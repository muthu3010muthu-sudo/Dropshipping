/* ==========================================================================
   MECH DESIGNHUB — render.js
   Builds product cards + populates home / listing / details pages from PRODUCTS
   ========================================================================== */

const CATEGORY_ICONS = {
  "Electronics": "fa-solid fa-microchip",
  "Home & Kitchen": "fa-solid fa-blender",
  "Fashion": "fa-solid fa-shirt",
  "Furniture": "fa-solid fa-couch",
  "Beauty": "fa-solid fa-spa",
  "Sports": "fa-solid fa-dumbbell",
  "Accessories": "fa-solid fa-bag-shopping",
  "Toys": "fa-solid fa-robot",
  "Books": "fa-solid fa-book",
  "Office Supplies": "fa-solid fa-briefcase",
  "Automotive": "fa-solid fa-car",
  "Pet Supplies": "fa-solid fa-paw",
};

function badgeHTML(p) {
  const out = [];
  if (p.badges.includes("deal")) out.push(`<span class="tag tag-deal">DEAL</span>`);
  if (p.badges.includes("bestseller")) out.push(`<span class="tag tag-best">BESTSELLER</span>`);
  if (p.badges.includes("new")) out.push(`<span class="tag tag-new">NEW</span>`);
  if (p.badges.includes("trending")) out.push(`<span class="tag tag-trend">TRENDING</span>`);
  return out.slice(0, 2).join("");
}

function productCardHTML(p) {
  const wished = STORE.wishlist.has(p.id);
  return `
  <div class="pcard" data-aos="fade-up">
    <div class="pcard-media">
      <a href="product-details.html?id=${p.id}">
        <img src="${p.image}" alt="${p.name}" loading="lazy">
      </a>
      <div class="pcard-badges">${badgeHTML(p)}</div>
      <button class="pcard-wish ${wished ? "active" : ""}" data-id="${p.id}" aria-label="Toggle wishlist">
        <i class="fa-${wished ? "solid" : "regular"} fa-heart"></i>
      </button>
      <div class="pcard-quick">
        <button data-quickview="${p.id}"><i class="fa-regular fa-eye"></i> Quick View</button>
      </div>
    </div>
    <div class="pcard-body">
      <div class="pcard-brand">${p.brand}</div>
      <div class="pcard-name"><a href="product-details.html?id=${p.id}">${p.name}</a></div>
      <div class="pcard-rating"><span class="stars">${STORE.stars(p.rating)}</span><span class="count">${p.rating} (${p.reviewsCount})</span></div>
      <div class="pcard-price">
        <span class="price-now">${STORE.currency(p.price)}</span>
        <span class="price-mrp">${STORE.currency(p.mrp)}</span>
        <span class="price-off">${p.discount}% OFF</span>
      </div>
      <div class="free-del"><i class="fa-solid fa-truck-fast"></i> Free delivery · ${p.deliveryTime}</div>
      <div class="pcard-foot">
        <button class="btn btn-outline" data-quickview="${p.id}"><i class="fa-regular fa-eye"></i></button>
        <button class="btn btn-primary" onclick="openBuyNow('${p.id}')"><i class="fa-solid fa-bolt"></i> Buy Now</button>
      </div>
    </div>
  </div>`;
}

function productRowSlider(containerId, list) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = list.map(productCardHTML).join("");
}

/* ================= HOME PAGE ================= */
function renderHome() {
  if (typeof PRODUCTS === "undefined") return;
  const byBadge = (b) => PRODUCTS.filter(p => p.badges.includes(b));

  productRowSlider("featured-products", shuffleSample(byBadge("featured").length ? byBadge("featured") : PRODUCTS, 8));
  productRowSlider("trending-products", shuffleSample(byBadge("trending"), 8));
  productRowSlider("flash-deals", [...byBadge("deal")].sort((a, b) => b.discount - a.discount).slice(0, 8));
  productRowSlider("bestseller-products", [...byBadge("bestseller")].sort((a, b) => b.reviewsCount - a.reviewsCount).slice(0, 8));
  productRowSlider("newarrival-products", shuffleSample(byBadge("new"), 8));

  // categories grid
  const catCounts = {};
  PRODUCTS.forEach(p => catCounts[p.category] = (catCounts[p.category] || 0) + 1);
  const catGrid = document.getElementById("home-categories");
  if (catGrid) {
    catGrid.innerHTML = Object.keys(CATEGORY_ICONS).map(cat => `
      <a class="cat-card" href="products.html?category=${encodeURIComponent(cat)}" data-aos="zoom-in">
        <div class="cat-icon"><i class="${CATEGORY_ICONS[cat]}"></i></div>
        <div class="cat-name">${cat}</div>
        <div class="cat-count">${catCounts[cat] || 0} items</div>
      </a>`).join("");
  }
}

function shuffleSample(arr, n) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy.slice(0, n);
}

/* ================= CATEGORIES PAGE ================= */
function renderCategoriesPage() {
  if (typeof PRODUCTS === "undefined") return;
  const catCounts = {};
  PRODUCTS.forEach(p => catCounts[p.category] = (catCounts[p.category] || 0) + 1);
  const grid = document.getElementById("all-categories-grid");
  if (!grid) return;
  grid.innerHTML = Object.keys(CATEGORY_ICONS).map(cat => `
    <a class="cat-card" href="products.html?category=${encodeURIComponent(cat)}" style="padding:32px 16px;" data-aos="fade-up">
      <div class="cat-icon" style="width:64px;height:64px;font-size:26px;"><i class="${CATEGORY_ICONS[cat]}"></i></div>
      <div class="cat-name" style="font-size:15px;">${cat}</div>
      <div class="cat-count">${catCounts[cat] || 0} products</div>
    </a>`).join("");
}

/* ================= PRODUCTS LISTING PAGE ================= */
const listingState = { category: [], brand: [], rating: 0, discount: 0, minPrice: null, maxPrice: null, sort: "popular", q: "" };

function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function initListingPage() {
  if (typeof PRODUCTS === "undefined" || !document.getElementById("products-grid")) return;

  const qCat = getQueryParam("category");
  const qQuery = getQueryParam("q");
  if (qCat) listingState.category = [qCat];
  if (qQuery) listingState.q = qQuery;

  const searchInput = document.getElementById("listing-search-input");
  if (searchInput && qQuery) searchInput.value = qQuery;

  buildFilterPanel();
  bindListingControls();
  applyListingFilters();
}

function buildFilterPanel() {
  const brands = [...new Set(PRODUCTS.map(p => p.brand))].sort();
  const categories = Object.keys(CATEGORY_ICONS);

  const catBox = document.getElementById("filter-categories");
  if (catBox) {
    catBox.innerHTML = categories.map(c => `
      <label class="filter-option">
        <input type="checkbox" value="${c}" class="f-category" ${listingState.category.includes(c) ? "checked" : ""}>
        ${c} <span class="fo-count">${PRODUCTS.filter(p => p.category === c).length}</span>
      </label>`).join("");
  }
  const brandBox = document.getElementById("filter-brands");
  if (brandBox) {
    brandBox.innerHTML = brands.map(b => `
      <label class="filter-option">
        <input type="checkbox" value="${b}" class="f-brand">
        ${b} <span class="fo-count">${PRODUCTS.filter(p => p.brand === b).length}</span>
      </label>`).join("");
  }
}

function bindListingControls() {
  document.querySelectorAll(".f-category").forEach(cb => cb.addEventListener("change", collectFilters));
  document.querySelectorAll(".f-brand").forEach(cb => cb.addEventListener("change", collectFilters));
  document.querySelectorAll(".f-rating").forEach(cb => cb.addEventListener("change", collectFilters));
  document.querySelectorAll(".f-discount").forEach(cb => cb.addEventListener("change", collectFilters));
  document.getElementById("price-min")?.addEventListener("change", collectFilters);
  document.getElementById("price-max")?.addEventListener("change", collectFilters);
  document.getElementById("sort-select")?.addEventListener("change", (e) => { listingState.sort = e.target.value; applyListingFilters(); });
  document.getElementById("clear-filters")?.addEventListener("click", () => {
    listingState.category = []; listingState.brand = []; listingState.rating = 0; listingState.discount = 0;
    listingState.minPrice = null; listingState.maxPrice = null; listingState.q = "";
    document.querySelectorAll(".filters-panel input[type=checkbox]").forEach(c => c.checked = false);
    document.querySelectorAll(".filters-panel input[type=number]").forEach(c => c.value = "");
    const si = document.getElementById("listing-search-input"); if (si) si.value = "";
    applyListingFilters();
  });

  const searchInput = document.getElementById("listing-search-input");
  searchInput?.addEventListener("input", () => {
    listingState.q = searchInput.value.trim();
    applyListingFilters();
  });

  document.getElementById("mobile-filter-open")?.addEventListener("click", () => {
    document.querySelector(".filters-panel")?.classList.add("open");
    document.getElementById("filter-overlay")?.classList.add("show");
  });
  document.getElementById("filter-overlay")?.addEventListener("click", closeMobileFilters);
  document.getElementById("mobile-filter-close")?.addEventListener("click", closeMobileFilters);
}
function closeMobileFilters() {
  document.querySelector(".filters-panel")?.classList.remove("open");
  document.getElementById("filter-overlay")?.classList.remove("show");
}

function collectFilters() {
  listingState.category = [...document.querySelectorAll(".f-category:checked")].map(c => c.value);
  listingState.brand = [...document.querySelectorAll(".f-brand:checked")].map(c => c.value);
  const ratingChecked = document.querySelector(".f-rating:checked");
  listingState.rating = ratingChecked ? parseFloat(ratingChecked.value) : 0;
  const discountChecked = document.querySelector(".f-discount:checked");
  listingState.discount = discountChecked ? parseInt(discountChecked.value, 10) : 0;
  const minP = document.getElementById("price-min")?.value;
  const maxP = document.getElementById("price-max")?.value;
  listingState.minPrice = minP ? parseFloat(minP) : null;
  listingState.maxPrice = maxP ? parseFloat(maxP) : null;
  applyListingFilters();
}

function applyListingFilters() {
  let result = PRODUCTS.filter(p => {
    if (listingState.category.length && !listingState.category.includes(p.category)) return false;
    if (listingState.brand.length && !listingState.brand.includes(p.brand)) return false;
    if (listingState.rating && p.rating < listingState.rating) return false;
    if (listingState.discount && p.discount < listingState.discount) return false;
    if (listingState.minPrice !== null && p.price < listingState.minPrice) return false;
    if (listingState.maxPrice !== null && p.price > listingState.maxPrice) return false;
    if (listingState.q) {
      const q = listingState.q.toLowerCase();
      if (!p.name.toLowerCase().includes(q) && !p.id.toLowerCase().includes(q) &&
          !p.brand.toLowerCase().includes(q) && !p.category.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  switch (listingState.sort) {
    case "price-low": result.sort((a, b) => a.price - b.price); break;
    case "price-high": result.sort((a, b) => b.price - a.price); break;
    case "rating": result.sort((a, b) => b.rating - a.rating); break;
    case "discount": result.sort((a, b) => b.discount - a.discount); break;
    case "popular": default: result.sort((a, b) => b.reviewsCount - a.reviewsCount); break;
  }

  renderChips();
  const grid = document.getElementById("products-grid");
  const countEl = document.getElementById("result-count");
  if (countEl) countEl.textContent = `${result.length} product${result.length !== 1 ? "s" : ""} found`;
  if (!result.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><i class="fa-solid fa-magnifying-glass"></i><h4>No products match your filters</h4><p>Try adjusting or clearing your filters.</p></div>`;
    return;
  }
  grid.innerHTML = result.map(productCardHTML).join("");
}

function renderChips() {
  const chipRow = document.getElementById("chip-row");
  if (!chipRow) return;
  const chips = [];
  listingState.category.forEach(c => chips.push({ label: c, clear: () => removeFrom("f-category", c) }));
  listingState.brand.forEach(b => chips.push({ label: b, clear: () => removeFrom("f-brand", b) }));
  if (listingState.q) chips.push({ label: `"${listingState.q}"`, clear: () => { listingState.q = ""; const si = document.getElementById("listing-search-input"); if (si) si.value = ""; applyListingFilters(); } });
  chipRow.innerHTML = chips.map((c, i) => `<span class="filter-chip">${c.label}<button data-chip-i="${i}"><i class="fa-solid fa-xmark"></i></button></span>`).join("");
  chipRow.querySelectorAll("button").forEach((btn, i) => btn.addEventListener("click", () => chips[i].clear()));
  function removeFrom(cls, val) {
    document.querySelectorAll(`.${cls}`).forEach(cb => { if (cb.value === val) cb.checked = false; });
    collectFilters();
  }
}

/* ================= PRODUCT DETAILS PAGE ================= */
function initProductDetailsPage() {
  const container = document.getElementById("pd-root");
  if (!container || typeof PRODUCTS === "undefined") return;
  const id = getQueryParam("id");
  const p = findProduct(id) || PRODUCTS[0];
  if (!p) return;
  STORE.recent.add(p.id);

  document.title = `${p.name} | Mech DesignHub`;
  document.getElementById("pd-breadcrumb-cat").textContent = p.category;
  document.getElementById("pd-breadcrumb-cat").href = `products.html?category=${encodeURIComponent(p.category)}`;
  document.getElementById("pd-breadcrumb-name").textContent = p.name;

  document.getElementById("pd-main-image").src = p.images[0];
  document.getElementById("pd-thumbs").innerHTML = p.images.map((img, i) => `<img src="${img}" class="${i === 0 ? "active" : ""}" data-i="${i}">`).join("");
  document.querySelectorAll("#pd-thumbs img").forEach(t => t.addEventListener("click", () => {
    document.getElementById("pd-main-image").src = p.images[t.dataset.i];
    document.querySelectorAll("#pd-thumbs img").forEach(x => x.classList.remove("active"));
    t.classList.add("active");
  }));

  document.getElementById("pd-brand").textContent = p.brand;
  document.getElementById("pd-name").textContent = p.name;
  document.getElementById("pd-stars").innerHTML = STORE.stars(p.rating);
  document.getElementById("pd-rating-text").textContent = `${p.rating} (${p.reviewsCount} reviews)`;
  document.getElementById("pd-id").textContent = p.id;
  document.getElementById("pd-sku").textContent = p.sku;
  document.getElementById("pd-price").textContent = STORE.currency(p.price);
  document.getElementById("pd-mrp").textContent = STORE.currency(p.mrp);
  document.getElementById("pd-off").textContent = `${p.discount}% OFF`;
  document.getElementById("pd-saved").textContent = STORE.currency(p.saved);
  document.getElementById("pd-availability").textContent = p.availability;
  document.getElementById("pd-delivery").textContent = p.deliveryTime;
  document.getElementById("pd-warranty").textContent = p.warranty;
  document.getElementById("pd-return").textContent = p.returnPolicy;
  document.getElementById("pd-desc").textContent = p.description;
  document.getElementById("pd-features").innerHTML = p.features.map(f => `<li><i class="fa-solid fa-circle-check" style="color:var(--green);margin-right:8px;"></i>${f}</li>`).join("");
  document.getElementById("pd-specs").innerHTML = Object.entries(p.specifications).map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join("");
  document.getElementById("pd-reviews").innerHTML = p.reviews.map(r => `
    <div class="review-row">
      <div class="testi-avatar" style="flex-shrink:0;">${r.name[0]}</div>
      <div>
        <div style="display:flex;align-items:center;gap:8px;"><b style="font-size:13.5px;">${r.name}</b><span class="stars" style="font-size:11px;">${STORE.stars(r.rating)}</span></div>
        <p style="margin:4px 0 0;font-size:13px;">${r.text}</p>
      </div>
    </div>`).join("");
  const buyBtn = document.getElementById("pd-buy-btn");
  if (buyBtn) buyBtn.onclick = () => openBuyNow(p.id);
  const wishBtn = document.getElementById("pd-wish-btn");
  if (wishBtn) {
    const wished = STORE.wishlist.has(p.id);
    wishBtn.classList.toggle("active", wished);
    wishBtn.innerHTML = `<i class="fa-${wished ? "solid" : "regular"} fa-heart"></i>`;
    wishBtn.onclick = () => {
      const added = STORE.wishlist.toggle(p.id);
      wishBtn.classList.toggle("active", added);
      wishBtn.innerHTML = `<i class="fa-${added ? "solid" : "regular"} fa-heart"></i>`;
      showToast(added ? "Added to wishlist" : "Removed from wishlist", added ? "success" : "info");
    };
  }

  // Tabs
  document.querySelectorAll(".pd-tab").forEach(tab => tab.addEventListener("click", () => {
    document.querySelectorAll(".pd-tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".pd-tabpanel").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(tab.dataset.target).classList.add("active");
  }));

  // Related products
  const related = PRODUCTS.filter(x => x.category === p.category && x.id !== p.id).slice(0, 4);
  productRowSlider("pd-related", related.length ? related : shuffleSample(PRODUCTS.filter(x => x.id !== p.id), 4));

  // Recently viewed
  const recentIds = STORE.recent.get().filter(rid => rid !== p.id);
  const recentProducts = recentIds.map(findProduct).filter(Boolean).slice(0, 4);
  const recentSection = document.getElementById("pd-recent-section");
  if (recentProducts.length) {
    productRowSlider("pd-recent", recentProducts);
    recentSection.style.display = "";
  } else if (recentSection) recentSection.style.display = "none";
}

document.addEventListener("DOMContentLoaded", () => {
  renderHome();
  renderCategoriesPage();
  initListingPage();
  initProductDetailsPage();
});
