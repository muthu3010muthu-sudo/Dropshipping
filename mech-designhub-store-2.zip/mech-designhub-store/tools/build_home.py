# -*- coding: utf-8 -*-
from build_common import IG_URL

def home_body():
    return f"""
<section class="hero">
  <div class="hero-shape s1"></div>
  <div class="hero-shape s2"></div>
  <div class="container hero-grid">
    <div class="hero-copy">
      <div class="eyebrow">Manually Verified Orders · Est. mech_designhub</div>
      <h1 class="hero-title">Everyday essentials,<br><span class="accent">engineered</span> for value.</h1>
      <p class="hero-desc">Browse a curated catalog of 150+ products across 12 categories. Build your order sheet in seconds, download a professional PDF, and confirm directly with our team over Instagram — no accounts, no online payment.</p>
      <div class="hero-cta">
        <a href="products.html" class="btn btn-primary btn-lg"><i class="fa-solid fa-bag-shopping"></i> Shop Now</a>
        <a href="{IG_URL}" target="_blank" rel="noopener" class="btn btn-ig"><i class="fa-brands fa-instagram"></i> Order on Instagram</a>
      </div>
      <div class="hero-stats">
        <div class="hero-stat"><b data-count="156">0</b><span>Demo Products</span></div>
        <div class="hero-stat"><b data-count="12">0</b><span>Categories</span></div>
        <div class="hero-stat"><b data-count="5200">0</b><span>Orders Fulfilled</span></div>
        <div class="hero-stat"><b data-count="47" id="rating-stat">0</b><span>Avg. Rating ×10</span></div>
      </div>
    </div>
    <div class="hero-visual">
      <div class="hero-frame">
        <img src="https://placehold.co/900x900/2F5CFF/FFFFFF?font=poppins&text=Mech+DesignHub" alt="Featured product collage">
        <span class="corner-bracket tl"></span>
        <span class="corner-bracket br"></span>
      </div>
      <div class="float-card glass-card fc1"><div class="fc-title"><i class="fa-solid fa-truck-fast" style="color:var(--blue-600);"></i>&nbsp; Free Delivery</div><div class="fc-sub">On all prepaid-verified orders</div></div>
      <div class="float-card glass-card fc2"><div class="fc-title"><i class="fa-solid fa-shield-check" style="color:var(--green);"></i>&nbsp; Manually Verified</div><div class="fc-sub">Every order confirmed via DM</div></div>
    </div>
  </div>
</section>

<div class="marquee-wrap">
  <div class="marquee-track">
    <span>VOLTRIX</span><span>NORDLY</span><span>ATHLEX</span><span>HEARTHLY</span><span>URBANWEAR</span><span>KRYONIX</span><span>GLOWVANA</span><span>WOODURA</span><span>DRIVEON</span><span>PAWSOME</span>
    <span>VOLTRIX</span><span>NORDLY</span><span>ATHLEX</span><span>HEARTHLY</span><span>URBANWEAR</span><span>KRYONIX</span><span>GLOWVANA</span><span>WOODURA</span><span>DRIVEON</span><span>PAWSOME</span>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="section-head">
      <div>
        <div class="eyebrow">Browse</div>
        <h2 class="section-title">Shop by Category</h2>
        <p class="section-sub">Twelve carefully organized departments, from electronics to pet supplies.</p>
      </div>
      <a href="categories.html" class="link-more">View all categories <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <div class="cat-grid" id="home-categories"></div>
  </div>
</section>

<section class="section-tight" style="background:#fff;">
  <div class="container">
    <div class="section-head">
      <div><div class="eyebrow">Handpicked</div><h2 class="section-title">Featured Products</h2></div>
      <a href="products.html" class="link-more">Shop all <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <div class="product-grid" id="featured-products"></div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="section-head">
      <div><div class="eyebrow">Right Now</div><h2 class="section-title">Trending Products</h2></div>
      <a href="products.html" class="link-more">Shop all <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <div class="product-grid" id="trending-products"></div>
  </div>
</section>

<section class="section-tight" style="background:#fff;">
  <div class="container">
    <div class="deal-strip">
      <div class="dl-left">
        <div class="eyebrow" style="color:#ffd08a;">Limited Time</div>
        <h3>Flash Deals — up to 50% off</h3>
        <p>Prices refresh daily. Grab them before the clock resets.</p>
      </div>
      <div class="countdown" id="flash-countdown">
        <div class="cd-box"><b class="cd-h">00</b><span>Hours</span></div>
        <div class="cd-box"><b class="cd-m">00</b><span>Mins</span></div>
        <div class="cd-box"><b class="cd-s">00</b><span>Secs</span></div>
      </div>
    </div>
    <div class="product-grid" id="flash-deals"></div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="section-head">
      <div><div class="eyebrow">Fan Favorites</div><h2 class="section-title">Best Sellers</h2></div>
      <a href="products.html" class="link-more">Shop all <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <div class="product-grid" id="bestseller-products"></div>
  </div>
</section>

<section class="section-tight" style="background:#fff;">
  <div class="container">
    <div class="section-head">
      <div><div class="eyebrow">Just Landed</div><h2 class="section-title">New Arrivals</h2></div>
      <a href="products.html" class="link-more">Shop all <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <div class="product-grid" id="newarrival-products"></div>
  </div>
</section>

<section class="section" id="how-to-order">
  <div class="container">
    <div class="section-head">
      <div><div class="eyebrow">Simple &amp; Transparent</div><h2 class="section-title">How to Order</h2><p class="section-sub">No accounts, no online payment. Just eight quick steps to a confirmed order.</p></div>
    </div>
    <div class="timeline" data-aos="fade-up">
      <div class="tl-step"><div class="tl-num">1</div><h4>Browse Products</h4><p>Explore 150+ items across 12 categories.</p></div>
      <div class="tl-step"><div class="tl-num">2</div><h4>Open Details</h4><p>Check specs, reviews and pricing.</p></div>
      <div class="tl-step"><div class="tl-num">3</div><h4>Click Buy Now</h4><p>Start your order sheet instantly.</p></div>
      <div class="tl-step"><div class="tl-num">4</div><h4>Fill Delivery Info</h4><p>Enter your address and contact details.</p></div>
    </div>
    <div class="timeline" style="margin-top:26px;" data-aos="fade-up">
      <div class="tl-step"><div class="tl-num">5</div><h4>Generate PDF</h4><p>Download your professional order sheet.</p></div>
      <div class="tl-step"><div class="tl-num">6</div><h4>Send via Instagram</h4><p>DM the PDF to @mech_designhub.</p></div>
      <div class="tl-step"><div class="tl-num">7</div><h4>We Verify</h4><p>Our team checks and confirms your order.</p></div>
      <div class="tl-step"><div class="tl-num">8</div><h4>Get Updates</h4><p>Receive confirmation and shipping status.</p></div>
    </div>
    <div class="text-center" style="margin-top:32px;">
      <a href="{IG_URL}" target="_blank" rel="noopener" class="btn btn-ig"><i class="fa-brands fa-instagram"></i> Order on Instagram</a>
    </div>
  </div>
</section>

<section class="section-tight" style="background:#fff;">
  <div class="container">
    <div class="section-head">
      <div><div class="eyebrow">Reviews</div><h2 class="section-title">What Customers Say</h2></div>
    </div>
    <div class="swiper testi-swiper" data-aos="fade-up">
      <div class="swiper-wrapper" style="padding-bottom:6px;">
        <div class="swiper-slide"><div class="testi-card"><div class="testi-stars">★★★★★</div><p class="testi-text">"Ordered a pair of earbuds — the PDF process was so easy and the team confirmed on Instagram within an hour."</p><div class="testi-person"><div class="testi-avatar">R</div><div><b>Riya Mehta</b><span>Mumbai</span></div></div></div></div>
        <div class="swiper-slide"><div class="testi-card"><div class="testi-stars">★★★★★</div><p class="testi-text">"Loved that there was no signup needed. Filled the form, sent the PDF, done. Product quality was great too."</p><div class="testi-person"><div class="testi-avatar">A</div><div><b>Aman Verma</b><span>Delhi</span></div></div></div></div>
        <div class="swiper-slide"><div class="testi-card"><div class="testi-stars">★★★★☆</div><p class="testi-text">"Good prices and the order sheet PDF looked genuinely professional. Delivery took a day longer than expected."</p><div class="testi-person"><div class="testi-avatar">S</div><div><b>Sana Iqbal</b><span>Bengaluru</span></div></div></div></div>
        <div class="swiper-slide"><div class="testi-card"><div class="testi-stars">★★★★★</div><p class="testi-text">"Ordered furniture for my study, the specs table on the product page made the decision easy."</p><div class="testi-person"><div class="testi-avatar">K</div><div><b>Karan Shah</b><span>Pune</span></div></div></div></div>
        <div class="swiper-slide"><div class="testi-card"><div class="testi-stars">★★★★★</div><p class="testi-text">"Their Instagram team replied fast and kept me updated until delivery. Will shop again."</p><div class="testi-person"><div class="testi-avatar">P</div><div><b>Priyanka Nair</b><span>Kochi</span></div></div></div></div>
      </div>
    </div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <div class="newsletter-band" data-aos="zoom-in">
      <div class="eyebrow" style="justify-content:center;">Stay Updated</div>
      <h2 class="section-title">Get early access to new drops &amp; deals</h2>
      <p class="section-sub" style="margin:0 auto;">No spam — just fresh arrivals and flash-deal alerts.</p>
      <form class="newsletter-form">
        <input type="email" placeholder="Enter your email" required aria-label="Email for newsletter">
        <button class="btn btn-primary" type="submit">Subscribe</button>
      </form>
    </div>
  </div>
</section>

<section class="section-tight" style="padding-top:0;">
  <div class="container">
    <div class="ig-band" data-aos="fade-up">
      <div>
        <h3><i class="fa-brands fa-instagram"></i> Prefer to order on Instagram?</h3>
        <p>Message us your favorite product screenshots any time — our team replies during business hours to help you check out manually.</p>
      </div>
      <a href="{IG_URL}" target="_blank" rel="noopener" class="btn" style="background:#fff;color:#dd2a7b;"><i class="fa-brands fa-instagram"></i> @mech_designhub</a>
    </div>
  </div>
</section>
"""

HOME_EXTRA_SCRIPT = """
<script>
  document.addEventListener('DOMContentLoaded', function () {
    if (window.Swiper) {
      new Swiper('.testi-swiper', {
        slidesPerView: 1.05,
        spaceBetween: 20,
        breakpoints: { 700: { slidesPerView: 2, spaceBetween: 22 }, 1080: { slidesPerView: 3, spaceBetween: 24 } },
        autoplay: { delay: 3800, disableOnInteraction: false },
        loop: true,
      });
    }
  });
</script>
"""
