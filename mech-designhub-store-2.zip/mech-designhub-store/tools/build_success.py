# -*- coding: utf-8 -*-
from build_common import IG_URL

def order_success_body():
    return f"""
<section class="section" style="padding-top:54px;">
  <div class="container" style="max-width:720px;">

    <div id="no-order-fallback" class="empty-state" style="display:none;">
      <i class="fa-regular fa-file-lines"></i>
      <h3>No recent order found</h3>
      <p>It looks like you haven't generated an order sheet yet, or this page was opened directly.</p>
      <a href="products.html" class="btn btn-primary"><i class="fa-solid fa-bag-shopping"></i> Browse Products</a>
    </div>

    <div id="order-content" style="display:none;">
      <div class="success-view">
        <div class="success-icon"><i class="fa-solid fa-check"></i></div>
        <h1 class="section-title" style="margin-bottom:6px;">Order Sheet Generated!</h1>
        <p style="max-width:520px;margin:0 auto;">Your order form has been generated successfully. Please download the PDF and send it to our official Instagram account through Instagram Direct Message. Once we verify your order, we will contact you to confirm it.</p>
        <div class="order-id-box">
          <i class="fa-solid fa-hashtag" style="color:var(--blue-600);"></i>
          <span id="success-order-id">—</span>
          <button id="copy-order-id-btn" class="icon-btn" style="width:28px;height:28px;border:none;background:var(--gray-100);" aria-label="Copy Order ID"><i class="fa-regular fa-copy" style="font-size:12px;"></i></button>
        </div>
      </div>

      <div class="glass-card" style="padding:22px;margin-bottom:22px;">
        <h4 style="margin-bottom:14px;font-size:14.5px;"><i class="fa-solid fa-file-invoice" style="color:var(--blue-600);"></i> Your Order Sheet</h4>
        <div style="display:flex;gap:12px;flex-wrap:wrap;">
          <button id="btn-download-pdf" class="btn btn-primary"><i class="fa-solid fa-download"></i> Download PDF</button>
          <button id="btn-preview-pdf" class="btn btn-outline"><i class="fa-regular fa-eye"></i> Preview PDF</button>
          <button id="btn-print-pdf" class="btn btn-outline"><i class="fa-solid fa-print"></i> Print PDF</button>
        </div>
      </div>

      <div class="ig-band" style="margin-bottom:26px;">
        <div>
          <h3><i class="fa-brands fa-instagram"></i> Step 2: Send it to Instagram</h3>
          <p>DM your downloaded PDF to <b>@mech_designhub</b> to complete your order.</p>
        </div>
        <a id="btn-open-instagram" href="{IG_URL}" target="_blank" rel="noopener" class="btn" style="background:#fff;color:#dd2a7b;"><i class="fa-brands fa-instagram"></i> Open Instagram</a>
      </div>

      <div class="glass-card" style="padding:22px;margin-bottom:26px;">
        <h4 style="margin-bottom:14px;font-size:14.5px;">Order Summary</h4>
        <div id="order-summary-details"></div>
      </div>

      <div class="timeline" style="grid-template-columns:repeat(3,1fr);">
        <div class="tl-step"><div class="tl-num"><i class="fa-brands fa-instagram" style="font-size:14px;"></i></div><h4>Sent to Instagram</h4><p>Your PDF is on its way to our team.</p></div>
        <div class="tl-step"><div class="tl-num"><i class="fa-solid fa-magnifying-glass" style="font-size:13px;"></i></div><h4>We Verify</h4><p>We confirm stock, price and address.</p></div>
        <div class="tl-step"><div class="tl-num"><i class="fa-solid fa-truck" style="font-size:13px;"></i></div><h4>Confirmed &amp; Shipped</h4><p>You'll get delivery updates from us.</p></div>
      </div>

      <div class="text-center" style="margin-top:30px;">
        <a href="products.html" class="link-more" style="justify-content:center;"><i class="fa-solid fa-arrow-left"></i> Continue Shopping</a>
      </div>
    </div>

  </div>
</section>
"""

ORDER_SUCCESS_SCRIPT = """
<script>
document.addEventListener('DOMContentLoaded', function () {
  var raw = localStorage.getItem('mdh_last_order');
  var fallback = document.getElementById('no-order-fallback');
  var content = document.getElementById('order-content');
  if (!raw) { fallback.style.display = 'block'; return; }
  var order;
  try { order = JSON.parse(raw); } catch (e) { fallback.style.display = 'block'; return; }
  content.style.display = 'block';

  document.getElementById('success-order-id').textContent = order.orderId;

  var addr = order.address;
  var addrLine = [addr.houseNo, addr.apartment, addr.street, addr.area].filter(Boolean).join(', ');
  document.getElementById('order-summary-details').innerHTML =
    '<div style="display:flex;gap:14px;align-items:center;padding-bottom:16px;border-bottom:1px solid var(--gray-100);margin-bottom:16px;">' +
      '<img src="' + order.product.image + '" style="width:60px;height:60px;border-radius:10px;object-fit:cover;">' +
      '<div style="flex:1;"><b style="font-size:13.5px;">' + order.product.name + '</b><div class="mono" style="font-size:11.5px;color:var(--gray-500);">' + order.product.id + ' &middot; Qty: ' + order.qty + '</div></div>' +
      '<b class="mono" style="font-size:15px;">' + STORE.currency(order.totalPrice) + '</b>' +
    '</div>' +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:13px;">' +
      '<div><div style="color:var(--gray-500);font-size:11px;">INVOICE NO.</div><b class="mono">' + order.invoiceNumber + '</b></div>' +
      '<div><div style="color:var(--gray-500);font-size:11px;">ORDER DATE</div><b>' + order.orderDate + '</b></div>' +
      '<div><div style="color:var(--gray-500);font-size:11px;">EST. DELIVERY</div><b>' + order.estDelivery + '</b></div>' +
      '<div><div style="color:var(--gray-500);font-size:11px;">CONTACT</div><b>' + order.customer.fullName + ' &middot; ' + order.customer.mobile + '</b></div>' +
      '<div style="grid-column:1/-1;"><div style="color:var(--gray-500);font-size:11px;">DELIVERY ADDRESS</div><b>' + addrLine + ', ' + addr.city + ', ' + addr.district + ', ' + addr.state + ' - ' + addr.pincode + ', ' + addr.country + '</b></div>' +
    '</div>';

  document.getElementById('btn-download-pdf').addEventListener('click', function () { generateOrderPDF(order, 'download'); });
  document.getElementById('btn-preview-pdf').addEventListener('click', function () { generateOrderPDF(order, 'preview'); });
  document.getElementById('btn-print-pdf').addEventListener('click', function () { generateOrderPDF(order, 'print'); });

  document.getElementById('copy-order-id-btn').addEventListener('click', function () {
    navigator.clipboard.writeText(order.orderId).then(function () {
      showToast('Order ID copied to clipboard', 'success');
    }).catch(function () {
      showToast('Could not copy — please copy manually', 'error');
    });
  });
});
</script>
"""
