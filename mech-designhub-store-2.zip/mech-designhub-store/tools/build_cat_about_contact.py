# -*- coding: utf-8 -*-
from build_common import IG_URL

def categories_body():
    return """
<div class="page-hero">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / Categories</div>
    <h1 class="section-title mt-0">Shop by Category</h1>
    <p class="section-sub" style="margin:0 auto;">Twelve departments covering everything from tech to pet care.</p>
  </div>
</div>
<div class="container section">
  <div class="cat-grid" id="all-categories-grid" style="grid-template-columns:repeat(4,1fr);"></div>
</div>
<section class="section-tight" style="background:#fff;padding-top:0;">
  <div class="container">
    <div class="ig-band" data-aos="fade-up">
      <div>
        <h3><i class="fa-brands fa-instagram"></i> Looking for something specific?</h3>
        <p>DM us a photo or description and we'll help you find it in our catalog — or source it for you.</p>
      </div>
      <a href="__IG_URL__" target="_blank" rel="noopener" class="btn" style="background:#fff;color:#dd2a7b;"><i class="fa-brands fa-instagram"></i> Ask on Instagram</a>
    </div>
  </div>
</section>
""".replace("__IG_URL__", IG_URL)


def about_body():
    return """
<div class="page-hero">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / About Us</div>
    <h1 class="section-title mt-0">About Mech DesignHub</h1>
    <p class="section-sub" style="margin:0 auto;">A frontend-only storefront built around one idea: simple, transparent, manually-verified shopping.</p>
  </div>
</div>

<section class="section">
  <div class="container" style="display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center;">
    <div data-aos="fade-right">
      <div class="eyebrow">Our Story</div>
      <h2 class="section-title">Built for shoppers who value clarity over checkout friction</h2>
      <p>Mech DesignHub started as a small dropshipping page on Instagram and grew into a full product catalog. We kept the part our customers liked best — a real person confirming every order — and paired it with a proper browsing experience: real specs, real reviews, and a clean order sheet you can download and send in seconds.</p>
      <p>We don't collect payments online and we don't ask you to create an account. You browse, you build an order sheet, and our team takes it from there over Instagram DM.</p>
      <a href="products.html" class="btn btn-primary"><i class="fa-solid fa-bag-shopping"></i> Browse Products</a>
    </div>
    <img src="https://placehold.co/700x560/E3E9FF/1E3FCC?font=poppins&text=Mech+DesignHub" style="border-radius:24px;" alt="About Mech DesignHub" data-aos="fade-left">
  </div>
</section>

<section class="section-tight" style="background:#fff;">
  <div class="container">
    <div class="counter-grid" data-aos="fade-up">
      <div class="counter-item"><b data-count="4">0</b><span>Years Active</span></div>
      <div class="counter-item"><b data-count="5200">0</b><span>Orders Fulfilled</span></div>
      <div class="counter-item"><b data-count="156">0</b><span>Products Listed</span></div>
      <div class="counter-item"><b data-count="12">0</b><span>Categories</span></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-head"><div><div class="eyebrow">What We Stand For</div><h2 class="section-title">Our Values</h2></div></div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:22px;">
      <div class="value-card" data-aos="fade-up"><div class="cat-icon" style="margin:0 auto 16px;"><i class="fa-solid fa-shield-halved"></i></div><h4>Transparent Pricing</h4><p style="font-size:13.5px;">Every product shows MRP, discount and savings up front — no hidden charges at checkout.</p></div>
      <div class="value-card" data-aos="fade-up"><div class="cat-icon" style="margin:0 auto 16px;"><i class="fa-solid fa-comments"></i></div><h4>Real Human Verification</h4><p style="font-size:13.5px;">A real team member checks every order sheet before it's confirmed — no bots, no auto-charges.</p></div>
      <div class="value-card" data-aos="fade-up"><div class="cat-icon" style="margin:0 auto 16px;"><i class="fa-solid fa-bolt"></i></div><h4>Fast, Simple Ordering</h4><p style="font-size:13.5px;">No sign-up. Fill one form, download your PDF, send it over — done in under two minutes.</p></div>
    </div>
  </div>
</section>

<section class="section-tight" style="padding-top:0;">
  <div class="container">
    <div class="ig-band" data-aos="fade-up">
      <div><h3><i class="fa-brands fa-instagram"></i> Come say hi on Instagram</h3><p>Follow @mech_designhub for new arrivals, flash deals and behind-the-scenes updates.</p></div>
      <a href="__IG_URL__" target="_blank" rel="noopener" class="btn" style="background:#fff;color:#dd2a7b;"><i class="fa-brands fa-instagram"></i> @mech_designhub</a>
    </div>
  </div>
</section>
""".replace("__IG_URL__", IG_URL)


def contact_body():
    return """
<div class="page-hero">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / Contact Us</div>
    <h1 class="section-title mt-0">Get In Touch</h1>
    <p class="section-sub" style="margin:0 auto;">Questions about a product or an existing order? Reach us below.</p>
  </div>
</div>

<section class="section">
  <div class="container contact-grid">
    <div class="contact-info-card" data-aos="fade-right">
      <h3>Contact Information</h3>
      <p style="color:rgba(255,255,255,.7);">Our team typically replies within a few hours during business time.</p>
      <div class="contact-info-item">
        <div class="ci-icon"><i class="fa-brands fa-instagram"></i></div>
        <div><b>Instagram DM (fastest)</b><br><a href="__IG_URL__" target="_blank" rel="noopener" style="color:#9db4ff;">@mech_designhub</a></div>
      </div>
      <div class="contact-info-item">
        <div class="ci-icon"><i class="fa-solid fa-envelope"></i></div>
        <div><b>Email</b><br>orders.mechdesignhub@gmail.com</div>
      </div>
      <div class="contact-info-item">
        <div class="ci-icon"><i class="fa-solid fa-clock"></i></div>
        <div><b>Support Hours</b><br>Mon–Sat, 10 AM – 7 PM IST</div>
      </div>
      <div class="contact-info-item">
        <div class="ci-icon"><i class="fa-solid fa-location-dot"></i></div>
        <div><b>Operating From</b><br>India (ships nationwide)</div>
      </div>
      <a href="__IG_URL__" target="_blank" rel="noopener" class="btn btn-ig btn-block" style="margin-top:20px;"><i class="fa-brands fa-instagram"></i> Message Us Now</a>
    </div>

    <div data-aos="fade-left">
      <h3>Send a Message</h3>
      <p>Prefer a written note? Fill this out — it's a demo form for this frontend-only site, so for real replies please use Instagram DM above.</p>
      <form id="contact-form">
        <div class="form-row">
          <div class="form-group"><label>Full Name <span class="req">*</span></label><input type="text" required></div>
          <div class="form-group"><label>Email <span class="req">*</span></label><input type="email" required></div>
        </div>
        <div class="form-group" style="margin-bottom:14px;"><label>Subject</label><input type="text" placeholder="Order question, product query, etc."></div>
        <div class="form-group" style="margin-bottom:18px;"><label>Message <span class="req">*</span></label><textarea rows="5" required style="resize:vertical;"></textarea></div>
        <button type="submit" class="btn btn-primary btn-block"><i class="fa-solid fa-paper-plane"></i> Send Message</button>
      </form>
    </div>
  </div>
</section>
""".replace("__IG_URL__", IG_URL)
