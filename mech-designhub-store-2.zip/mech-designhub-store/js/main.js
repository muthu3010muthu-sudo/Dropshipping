/* ==========================================================================
   MECH DESIGNHUB — main.js
   Core site behaviour: nav, search, wishlist, toasts, scroll fx, lib init
   ========================================================================== */

const STORE = {
  currency(n) {
    return "₹" + Math.round(n).toLocaleString("en-IN");
  },
  stars(rating) {
    const full = Math.floor(rating);
    const half = rating - full >= 0.5;
    let html = "";
    for (let i = 0; i < full; i++) html += '<i class="fa-solid fa-star"></i>';
    if (half) html += '<i class="fa-solid fa-star-half-stroke"></i>';
    for (let i = full + (half ? 1 : 0); i < 5; i++) html += '<i class="fa-regular fa-star"></i>';
    return html;
  },
  badgeMeta: {
    deal: { label: "DEAL", cls: "tag-deal" },
    new: { label: "NEW", cls: "tag-new" },
    bestseller: { label: "BESTSELLER", cls: "tag-best" },
    trending: { label: "TRENDING", cls: "tag-trend" },
  },
  wishlist: {
    key: "mdh_wishlist",
    get() { try { return JSON.parse(localStorage.getItem(this.key)) || []; } catch (e) { return []; } },
    has(id) { return this.get().includes(id); },
    toggle(id) {
      let list = this.get();
      let added;
      if (list.includes(id)) { list = list.filter(x => x !== id); added = false; }
      else { list.push(id); added = true; }
      localStorage.setItem(this.key, JSON.stringify(list));
      updateWishlistCount();
      return added;
    },
  },
  recent: {
    key: "mdh_recent",
    get() { try { return JSON.parse(localStorage.getItem(this.key)) || []; } catch (e) { return []; } },
    add(id) {
      let list = this.get().filter(x => x !== id);
      list.unshift(id);
      list = list.slice(0, 10);
      localStorage.setItem(this.key, JSON.stringify(list));
    },
  },
};

function findProduct(id) {
  return (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(p => p.id === id) : null;
}

function updateWishlistCount() {
  const count = STORE.wishlist.get().length;
  document.querySelectorAll("#wishlist-count").forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? "flex" : "none";
  });
}

/* ---------------- Toast ---------------- */
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;
  const icons = { success: "fa-circle-check", error: "fa-circle-exclamation", info: "fa-circle-info" };
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i><span>${message}</span>`;
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("show"));
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 350);
  }, 3200);
}
window.showToast = showToast;

/* ---------------- Generic modal ---------------- */
function openModal(innerHTML, id = "generic-modal") {
  closeModal(id);
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.id = id;
  overlay.innerHTML = `<div class="modal-box">${innerHTML}</div>`;
  document.body.appendChild(overlay);
  document.body.style.overflow = "hidden";
  requestAnimationFrame(() => overlay.classList.add("show"));
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closeModal(id); });
  return overlay;
}
function closeModal(id = "generic-modal") {
  const overlay = document.getElementById(id);
  if (!overlay) return;
  overlay.classList.remove("show");
  document.body.style.overflow = "";
  setTimeout(() => overlay.remove(), 300);
}
window.openModal = openModal;
window.closeModal = closeModal;

/* ---------------- Wishlist toggle (delegated) ---------------- */
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".pcard-wish");
  if (!btn) return;
  e.preventDefault();
  const id = btn.dataset.id;
  const added = STORE.wishlist.toggle(id);
  btn.classList.toggle("active", added);
  btn.innerHTML = added ? '<i class="fa-solid fa-heart"></i>' : '<i class="fa-regular fa-heart"></i>';
  showToast(added ? "Added to wishlist" : "Removed from wishlist", added ? "success" : "info");
});

document.addEventListener("click", (e) => {
  const qv = e.target.closest("[data-quickview]");
  if (!qv) return;
  openQuickView(qv.dataset.quickview);
});

function openQuickView(id) {
  const p = findProduct(id);
  if (!p) return;
  const overlay = openModal(`
    <div class="modal-head">
      <strong>Quick View</strong>
      <button class="modal-close" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <div style="display:grid;grid-template-columns:1fr 1.2fr;gap:22px;" class="qv-grid">
        <img src="${p.image}" alt="${p.name}" style="width:100%;border-radius:14px;background:#f6f7fb;">
        <div>
          <div class="pcard-brand">${p.brand}</div>
          <h3 style="margin:4px 0 8px;">${p.name}</h3>
          <div class="pcard-rating" style="margin-bottom:10px;"><span class="stars">${STORE.stars(p.rating)}</span><span class="count">${p.rating} (${p.reviewsCount})</span></div>
          <div class="pcard-price" style="margin-bottom:12px;">
            <span class="price-now" style="font-size:22px;">${STORE.currency(p.price)}</span>
            <span class="price-mrp">${STORE.currency(p.mrp)}</span>
            <span class="price-off">${p.discount}% OFF</span>
          </div>
          <p style="font-size:13.5px;">${p.description}</p>
          <div style="display:flex;gap:10px;margin-top:16px;">
            <button class="btn btn-primary" onclick="closeModal();openBuyNow('${p.id}')"><i class="fa-solid fa-bolt"></i> Buy Now</button>
            <a class="btn btn-outline" href="product-details.html?id=${p.id}">View Full Details</a>
          </div>
        </div>
      </div>
    </div>
  `);
}
window.openQuickView = openQuickView;

/* ---------------- Ripple ---------------- */
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".btn");
  if (!btn) return;
  const rect = btn.getBoundingClientRect();
  const ripple = document.createElement("span");
  const size = Math.max(rect.width, rect.height);
  ripple.className = "ripple";
  ripple.style.width = ripple.style.height = size + "px";
  ripple.style.left = (e.clientX - rect.left - size / 2) + "px";
  ripple.style.top = (e.clientY - rect.top - size / 2) + "px";
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 650);
});

/* ---------------- Search ---------------- */
function setupSearch() {
  const inputs = document.querySelectorAll(".nav-search input");
  inputs.forEach(input => {
    const wrap = input.closest(".nav-search");
    const suggestBox = wrap.querySelector(".search-suggest");
    input.addEventListener("input", () => {
      const q = input.value.trim().toLowerCase();
      if (!q || typeof PRODUCTS === "undefined") { suggestBox.classList.remove("show"); return; }
      const results = PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
      ).slice(0, 6);
      if (!results.length) {
        suggestBox.innerHTML = `<div class="sg-empty">No products found for "${input.value}"</div>`;
      } else {
        suggestBox.innerHTML = results.map(p => `
          <a class="sg-item" href="product-details.html?id=${p.id}">
            <img src="${p.image}" alt="">
            <div>
              <div class="sg-name">${p.name}</div>
              <div class="sg-cat">${p.category} · ${STORE.currency(p.price)}</div>
            </div>
          </a>`).join("");
      }
      suggestBox.classList.add("show");
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        window.location.href = `products.html?q=${encodeURIComponent(input.value.trim())}`;
      }
    });
    document.addEventListener("click", (e) => {
      if (!wrap.contains(e.target)) suggestBox.classList.remove("show");
    });
    wrap.querySelector("button")?.addEventListener("click", () => {
      window.location.href = `products.html?q=${encodeURIComponent(input.value.trim())}`;
    });
  });
}

/* ---------------- Wishlist mini panel ---------------- */
function openWishlistPanel() {
  const ids = STORE.wishlist.get();
  const items = ids.map(findProduct).filter(Boolean);
  const rows = items.length ? items.map(p => `
    <div style="display:flex;gap:12px;align-items:center;padding:12px 0;border-bottom:1px solid var(--gray-100);">
      <img src="${p.image}" style="width:56px;height:56px;border-radius:10px;object-fit:cover;">
      <div style="flex:1;">
        <div style="font-size:13px;font-weight:600;">${p.name}</div>
        <div style="font-family:var(--font-mono);font-size:12.5px;color:var(--blue-700);">${STORE.currency(p.price)}</div>
      </div>
      <button class="btn btn-sm btn-outline" onclick="closeModal('wishlist-modal');openBuyNow('${p.id}')">Buy</button>
      <button class="icon-btn btn-sm" style="width:32px;height:32px;" onclick="STORE.wishlist.toggle('${p.id}');closeModal('wishlist-modal');openWishlistPanel();"><i class="fa-solid fa-trash" style="font-size:12px;"></i></button>
    </div>`).join("") : `<div class="empty-state"><i class="fa-regular fa-heart"></i><p>Your wishlist is empty.</p></div>`;

  openModal(`
    <div class="modal-head"><strong>My Wishlist</strong><button class="modal-close" onclick="closeModal('wishlist-modal')"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">${rows}</div>
  `, "wishlist-modal");
}
window.openWishlistPanel = openWishlistPanel;

/* ---------------- Init on DOM ready ---------------- */
document.addEventListener("DOMContentLoaded", () => {
  // Loader
  window.addEventListener("load", () => {
    setTimeout(() => document.getElementById("page-loader")?.classList.add("loaded"), 300);
  });
  setTimeout(() => document.getElementById("page-loader")?.classList.add("loaded"), 1800);

  // Year
  document.querySelectorAll(".cur-year").forEach(el => el.textContent = new Date().getFullYear());

  updateWishlistCount();
  setupSearch();

  // Navbar scroll state + progress bar
  const navbar = document.getElementById("navbar");
  const progress = document.getElementById("scroll-progress");
  const backTop = document.getElementById("back-to-top");
  window.addEventListener("scroll", () => {
    const y = window.scrollY;
    navbar?.classList.toggle("scrolled", y > 30);
    const h = document.documentElement.scrollHeight - window.innerHeight;
    if (progress) progress.style.width = (h > 0 ? (y / h) * 100 : 0) + "%";
    backTop?.classList.toggle("show", y > 500);
  }, { passive: true });

  backTop?.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  // Mobile drawer
  const burger = document.getElementById("nav-burger");
  const drawer = document.getElementById("mobile-drawer");
  const overlay = document.getElementById("drawer-overlay");
  function toggleDrawer(open) {
    drawer?.classList.toggle("open", open);
    overlay?.classList.toggle("show", open);
    document.body.style.overflow = open ? "hidden" : "";
  }
  burger?.addEventListener("click", () => toggleDrawer(true));
  overlay?.addEventListener("click", () => toggleDrawer(false));
  drawer?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => toggleDrawer(false)));

  // Animated counters
  const counters = document.querySelectorAll("[data-count]");
  if (counters.length) {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = parseInt(el.dataset.count, 10);
        let cur = 0;
        const step = Math.max(1, Math.ceil(target / 60));
        const tick = () => {
          cur += step;
          if (cur >= target) { el.textContent = target.toLocaleString("en-IN"); return; }
          el.textContent = cur.toLocaleString("en-IN");
          requestAnimationFrame(tick);
        };
        tick();
        obs.unobserve(el);
      });
    }, { threshold: 0.4 });
    counters.forEach(c => obs.observe(c));
  }

  // AOS init (if library loaded)
  if (window.AOS) AOS.init({ duration: 700, once: true, offset: 60, easing: "ease-out-cubic" });

  // GSAP hero entrance (if library loaded)
  if (window.gsap) {
    gsap.from(".hero-copy .eyebrow, .hero-title, .hero-desc, .hero-cta, .hero-stats", {
      y: 26, opacity: 0, duration: 0.8, stagger: 0.12, ease: "power3.out",
    });
    gsap.from(".hero-visual", { x: 40, opacity: 0, duration: 1, ease: "power3.out", delay: 0.15 });
  }

  // Newsletter forms
  document.querySelectorAll(".newsletter-form").forEach(form => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      showToast("Subscribed! Watch your inbox for deals.", "success");
      form.reset();
    });
  });

  // Contact form (demo only, no backend)
  document.getElementById("contact-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    showToast("Message sent! We'll reply within 24 hours.", "success");
    e.target.reset();
  });

  // Flash deal countdown (resets at next local midnight)
  const cdEl = document.getElementById("flash-countdown");
  if (cdEl) {
    const hEl = cdEl.querySelector(".cd-h"), mEl = cdEl.querySelector(".cd-m"), sEl = cdEl.querySelector(".cd-s");
    function tick() {
      const now = new Date();
      const end = new Date(now); end.setHours(24, 0, 0, 0);
      let diff = Math.max(0, end - now) / 1000;
      const h = Math.floor(diff / 3600), m = Math.floor((diff % 3600) / 60), s = Math.floor(diff % 60);
      hEl.textContent = String(h).padStart(2, "0");
      mEl.textContent = String(m).padStart(2, "0");
      sEl.textContent = String(s).padStart(2, "0");
    }
    tick();
    setInterval(tick, 1000);
  }

  // Accordions (FAQ)
  document.querySelectorAll(".accordion-head").forEach(head => {
    head.addEventListener("click", () => {
      const item = head.closest(".accordion-item");
      const wasOpen = item.classList.contains("open");
      item.parentElement.querySelectorAll(".accordion-item").forEach(i => i.classList.remove("open"));
      if (!wasOpen) item.classList.add("open");
    });
  });
});
