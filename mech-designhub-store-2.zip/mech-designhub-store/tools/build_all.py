# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from build_common import page_wrap
from build_home import home_body, HOME_EXTRA_SCRIPT
from build_products_pd import products_body, product_details_body
from build_cat_about_contact import categories_body, about_body, contact_body
from build_faq_policy_404 import faq_body, privacy_body, terms_body, notfound_body
from build_success import order_success_body, ORDER_SUCCESS_SCRIPT

OUT = os.path.join(os.path.dirname(__file__), "..")

pages = [
    ("index.html", "home", "Premium Dropshipping Store", "Shop 150+ curated products across 12 categories. Build your order sheet, download a PDF, and confirm via Instagram DM.", home_body(), HOME_EXTRA_SCRIPT),
    ("products.html", "products", "All Products", "Browse and filter our full catalog of 150+ products by category, brand, price, rating and discount.", products_body(), ""),
    ("product-details.html", "products", "Product Details", "View full product specifications, features, pricing and reviews.", product_details_body(), ""),
    ("categories.html", "categories", "Categories", "Browse Mech DesignHub products by category — electronics, fashion, home & kitchen, and more.", categories_body(), ""),
    ("about.html", "about", "About Us", "Learn about Mech DesignHub — a manually-verified, frontend-only dropshipping storefront.", about_body(), ""),
    ("contact.html", "contact", "Contact Us", "Get in touch with Mech DesignHub via Instagram DM, email, or our contact form.", contact_body(), ""),
    ("faq.html", "faq", "FAQ", "Frequently asked questions about ordering, delivery, payments and returns at Mech DesignHub.", faq_body(), ""),
    ("privacy.html", "privacy", "Privacy Policy", "How Mech DesignHub handles your information on this frontend-only storefront.", privacy_body(), ""),
    ("terms.html", "terms", "Terms & Conditions", "Terms and conditions for shopping at Mech DesignHub.", terms_body(), ""),
    ("404.html", "404", "Page Not Found", "The page you're looking for could not be found.", notfound_body(), ""),
    ("order-success.html", "success", "Order Sheet Generated", "Your order sheet has been generated. Download the PDF and send it to us on Instagram to confirm.", order_success_body(), ORDER_SUCCESS_SCRIPT),
]

for filename, key, title, desc, body, extra in pages:
    html = page_wrap(key, title, desc, body, extra)
    path = os.path.join(OUT, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Wrote {filename} ({len(html)} bytes)")
