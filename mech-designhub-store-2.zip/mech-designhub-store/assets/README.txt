Drop your own product photos, logo files, or other static images here, then
reference them in js/products-data.js (e.g. "assets/my-photo.jpg") or in the
PDF logo section of js/pdf-generator.js. The site currently uses placehold.co
placeholder images so it works immediately without any files in this folder.
