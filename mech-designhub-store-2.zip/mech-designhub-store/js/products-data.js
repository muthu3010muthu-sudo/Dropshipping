// Auto-generated demo product catalog for Mech DesignHub
const PRODUCTS = [
  {
    "id": "MDH-1042",
    "sku": "SKU104251",
    "name": "Urbanwear Track Pants",
    "brand": "Urbanwear",
    "category": "Fashion",
    "description": "Upgrade your routine with the Urbanwear Track Pants \u2014 thoughtfully crafted by Urbanwear to deliver consistent performance without compromising on design.",
    "features": [
      "Sleek modern design",
      "Compact and lightweight",
      "Easy to clean and maintain",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Urbanwear",
      "Model": "TRA-679",
      "Category": "Fashion",
      "Material": "High-Grade Polymer",
      "Color": "Blue",
      "Weight": "1.23 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 395,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 9999,
    "discount": 10,
    "price": 8999,
    "saved": 1000,
    "availability": "Only Few Left",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Track+Pants",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Track+Pants",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Track+Pants%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Track+Pants%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Track+Pants%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1138",
    "sku": "SKU113861",
    "name": "Motorix Tire Pressure Gauge",
    "brand": "Motorix",
    "category": "Automotive",
    "description": "Engineered for everyday reliability, the Motorix Tire Pressure Gauge combines thoughtful design with dependable performance, making it a smart addition to your automotive collection.",
    "features": [
      "1-year manufacturer support",
      "Adjustable settings",
      "Energy efficient design",
      "Premium build quality"
    ],
    "specifications": {
      "Brand": "Motorix",
      "Model": "TIR-302",
      "Category": "Automotive",
      "Material": "High-Grade Polymer",
      "Color": "White",
      "Weight": "5.29 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 277,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Tire+Pressure+Gauge",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Tire+Pressure+Gauge",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Tire+Pressure+Gauge%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Tire+Pressure+Gauge%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Tire+Pressure+Gauge%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1083",
    "sku": "SKU108351",
    "name": "Fitgear Table Tennis Kit",
    "brand": "Fitgear",
    "category": "Sports",
    "description": "Designed with the modern user in mind, the Fitgear Table Tennis Kit offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Water & dust resistant",
      "Adjustable settings",
      "Ergonomic and comfortable",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Fitgear",
      "Model": "TAB-619",
      "Category": "Sports",
      "Material": "Aluminum Alloy",
      "Color": "Navy",
      "Weight": "3.26 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 643,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 4999,
    "discount": 35,
    "price": 3249,
    "saved": 1750,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Table+Tennis+Kit",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Table+Tennis+Kit",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Table+Tennis+Kit%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Table+Tennis+Kit%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Table+Tennis+Kit%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1111",
    "sku": "SKU111160",
    "name": "Storyfield Children's Picture Book Set",
    "brand": "Storyfield",
    "category": "Books",
    "description": "Designed with the modern user in mind, the Storyfield Children's Picture Book Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Travel-friendly size",
      "Advanced safety features",
      "Noise-free smooth operation",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Storyfield",
      "Model": "CHI-485",
      "Category": "Books",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "2.47 kg",
      "Country of Origin": "India"
    },
    "rating": 4.6,
    "reviewsCount": 660,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 2499,
    "discount": 30,
    "price": 1749,
    "saved": 750,
    "availability": "Only Few Left",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Children's+Picture+Book+Set",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Children's+Picture+Book+Set",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Children's+Picture+Book+Set%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Children's+Picture+Book+Set%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Children's+Picture+Book+Set%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "trending"
    ]
  },
  {
    "id": "MDH-1135",
    "sku": "SKU113599",
    "name": "Gearhead Car Vacuum Cleaner",
    "brand": "Gearhead",
    "category": "Automotive",
    "description": "Upgrade your routine with the Gearhead Car Vacuum Cleaner \u2014 thoughtfully crafted by Gearhead to deliver consistent performance without compromising on design.",
    "features": [
      "Advanced safety features",
      "Energy efficient design",
      "Skin/eco-friendly materials",
      "Compact and lightweight"
    ],
    "specifications": {
      "Brand": "Gearhead",
      "Model": "CAR-176",
      "Category": "Automotive",
      "Material": "Aluminum Alloy",
      "Color": "Navy",
      "Weight": "0.55 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 98,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2499,
    "discount": 45,
    "price": 1374,
    "saved": 1125,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Car+Vacuum+Cleaner",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Vacuum+Cleaner",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Vacuum+Cleaner%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Vacuum+Cleaner%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Vacuum+Cleaner%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1064",
    "sku": "SKU106422",
    "name": "Purelle Perfume 100ml",
    "brand": "Purelle",
    "category": "Beauty",
    "description": "The Purelle Perfume 100ml from Purelle blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Premium build quality",
      "Multi-functional usage",
      "Long-lasting durability",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Purelle",
      "Model": "PER-711",
      "Category": "Beauty",
      "Material": "Cotton Blend",
      "Color": "Blue",
      "Weight": "1.18 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 551,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 3999,
    "discount": 50,
    "price": 2000,
    "saved": 1999,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Perfume+100ml",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Perfume+100ml",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Perfume+100ml%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Perfume+100ml%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Perfume+100ml%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "trending"
    ]
  },
  {
    "id": "MDH-1056",
    "sku": "SKU105687",
    "name": "Formaline Console Table",
    "brand": "Formaline",
    "category": "Furniture",
    "description": "Engineered for everyday reliability, the Formaline Console Table combines thoughtful design with dependable performance, making it a smart addition to your furniture collection.",
    "features": [
      "Skin/eco-friendly materials",
      "Energy efficient design",
      "Long-lasting durability",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Formaline",
      "Model": "CON-390",
      "Category": "Furniture",
      "Material": "High-Grade Polymer",
      "Color": "Charcoal",
      "Weight": "3.92 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 785,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 3499,
    "discount": 40,
    "price": 2099,
    "saved": 1400,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Console+Table",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Console+Table",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Console+Table%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Console+Table%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Console+Table%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1057",
    "sku": "SKU105747",
    "name": "Purelle Vitamin C Face Serum",
    "brand": "Purelle",
    "category": "Beauty",
    "description": "The Purelle Vitamin C Face Serum from Purelle blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Sleek modern design",
      "Compact and lightweight",
      "Adjustable settings",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Purelle",
      "Model": "VIT-612",
      "Category": "Beauty",
      "Material": "Aluminum Alloy",
      "Color": "Charcoal",
      "Weight": "5.27 kg",
      "Country of Origin": "India"
    },
    "rating": 3.6,
    "reviewsCount": 776,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Vitamin+C+Face+Serum",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Vitamin+C+Face+Serum",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Vitamin+C+Face+Serum%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Vitamin+C+Face+Serum%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Vitamin+C+Face+Serum%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1019",
    "sku": "SKU101951",
    "name": "Warmlyn Coffee Maker",
    "brand": "Warmlyn",
    "category": "Home & Kitchen",
    "description": "The Warmlyn Coffee Maker from Warmlyn blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Sleek modern design",
      "Multi-functional usage",
      "1-year manufacturer support",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Warmlyn",
      "Model": "COF-730",
      "Category": "Home & Kitchen",
      "Material": "Aluminum Alloy",
      "Color": "Graphite Grey",
      "Weight": "2.73 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 208,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2999,
    "discount": 30,
    "price": 2099,
    "saved": 900,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Coffee+Maker",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Coffee+Maker",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Coffee+Maker%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Coffee+Maker%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Coffee+Maker%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1026",
    "sku": "SKU102669",
    "name": "Kitchenora Table Lamp",
    "brand": "Kitchenora",
    "category": "Home & Kitchen",
    "description": "Engineered for everyday reliability, the Kitchenora Table Lamp combines thoughtful design with dependable performance, making it a smart addition to your home & kitchen collection.",
    "features": [
      "Advanced safety features",
      "1-year manufacturer support",
      "Water & dust resistant",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Kitchenora",
      "Model": "TAB-896",
      "Category": "Home & Kitchen",
      "Material": "Stainless Steel",
      "Color": "Graphite Grey",
      "Weight": "0.84 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 183,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 7999,
    "discount": 30,
    "price": 5599,
    "saved": 2400,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Table+Lamp",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Table+Lamp",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Table+Lamp%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Table+Lamp%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Table+Lamp%0A(View+4)"
    ],
    "badges": [
      "new"
    ]
  },
  {
    "id": "MDH-1003",
    "sku": "SKU100334",
    "name": "Kryonix Smart Watch",
    "brand": "Kryonix",
    "category": "Electronics",
    "description": "Engineered for everyday reliability, the Kryonix Smart Watch combines thoughtful design with dependable performance, making it a smart addition to your electronics collection.",
    "features": [
      "Noise-free smooth operation",
      "Ergonomic and comfortable",
      "Energy efficient design",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Kryonix",
      "Model": "SMA-489",
      "Category": "Electronics",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "4.19 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 245,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 7999,
    "discount": 15,
    "price": 6799,
    "saved": 1200,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Smart+Watch",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Watch",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Watch%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Watch%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Watch%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1126",
    "sku": "SKU112618",
    "name": "Papertone Desk Calendar Stand",
    "brand": "Papertone",
    "category": "Office Supplies",
    "description": "The Papertone Desk Calendar Stand from Papertone blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Travel-friendly size",
      "Long-lasting durability",
      "Water & dust resistant",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Papertone",
      "Model": "DES-521",
      "Category": "Office Supplies",
      "Material": "Aluminum Alloy",
      "Color": "Charcoal",
      "Weight": "2.96 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 180,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 3999,
    "discount": 10,
    "price": 3599,
    "saved": 400,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Desk+Calendar+Stand",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Desk+Calendar+Stand",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Desk+Calendar+Stand%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Desk+Calendar+Stand%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Desk+Calendar+Stand%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1035",
    "sku": "SKU103586",
    "name": "Urbanwear Canvas Sneakers",
    "brand": "Urbanwear",
    "category": "Fashion",
    "description": "Engineered for everyday reliability, the Urbanwear Canvas Sneakers combines thoughtful design with dependable performance, making it a smart addition to your fashion collection.",
    "features": [
      "Ergonomic and comfortable",
      "Premium build quality",
      "Energy efficient design",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Urbanwear",
      "Model": "CAN-883",
      "Category": "Fashion",
      "Material": "High-Grade Polymer",
      "Color": "Graphite Grey",
      "Weight": "3.81 kg",
      "Country of Origin": "India"
    },
    "rating": 4.6,
    "reviewsCount": 630,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 799,
    "discount": 40,
    "price": 479,
    "saved": 320,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Canvas+Sneakers",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Canvas+Sneakers",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Canvas+Sneakers%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Canvas+Sneakers%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Canvas+Sneakers%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller"
    ]
  },
  {
    "id": "MDH-1023",
    "sku": "SKU102369",
    "name": "Cookrite Knife Set 6-Piece",
    "brand": "Cookrite",
    "category": "Home & Kitchen",
    "description": "Engineered for everyday reliability, the Cookrite Knife Set 6-Piece combines thoughtful design with dependable performance, making it a smart addition to your home & kitchen collection.",
    "features": [
      "Sleek modern design",
      "Noise-free smooth operation",
      "Advanced safety features",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Cookrite",
      "Model": "KNI-977",
      "Category": "Home & Kitchen",
      "Material": "Aluminum Alloy",
      "Color": "White",
      "Weight": "3.18 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 442,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 2999,
    "discount": 10,
    "price": 2699,
    "saved": 300,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Knife+Set+6-Piece",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Knife+Set+6-Piece",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Knife+Set+6-Piece%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Knife+Set+6-Piece%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Knife+Set+6-Piece%0A(View+4)"
    ],
    "badges": [
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1120",
    "sku": "SKU112048",
    "name": "Storyfield Motivational Quotes Journal",
    "brand": "Storyfield",
    "category": "Books",
    "description": "The Storyfield Motivational Quotes Journal from Storyfield blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Energy efficient design",
      "Travel-friendly size",
      "1-year manufacturer support",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Storyfield",
      "Model": "MOT-930",
      "Category": "Books",
      "Material": "High-Grade Polymer",
      "Color": "Navy",
      "Weight": "4.53 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 848,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 799,
    "discount": 45,
    "price": 439,
    "saved": 360,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Motivational+Quotes+Journal",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Motivational+Quotes+Journal",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Motivational+Quotes+Journal%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Motivational+Quotes+Journal%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Motivational+Quotes+Journal%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1008",
    "sku": "SKU100867",
    "name": "Kryonix Mechanical Keyboard",
    "brand": "Kryonix",
    "category": "Electronics",
    "description": "The Kryonix Mechanical Keyboard from Kryonix blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Premium build quality",
      "Advanced safety features",
      "Skin/eco-friendly materials",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Kryonix",
      "Model": "MEC-107",
      "Category": "Electronics",
      "Material": "Premium ABS Plastic",
      "Color": "Charcoal",
      "Weight": "4.16 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 358,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 999,
    "discount": 25,
    "price": 749,
    "saved": 250,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Mechanical+Keyboard",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Mechanical+Keyboard",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Mechanical+Keyboard%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Mechanical+Keyboard%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Mechanical+Keyboard%0A(View+4)"
    ],
    "badges": [
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1156",
    "sku": "SKU115670",
    "name": "Pawsome Bird Cage Medium",
    "brand": "Pawsome",
    "category": "Pet Supplies",
    "description": "Designed with the modern user in mind, the Pawsome Bird Cage Medium offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Easy to clean and maintain",
      "Ergonomic and comfortable",
      "Advanced safety features",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Pawsome",
      "Model": "BIR-533",
      "Category": "Pet Supplies",
      "Material": "Cotton Blend",
      "Color": "Graphite Grey",
      "Weight": "3.06 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 20,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1249,
    "discount": 20,
    "price": 999,
    "saved": 250,
    "availability": "Only Few Left",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Bird+Cage+Medium",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Bird+Cage+Medium",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Bird+Cage+Medium%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Bird+Cage+Medium%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Bird+Cage+Medium%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1115",
    "sku": "SKU111512",
    "name": "Pageturn Press Productivity Planner Book",
    "brand": "Pageturn Press",
    "category": "Books",
    "description": "The Pageturn Press Productivity Planner Book from Pageturn Press blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "1-year manufacturer support",
      "Water & dust resistant",
      "Easy to clean and maintain",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Pageturn Press",
      "Model": "PRO-665",
      "Category": "Books",
      "Material": "Stainless Steel",
      "Color": "Graphite Grey",
      "Weight": "3.71 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 180,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "Only Few Left",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Productivity+Planner+Book",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Productivity+Planner+Book",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Productivity+Planner+Book%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Productivity+Planner+Book%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Productivity+Planner+Book%0A(View+4)"
    ],
    "badges": [
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1099",
    "sku": "SKU109978",
    "name": "Playnest Plush Teddy Bear",
    "brand": "Playnest",
    "category": "Toys",
    "description": "Engineered for everyday reliability, the Playnest Plush Teddy Bear combines thoughtful design with dependable performance, making it a smart addition to your toys collection.",
    "features": [
      "Multi-functional usage",
      "Advanced safety features",
      "Adjustable settings",
      "Premium build quality"
    ],
    "specifications": {
      "Brand": "Playnest",
      "Model": "PLU-292",
      "Category": "Toys",
      "Material": "Aluminum Alloy",
      "Color": "Charcoal",
      "Weight": "4.41 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 398,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 7999,
    "discount": 25,
    "price": 5999,
    "saved": 2000,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Plush+Teddy+Bear",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Plush+Teddy+Bear",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Plush+Teddy+Bear%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Plush+Teddy+Bear%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Plush+Teddy+Bear%0A(View+4)"
    ],
    "badges": [
      "new",
      "trending"
    ]
  },
  {
    "id": "MDH-1140",
    "sku": "SKU114041",
    "name": "Autolume Car Cover Waterproof",
    "brand": "Autolume",
    "category": "Automotive",
    "description": "Upgrade your routine with the Autolume Car Cover Waterproof \u2014 thoughtfully crafted by Autolume to deliver consistent performance without compromising on design.",
    "features": [
      "Noise-free smooth operation",
      "Water & dust resistant",
      "Long-lasting durability",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Autolume",
      "Model": "CAR-452",
      "Category": "Automotive",
      "Material": "Aluminum Alloy",
      "Color": "Navy",
      "Weight": "2.19 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 403,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 5999,
    "discount": 50,
    "price": 3000,
    "saved": 2999,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Car+Cover+Waterproof",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Cover+Waterproof",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Cover+Waterproof%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Cover+Waterproof%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Cover+Waterproof%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "new"
    ]
  },
  {
    "id": "MDH-1081",
    "sku": "SKU108146",
    "name": "Athlex Camping Tent 2-Person",
    "brand": "Athlex",
    "category": "Sports",
    "description": "Designed with the modern user in mind, the Athlex Camping Tent 2-Person offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Adjustable settings",
      "Energy efficient design",
      "Sleek modern design",
      "Compact and lightweight"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "CAM-844",
      "Category": "Sports",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "2.47 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 20,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 3499,
    "discount": 45,
    "price": 1924,
    "saved": 1575,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Camping+Tent+2-Person",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Camping+Tent+2-Person",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Camping+Tent+2-Person%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Camping+Tent+2-Person%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Camping+Tent+2-Person%0A(View+4)"
    ],
    "badges": [
      "deal",
      "featured"
    ]
  },
  {
    "id": "MDH-1080",
    "sku": "SKU108016",
    "name": "Athlex Fitness Tracker Band",
    "brand": "Athlex",
    "category": "Sports",
    "description": "Designed with the modern user in mind, the Athlex Fitness Tracker Band offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Easy to clean and maintain",
      "Adjustable settings",
      "Compact and lightweight",
      "Long-lasting durability"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "FIT-294",
      "Category": "Sports",
      "Material": "Stainless Steel",
      "Color": "White",
      "Weight": "6.47 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 440,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1999,
    "discount": 40,
    "price": 1199,
    "saved": 800,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Fitness+Tracker+Band",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Fitness+Tracker+Band",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Fitness+Tracker+Band%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Fitness+Tracker+Band%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Fitness+Tracker+Band%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "trending"
    ]
  },
  {
    "id": "MDH-1047",
    "sku": "SKU104799",
    "name": "Formaline Wooden Coffee Table",
    "brand": "Formaline",
    "category": "Furniture",
    "description": "Engineered for everyday reliability, the Formaline Wooden Coffee Table combines thoughtful design with dependable performance, making it a smart addition to your furniture collection.",
    "features": [
      "Premium build quality",
      "Ergonomic and comfortable",
      "Travel-friendly size",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Formaline",
      "Model": "WOO-340",
      "Category": "Furniture",
      "Material": "Aluminum Alloy",
      "Color": "Blue",
      "Weight": "2.62 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 58,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 1999,
    "discount": 40,
    "price": 1199,
    "saved": 800,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Wooden+Coffee+Table",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wooden+Coffee+Table",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wooden+Coffee+Table%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wooden+Coffee+Table%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wooden+Coffee+Table%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1145",
    "sku": "SKU114595",
    "name": "Pawsome Dog Leash & Collar Set",
    "brand": "Pawsome",
    "category": "Pet Supplies",
    "description": "Designed with the modern user in mind, the Pawsome Dog Leash & Collar Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Easy to clean and maintain",
      "1-year manufacturer support",
      "Water & dust resistant",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Pawsome",
      "Model": "DOG-362",
      "Category": "Pet Supplies",
      "Material": "Premium ABS Plastic",
      "Color": "Charcoal",
      "Weight": "0.16 kg",
      "Country of Origin": "India"
    },
    "rating": 4.2,
    "reviewsCount": 283,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 5999,
    "discount": 35,
    "price": 3899,
    "saved": 2100,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Dog+Leash+&+Collar+Set",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Leash+&+Collar+Set",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Leash+&+Collar+Set%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Leash+&+Collar+Set%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Leash+&+Collar+Set%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1045",
    "sku": "SKU104551",
    "name": "Restly Bookshelf 5-Tier",
    "brand": "Restly",
    "category": "Furniture",
    "description": "Designed with the modern user in mind, the Restly Bookshelf 5-Tier offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Noise-free smooth operation",
      "Skin/eco-friendly materials",
      "Long-lasting durability",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Restly",
      "Model": "BOO-950",
      "Category": "Furniture",
      "Material": "Stainless Steel",
      "Color": "Graphite Grey",
      "Weight": "5.95 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 147,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 7999,
    "discount": 40,
    "price": 4799,
    "saved": 3200,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Bookshelf+5-Tier",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bookshelf+5-Tier",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bookshelf+5-Tier%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bookshelf+5-Tier%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bookshelf+5-Tier%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending"
    ]
  },
  {
    "id": "MDH-1002",
    "sku": "SKU100299",
    "name": "Nexowave Bluetooth Speaker",
    "brand": "Nexowave",
    "category": "Electronics",
    "description": "Upgrade your routine with the Nexowave Bluetooth Speaker \u2014 thoughtfully crafted by Nexowave to deliver consistent performance without compromising on design.",
    "features": [
      "Noise-free smooth operation",
      "Long-lasting durability",
      "Energy efficient design",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Nexowave",
      "Model": "BLU-199",
      "Category": "Electronics",
      "Material": "Engineered Wood",
      "Color": "Graphite Grey",
      "Weight": "3.98 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 232,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 2999,
    "discount": 35,
    "price": 1949,
    "saved": 1050,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Speaker",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Speaker",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Speaker%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Speaker%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Speaker%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1106",
    "sku": "SKU110619",
    "name": "Blockzy Art & Craft Kit",
    "brand": "Blockzy",
    "category": "Toys",
    "description": "Designed with the modern user in mind, the Blockzy Art & Craft Kit offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Adjustable settings",
      "1-year manufacturer support",
      "Sleek modern design",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Blockzy",
      "Model": "ART-493",
      "Category": "Toys",
      "Material": "High-Grade Polymer",
      "Color": "Blue",
      "Weight": "5.17 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 592,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1999,
    "discount": 20,
    "price": 1599,
    "saved": 400,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Art+&+Craft+Kit",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Art+&+Craft+Kit",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Art+&+Craft+Kit%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Art+&+Craft+Kit%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Art+&+Craft+Kit%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1031",
    "sku": "SKU103145",
    "name": "Threadloom Running Shoes",
    "brand": "Threadloom",
    "category": "Fashion",
    "description": "Engineered for everyday reliability, the Threadloom Running Shoes combines thoughtful design with dependable performance, making it a smart addition to your fashion collection.",
    "features": [
      "Compact and lightweight",
      "Multi-functional usage",
      "Noise-free smooth operation",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Threadloom",
      "Model": "RUN-993",
      "Category": "Fashion",
      "Material": "Premium ABS Plastic",
      "Color": "Navy",
      "Weight": "1.96 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 726,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 799,
    "discount": 10,
    "price": 719,
    "saved": 80,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Running+Shoes",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Running+Shoes",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Running+Shoes%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Running+Shoes%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Running+Shoes%0A(View+4)"
    ],
    "badges": [
      "new",
      "trending"
    ]
  },
  {
    "id": "MDH-1070",
    "sku": "SKU107097",
    "name": "Lumina Face Wash Combo",
    "brand": "Lumina",
    "category": "Beauty",
    "description": "Engineered for everyday reliability, the Lumina Face Wash Combo combines thoughtful design with dependable performance, making it a smart addition to your beauty collection.",
    "features": [
      "Compact and lightweight",
      "Energy efficient design",
      "Water & dust resistant",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Lumina",
      "Model": "FAC-400",
      "Category": "Beauty",
      "Material": "Stainless Steel",
      "Color": "Black",
      "Weight": "5.17 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 842,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 3499,
    "discount": 45,
    "price": 1924,
    "saved": 1575,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Face+Wash+Combo",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Face+Wash+Combo",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Face+Wash+Combo%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Face+Wash+Combo%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Face+Wash+Combo%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending"
    ]
  },
  {
    "id": "MDH-1148",
    "sku": "SKU114835",
    "name": "Wagwell Automatic Pet Feeder",
    "brand": "Wagwell",
    "category": "Pet Supplies",
    "description": "Designed with the modern user in mind, the Wagwell Automatic Pet Feeder offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Ergonomic and comfortable",
      "Energy efficient design",
      "Travel-friendly size",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Wagwell",
      "Model": "AUT-903",
      "Category": "Pet Supplies",
      "Material": "Cotton Blend",
      "Color": "White",
      "Weight": "3.26 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 665,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 999,
    "discount": 10,
    "price": 899,
    "saved": 100,
    "availability": "Only Few Left",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Automatic+Pet+Feeder",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Automatic+Pet+Feeder",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Automatic+Pet+Feeder%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Automatic+Pet+Feeder%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Automatic+Pet+Feeder%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1139",
    "sku": "SKU113913",
    "name": "Gearhead Dashboard Camera",
    "brand": "Gearhead",
    "category": "Automotive",
    "description": "Upgrade your routine with the Gearhead Dashboard Camera \u2014 thoughtfully crafted by Gearhead to deliver consistent performance without compromising on design.",
    "features": [
      "1-year manufacturer support",
      "Compact and lightweight",
      "Ergonomic and comfortable",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Gearhead",
      "Model": "DAS-252",
      "Category": "Automotive",
      "Material": "Premium ABS Plastic",
      "Color": "Navy",
      "Weight": "4.08 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 231,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 2999,
    "discount": 40,
    "price": 1799,
    "saved": 1200,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Dashboard+Camera",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Dashboard+Camera",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Dashboard+Camera%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Dashboard+Camera%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Dashboard+Camera%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1033",
    "sku": "SKU103336",
    "name": "Urbanwear Winter Hoodie",
    "brand": "Urbanwear",
    "category": "Fashion",
    "description": "Engineered for everyday reliability, the Urbanwear Winter Hoodie combines thoughtful design with dependable performance, making it a smart addition to your fashion collection.",
    "features": [
      "Compact and lightweight",
      "Easy to clean and maintain",
      "1-year manufacturer support",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Urbanwear",
      "Model": "WIN-260",
      "Category": "Fashion",
      "Material": "Premium ABS Plastic",
      "Color": "White",
      "Weight": "3.01 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 95,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 5999,
    "discount": 25,
    "price": 4499,
    "saved": 1500,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Winter+Hoodie",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Winter+Hoodie",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Winter+Hoodie%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Winter+Hoodie%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Winter+Hoodie%0A(View+4)"
    ],
    "badges": [
      "new",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1151",
    "sku": "SKU115181",
    "name": "Wagwell Cat Litter Box",
    "brand": "Wagwell",
    "category": "Pet Supplies",
    "description": "Upgrade your routine with the Wagwell Cat Litter Box \u2014 thoughtfully crafted by Wagwell to deliver consistent performance without compromising on design.",
    "features": [
      "Skin/eco-friendly materials",
      "Travel-friendly size",
      "Premium build quality",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Wagwell",
      "Model": "CAT-215",
      "Category": "Pet Supplies",
      "Material": "Cotton Blend",
      "Color": "Blue",
      "Weight": "1.09 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 294,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 2999,
    "discount": 50,
    "price": 1500,
    "saved": 1499,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Cat+Litter+Box",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Litter+Box",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Litter+Box%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Litter+Box%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Litter+Box%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending"
    ]
  },
  {
    "id": "MDH-1063",
    "sku": "SKU106326",
    "name": "Skinova Moisturizing Cream",
    "brand": "Skinova",
    "category": "Beauty",
    "description": "Engineered for everyday reliability, the Skinova Moisturizing Cream combines thoughtful design with dependable performance, making it a smart addition to your beauty collection.",
    "features": [
      "Multi-functional usage",
      "Noise-free smooth operation",
      "Long-lasting durability",
      "Compact and lightweight"
    ],
    "specifications": {
      "Brand": "Skinova",
      "Model": "MOI-761",
      "Category": "Beauty",
      "Material": "High-Grade Polymer",
      "Color": "White",
      "Weight": "3.38 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 397,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 4999,
    "discount": 15,
    "price": 4249,
    "saved": 750,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Moisturizing+Cream",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Moisturizing+Cream",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Moisturizing+Cream%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Moisturizing+Cream%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Moisturizing+Cream%0A(View+4)"
    ],
    "badges": [
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1051",
    "sku": "SKU105164",
    "name": "Formaline Wardrobe 3-Door",
    "brand": "Formaline",
    "category": "Furniture",
    "description": "The Formaline Wardrobe 3-Door from Formaline blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Energy efficient design",
      "1-year manufacturer support",
      "Long-lasting durability",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Formaline",
      "Model": "WAR-167",
      "Category": "Furniture",
      "Material": "Stainless Steel",
      "Color": "Graphite Grey",
      "Weight": "4.11 kg",
      "Country of Origin": "India"
    },
    "rating": 4.3,
    "reviewsCount": 466,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 5999,
    "discount": 15,
    "price": 5099,
    "saved": 900,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Wardrobe+3-Door",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wardrobe+3-Door",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wardrobe+3-Door%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wardrobe+3-Door%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wardrobe+3-Door%0A(View+4)"
    ],
    "badges": [
      "new"
    ]
  },
  {
    "id": "MDH-1052",
    "sku": "SKU105237",
    "name": "Oakstead Recliner Sofa Chair",
    "brand": "Oakstead",
    "category": "Furniture",
    "description": "Upgrade your routine with the Oakstead Recliner Sofa Chair \u2014 thoughtfully crafted by Oakstead to deliver consistent performance without compromising on design.",
    "features": [
      "Long-lasting durability",
      "Adjustable settings",
      "Travel-friendly size",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Oakstead",
      "Model": "REC-847",
      "Category": "Furniture",
      "Material": "Premium ABS Plastic",
      "Color": "Graphite Grey",
      "Weight": "2.86 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 435,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2999,
    "discount": 45,
    "price": 1649,
    "saved": 1350,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Recliner+Sofa+Chair",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Recliner+Sofa+Chair",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Recliner+Sofa+Chair%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Recliner+Sofa+Chair%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Recliner+Sofa+Chair%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1131",
    "sku": "SKU113113",
    "name": "Deskly Highlighter Set",
    "brand": "Deskly",
    "category": "Office Supplies",
    "description": "Engineered for everyday reliability, the Deskly Highlighter Set combines thoughtful design with dependable performance, making it a smart addition to your office supplies collection.",
    "features": [
      "Ergonomic and comfortable",
      "Water & dust resistant",
      "Advanced safety features",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Deskly",
      "Model": "HIG-608",
      "Category": "Office Supplies",
      "Material": "Cotton Blend",
      "Color": "Navy",
      "Weight": "2.44 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 77,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 2499,
    "discount": 40,
    "price": 1499,
    "saved": 1000,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Highlighter+Set",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Highlighter+Set",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Highlighter+Set%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Highlighter+Set%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Highlighter+Set%0A(View+4)"
    ],
    "badges": [
      "deal",
      "featured"
    ]
  },
  {
    "id": "MDH-1059",
    "sku": "SKU105977",
    "name": "Glowvana Electric Trimmer",
    "brand": "Glowvana",
    "category": "Beauty",
    "description": "The Glowvana Electric Trimmer from Glowvana blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Long-lasting durability",
      "Water & dust resistant",
      "Multi-functional usage",
      "Compact and lightweight"
    ],
    "specifications": {
      "Brand": "Glowvana",
      "Model": "ELE-205",
      "Category": "Beauty",
      "Material": "Stainless Steel",
      "Color": "Graphite Grey",
      "Weight": "1.4 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 369,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 3999,
    "discount": 25,
    "price": 2999,
    "saved": 1000,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Electric+Trimmer",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Electric+Trimmer",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Electric+Trimmer%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Electric+Trimmer%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Electric+Trimmer%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1011",
    "sku": "SKU101146",
    "name": "Byteon LED Desk Lamp",
    "brand": "Byteon",
    "category": "Electronics",
    "description": "Engineered for everyday reliability, the Byteon LED Desk Lamp combines thoughtful design with dependable performance, making it a smart addition to your electronics collection.",
    "features": [
      "Compact and lightweight",
      "Easy to clean and maintain",
      "Ergonomic and comfortable",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Byteon",
      "Model": "LED-693",
      "Category": "Electronics",
      "Material": "High-Grade Polymer",
      "Color": "Navy",
      "Weight": "0.54 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 510,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2999,
    "discount": 50,
    "price": 1500,
    "saved": 1499,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=LED+Desk+Lamp",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=LED+Desk+Lamp",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=LED+Desk+Lamp%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=LED+Desk+Lamp%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=LED+Desk+Lamp%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1014",
    "sku": "SKU101444",
    "name": "Nexowave Smart Plug Wi-Fi",
    "brand": "Nexowave",
    "category": "Electronics",
    "description": "Upgrade your routine with the Nexowave Smart Plug Wi-Fi \u2014 thoughtfully crafted by Nexowave to deliver consistent performance without compromising on design.",
    "features": [
      "Multi-functional usage",
      "1-year manufacturer support",
      "Ergonomic and comfortable",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Nexowave",
      "Model": "SMA-357",
      "Category": "Electronics",
      "Material": "Premium ABS Plastic",
      "Color": "Black",
      "Weight": "4.18 kg",
      "Country of Origin": "India"
    },
    "rating": 4.6,
    "reviewsCount": 220,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1999,
    "discount": 25,
    "price": 1499,
    "saved": 500,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Smart+Plug+Wi-Fi",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Plug+Wi-Fi",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Plug+Wi-Fi%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Plug+Wi-Fi%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Smart+Plug+Wi-Fi%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1018",
    "sku": "SKU101887",
    "name": "Warmlyn Blender 700W",
    "brand": "Warmlyn",
    "category": "Home & Kitchen",
    "description": "Upgrade your routine with the Warmlyn Blender 700W \u2014 thoughtfully crafted by Warmlyn to deliver consistent performance without compromising on design.",
    "features": [
      "Easy to clean and maintain",
      "Ergonomic and comfortable",
      "Premium build quality",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Warmlyn",
      "Model": "BLE-101",
      "Category": "Home & Kitchen",
      "Material": "Aluminum Alloy",
      "Color": "Navy",
      "Weight": "4.51 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 602,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 3999,
    "discount": 15,
    "price": 3399,
    "saved": 600,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Blender+700W",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Blender+700W",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Blender+700W%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Blender+700W%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Blender+700W%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1094",
    "sku": "SKU109484",
    "name": "Straplyn Keychain Multi-tool",
    "brand": "Straplyn",
    "category": "Accessories",
    "description": "Upgrade your routine with the Straplyn Keychain Multi-tool \u2014 thoughtfully crafted by Straplyn to deliver consistent performance without compromising on design.",
    "features": [
      "Energy efficient design",
      "Skin/eco-friendly materials",
      "Premium build quality",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Straplyn",
      "Model": "KEY-132",
      "Category": "Accessories",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "1.29 kg",
      "Country of Origin": "India"
    },
    "rating": 4.2,
    "reviewsCount": 729,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 999,
    "discount": 10,
    "price": 899,
    "saved": 100,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Keychain+Multi-tool",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Keychain+Multi-tool",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Keychain+Multi-tool%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Keychain+Multi-tool%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Keychain+Multi-tool%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1001",
    "sku": "SKU100113",
    "name": "Voltrix Wireless Earbuds",
    "brand": "Voltrix",
    "category": "Electronics",
    "description": "Engineered for everyday reliability, the Voltrix Wireless Earbuds combines thoughtful design with dependable performance, making it a smart addition to your electronics collection.",
    "features": [
      "Water & dust resistant",
      "Energy efficient design",
      "Multi-functional usage",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Voltrix",
      "Model": "WIR-704",
      "Category": "Electronics",
      "Material": "Cotton Blend",
      "Color": "Black",
      "Weight": "0.34 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 154,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 7999,
    "discount": 30,
    "price": 5599,
    "saved": 2400,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Wireless+Earbuds",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Earbuds",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Earbuds%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Earbuds%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Earbuds%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1004",
    "sku": "SKU100491",
    "name": "Zentek Noise Cancelling Headphones",
    "brand": "Zentek",
    "category": "Electronics",
    "description": "The Zentek Noise Cancelling Headphones from Zentek blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Adjustable settings",
      "Noise-free smooth operation",
      "1-year manufacturer support",
      "Premium build quality"
    ],
    "specifications": {
      "Brand": "Zentek",
      "Model": "NOI-941",
      "Category": "Electronics",
      "Material": "Premium ABS Plastic",
      "Color": "Graphite Grey",
      "Weight": "2.7 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 344,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 7999,
    "discount": 50,
    "price": 4000,
    "saved": 3999,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Noise+Cancelling+Headphones",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Noise+Cancelling+Headphones",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Noise+Cancelling+Headphones%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Noise+Cancelling+Headphones%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Noise+Cancelling+Headphones%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new",
      "trending"
    ]
  },
  {
    "id": "MDH-1118",
    "sku": "SKU111881",
    "name": "Storyfield Science Fiction Novel",
    "brand": "Storyfield",
    "category": "Books",
    "description": "Engineered for everyday reliability, the Storyfield Science Fiction Novel combines thoughtful design with dependable performance, making it a smart addition to your books collection.",
    "features": [
      "Long-lasting durability",
      "Adjustable settings",
      "Travel-friendly size",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Storyfield",
      "Model": "SCI-986",
      "Category": "Books",
      "Material": "Engineered Wood",
      "Color": "Black",
      "Weight": "3.23 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 203,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1249,
    "discount": 45,
    "price": 687,
    "saved": 562,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Science+Fiction+Novel",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Science+Fiction+Novel",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Science+Fiction+Novel%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Science+Fiction+Novel%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Science+Fiction+Novel%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1055",
    "sku": "SKU105591",
    "name": "Framewell Shoe Cabinet",
    "brand": "Framewell",
    "category": "Furniture",
    "description": "The Framewell Shoe Cabinet from Framewell blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Sleek modern design",
      "1-year manufacturer support",
      "Travel-friendly size",
      "Long-lasting durability"
    ],
    "specifications": {
      "Brand": "Framewell",
      "Model": "SHO-478",
      "Category": "Furniture",
      "Material": "Engineered Wood",
      "Color": "Charcoal",
      "Weight": "2.21 kg",
      "Country of Origin": "India"
    },
    "rating": 4.6,
    "reviewsCount": 232,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 799,
    "discount": 15,
    "price": 679,
    "saved": 120,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Shoe+Cabinet",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Cabinet",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Cabinet%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Cabinet%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Cabinet%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "trending"
    ]
  },
  {
    "id": "MDH-1066",
    "sku": "SKU106676",
    "name": "Glowvana LED Makeup Mirror",
    "brand": "Glowvana",
    "category": "Beauty",
    "description": "Upgrade your routine with the Glowvana LED Makeup Mirror \u2014 thoughtfully crafted by Glowvana to deliver consistent performance without compromising on design.",
    "features": [
      "Ergonomic and comfortable",
      "Travel-friendly size",
      "Skin/eco-friendly materials",
      "Compact and lightweight"
    ],
    "specifications": {
      "Brand": "Glowvana",
      "Model": "LED-193",
      "Category": "Beauty",
      "Material": "Stainless Steel",
      "Color": "White",
      "Weight": "5.77 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 176,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 999,
    "discount": 30,
    "price": 699,
    "saved": 300,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=LED+Makeup+Mirror",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=LED+Makeup+Mirror",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=LED+Makeup+Mirror%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=LED+Makeup+Mirror%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=LED+Makeup+Mirror%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1041",
    "sku": "SKU104193",
    "name": "Clothcraft Polo T-Shirt",
    "brand": "Clothcraft",
    "category": "Fashion",
    "description": "Upgrade your routine with the Clothcraft Polo T-Shirt \u2014 thoughtfully crafted by Clothcraft to deliver consistent performance without compromising on design.",
    "features": [
      "Sleek modern design",
      "Long-lasting durability",
      "Multi-functional usage",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Clothcraft",
      "Model": "POL-993",
      "Category": "Fashion",
      "Material": "Aluminum Alloy",
      "Color": "Black",
      "Weight": "4.07 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 558,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 999,
    "discount": 35,
    "price": 649,
    "saved": 350,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Polo+T-Shirt",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Polo+T-Shirt",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Polo+T-Shirt%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Polo+T-Shirt%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Polo+T-Shirt%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller"
    ]
  },
  {
    "id": "MDH-1154",
    "sku": "SKU115482",
    "name": "Barkbox Aquarium Filter Pump",
    "brand": "Barkbox",
    "category": "Pet Supplies",
    "description": "Engineered for everyday reliability, the Barkbox Aquarium Filter Pump combines thoughtful design with dependable performance, making it a smart addition to your pet supplies collection.",
    "features": [
      "Easy to clean and maintain",
      "Adjustable settings",
      "Premium build quality",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Barkbox",
      "Model": "AQU-567",
      "Category": "Pet Supplies",
      "Material": "Premium ABS Plastic",
      "Color": "Graphite Grey",
      "Weight": "4.62 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 864,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 799,
    "discount": 20,
    "price": 639,
    "saved": 160,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Aquarium+Filter+Pump",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Aquarium+Filter+Pump",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Aquarium+Filter+Pump%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Aquarium+Filter+Pump%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Aquarium+Filter+Pump%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1032",
    "sku": "SKU103290",
    "name": "Draperie Leather Wallet",
    "brand": "Draperie",
    "category": "Fashion",
    "description": "Engineered for everyday reliability, the Draperie Leather Wallet combines thoughtful design with dependable performance, making it a smart addition to your fashion collection.",
    "features": [
      "Advanced safety features",
      "Ergonomic and comfortable",
      "Energy efficient design",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Draperie",
      "Model": "LEA-671",
      "Category": "Fashion",
      "Material": "Cotton Blend",
      "Color": "Navy",
      "Weight": "3.94 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 842,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 5999,
    "discount": 10,
    "price": 5399,
    "saved": 600,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Leather+Wallet",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Leather+Wallet",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Leather+Wallet%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Leather+Wallet%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Leather+Wallet%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1006",
    "sku": "SKU100692",
    "name": "Zentek Fast Charger 65W",
    "brand": "Zentek",
    "category": "Electronics",
    "description": "Designed with the modern user in mind, the Zentek Fast Charger 65W offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Travel-friendly size",
      "Premium build quality",
      "Water & dust resistant",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Zentek",
      "Model": "FAS-612",
      "Category": "Electronics",
      "Material": "Stainless Steel",
      "Color": "Navy",
      "Weight": "5.95 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 173,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Fast+Charger+65W",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Fast+Charger+65W",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Fast+Charger+65W%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Fast+Charger+65W%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Fast+Charger+65W%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1050",
    "sku": "SKU105012",
    "name": "Restly Shoe Rack Organizer",
    "brand": "Restly",
    "category": "Furniture",
    "description": "Engineered for everyday reliability, the Restly Shoe Rack Organizer combines thoughtful design with dependable performance, making it a smart addition to your furniture collection.",
    "features": [
      "Sleek modern design",
      "Skin/eco-friendly materials",
      "Energy efficient design",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Restly",
      "Model": "SHO-587",
      "Category": "Furniture",
      "Material": "Cotton Blend",
      "Color": "Graphite Grey",
      "Weight": "3.41 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 771,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 1249,
    "discount": 30,
    "price": 874,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Shoe+Rack+Organizer",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Rack+Organizer",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Rack+Organizer%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Rack+Organizer%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Shoe+Rack+Organizer%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1150",
    "sku": "SKU115014",
    "name": "Wagwell Pet Grooming Kit",
    "brand": "Wagwell",
    "category": "Pet Supplies",
    "description": "The Wagwell Pet Grooming Kit from Wagwell blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Advanced safety features",
      "Compact and lightweight",
      "Energy efficient design",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Wagwell",
      "Model": "PET-271",
      "Category": "Pet Supplies",
      "Material": "Stainless Steel",
      "Color": "Blue",
      "Weight": "0.95 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 705,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 3999,
    "discount": 50,
    "price": 2000,
    "saved": 1999,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Pet+Grooming+Kit",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Grooming+Kit",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Grooming+Kit%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Grooming+Kit%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Grooming+Kit%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1089",
    "sku": "SKU108963",
    "name": "Straplyn Analog Wrist Watch",
    "brand": "Straplyn",
    "category": "Accessories",
    "description": "Designed with the modern user in mind, the Straplyn Analog Wrist Watch offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Noise-free smooth operation",
      "Travel-friendly size",
      "Compact and lightweight",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Straplyn",
      "Model": "ANA-997",
      "Category": "Accessories",
      "Material": "Premium ABS Plastic",
      "Color": "Black",
      "Weight": "2.04 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 418,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1249,
    "discount": 10,
    "price": 1124,
    "saved": 125,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Analog+Wrist+Watch",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Analog+Wrist+Watch",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Analog+Wrist+Watch%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Analog+Wrist+Watch%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Analog+Wrist+Watch%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1021",
    "sku": "SKU102164",
    "name": "Hearthly Vacuum Flask Set",
    "brand": "Hearthly",
    "category": "Home & Kitchen",
    "description": "The Hearthly Vacuum Flask Set from Hearthly blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Skin/eco-friendly materials",
      "Travel-friendly size",
      "Premium build quality",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Hearthly",
      "Model": "VAC-968",
      "Category": "Home & Kitchen",
      "Material": "Premium ABS Plastic",
      "Color": "White",
      "Weight": "1.0 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 724,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1499,
    "discount": 20,
    "price": 1199,
    "saved": 300,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Vacuum+Flask+Set",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Vacuum+Flask+Set",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Vacuum+Flask+Set%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Vacuum+Flask+Set%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Vacuum+Flask+Set%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1123",
    "sku": "SKU112337",
    "name": "Notewell Gel Pen Set",
    "brand": "Notewell",
    "category": "Office Supplies",
    "description": "Upgrade your routine with the Notewell Gel Pen Set \u2014 thoughtfully crafted by Notewell to deliver consistent performance without compromising on design.",
    "features": [
      "Long-lasting durability",
      "Skin/eco-friendly materials",
      "Advanced safety features",
      "Compact and lightweight"
    ],
    "specifications": {
      "Brand": "Notewell",
      "Model": "GEL-907",
      "Category": "Office Supplies",
      "Material": "Engineered Wood",
      "Color": "Charcoal",
      "Weight": "4.99 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 302,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 3499,
    "discount": 30,
    "price": 2449,
    "saved": 1050,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Gel+Pen+Set",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Gel+Pen+Set",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Gel+Pen+Set%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Gel+Pen+Set%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Gel+Pen+Set%0A(View+4)"
    ],
    "badges": [
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1030",
    "sku": "SKU103050",
    "name": "Threadloom Slim Fit Jeans",
    "brand": "Threadloom",
    "category": "Fashion",
    "description": "Upgrade your routine with the Threadloom Slim Fit Jeans \u2014 thoughtfully crafted by Threadloom to deliver consistent performance without compromising on design.",
    "features": [
      "Compact and lightweight",
      "Easy to clean and maintain",
      "Adjustable settings",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Threadloom",
      "Model": "SLI-383",
      "Category": "Fashion",
      "Material": "High-Grade Polymer",
      "Color": "Navy",
      "Weight": "6.35 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 718,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 999,
    "discount": 50,
    "price": 500,
    "saved": 499,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Slim+Fit+Jeans",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Slim+Fit+Jeans",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Slim+Fit+Jeans%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Slim+Fit+Jeans%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Slim+Fit+Jeans%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller"
    ]
  },
  {
    "id": "MDH-1058",
    "sku": "SKU105847",
    "name": "Skinova Hair Dryer 1800W",
    "brand": "Skinova",
    "category": "Beauty",
    "description": "Designed with the modern user in mind, the Skinova Hair Dryer 1800W offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Compact and lightweight",
      "Noise-free smooth operation",
      "Advanced safety features",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Skinova",
      "Model": "HAI-190",
      "Category": "Beauty",
      "Material": "Cotton Blend",
      "Color": "Black",
      "Weight": "1.7 kg",
      "Country of Origin": "India"
    },
    "rating": 3.6,
    "reviewsCount": 344,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 999,
    "discount": 40,
    "price": 599,
    "saved": 400,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Hair+Dryer+1800W",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Dryer+1800W",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Dryer+1800W%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Dryer+1800W%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Dryer+1800W%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending"
    ]
  },
  {
    "id": "MDH-1037",
    "sku": "SKU103716",
    "name": "Clothcraft Denim Jacket",
    "brand": "Clothcraft",
    "category": "Fashion",
    "description": "Engineered for everyday reliability, the Clothcraft Denim Jacket combines thoughtful design with dependable performance, making it a smart addition to your fashion collection.",
    "features": [
      "Travel-friendly size",
      "Water & dust resistant",
      "1-year manufacturer support",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Clothcraft",
      "Model": "DEN-745",
      "Category": "Fashion",
      "Material": "Aluminum Alloy",
      "Color": "Blue",
      "Weight": "4.66 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 306,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 1499,
    "discount": 30,
    "price": 1049,
    "saved": 450,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Denim+Jacket",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Denim+Jacket",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Denim+Jacket%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Denim+Jacket%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Denim+Jacket%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1027",
    "sku": "SKU102725",
    "name": "Cookrite Induction Cooktop",
    "brand": "Cookrite",
    "category": "Home & Kitchen",
    "description": "Designed with the modern user in mind, the Cookrite Induction Cooktop offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Multi-functional usage",
      "Long-lasting durability",
      "Energy efficient design",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Cookrite",
      "Model": "IND-112",
      "Category": "Home & Kitchen",
      "Material": "Cotton Blend",
      "Color": "White",
      "Weight": "0.82 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 450,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 9999,
    "discount": 10,
    "price": 8999,
    "saved": 1000,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Induction+Cooktop",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Induction+Cooktop",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Induction+Cooktop%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Induction+Cooktop%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Induction+Cooktop%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1107",
    "sku": "SKU110751",
    "name": "Blockzy Musical Toy Piano",
    "brand": "Blockzy",
    "category": "Toys",
    "description": "Upgrade your routine with the Blockzy Musical Toy Piano \u2014 thoughtfully crafted by Blockzy to deliver consistent performance without compromising on design.",
    "features": [
      "Travel-friendly size",
      "Easy to clean and maintain",
      "Long-lasting durability",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Blockzy",
      "Model": "MUS-542",
      "Category": "Toys",
      "Material": "Stainless Steel",
      "Color": "Charcoal",
      "Weight": "3.87 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 473,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 799,
    "discount": 30,
    "price": 559,
    "saved": 240,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Musical+Toy+Piano",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Musical+Toy+Piano",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Musical+Toy+Piano%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Musical+Toy+Piano%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Musical+Toy+Piano%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new"
    ]
  },
  {
    "id": "MDH-1102",
    "sku": "SKU110272",
    "name": "Wondertoy Action Figure Set",
    "brand": "Wondertoy",
    "category": "Toys",
    "description": "Engineered for everyday reliability, the Wondertoy Action Figure Set combines thoughtful design with dependable performance, making it a smart addition to your toys collection.",
    "features": [
      "Skin/eco-friendly materials",
      "Premium build quality",
      "Energy efficient design",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Wondertoy",
      "Model": "ACT-882",
      "Category": "Toys",
      "Material": "Premium ABS Plastic",
      "Color": "White",
      "Weight": "1.02 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 72,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 1249,
    "discount": 50,
    "price": 624,
    "saved": 625,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Action+Figure+Set",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Action+Figure+Set",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Action+Figure+Set%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Action+Figure+Set%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Action+Figure+Set%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1009",
    "sku": "SKU100983",
    "name": "Kryonix Wireless Mouse",
    "brand": "Kryonix",
    "category": "Electronics",
    "description": "Upgrade your routine with the Kryonix Wireless Mouse \u2014 thoughtfully crafted by Kryonix to deliver consistent performance without compromising on design.",
    "features": [
      "Sleek modern design",
      "Easy to clean and maintain",
      "Energy efficient design",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Kryonix",
      "Model": "WIR-462",
      "Category": "Electronics",
      "Material": "Cotton Blend",
      "Color": "White",
      "Weight": "3.12 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 838,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 3499,
    "discount": 25,
    "price": 2624,
    "saved": 875,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Wireless+Mouse",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Mouse",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Mouse%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Mouse%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Wireless+Mouse%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1020",
    "sku": "SKU102094",
    "name": "Kitchenora Rice Cooker",
    "brand": "Kitchenora",
    "category": "Home & Kitchen",
    "description": "Designed with the modern user in mind, the Kitchenora Rice Cooker offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Advanced safety features",
      "Long-lasting durability",
      "Energy efficient design",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Kitchenora",
      "Model": "RIC-330",
      "Category": "Home & Kitchen",
      "Material": "Stainless Steel",
      "Color": "Blue",
      "Weight": "0.31 kg",
      "Country of Origin": "India"
    },
    "rating": 4.3,
    "reviewsCount": 660,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 999,
    "discount": 30,
    "price": 699,
    "saved": 300,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Rice+Cooker",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Rice+Cooker",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Rice+Cooker%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Rice+Cooker%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Rice+Cooker%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1143",
    "sku": "SKU114324",
    "name": "Motorix Car Organizer Trunk",
    "brand": "Motorix",
    "category": "Automotive",
    "description": "Engineered for everyday reliability, the Motorix Car Organizer Trunk combines thoughtful design with dependable performance, making it a smart addition to your automotive collection.",
    "features": [
      "Water & dust resistant",
      "Multi-functional usage",
      "Sleek modern design",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Motorix",
      "Model": "CAR-444",
      "Category": "Automotive",
      "Material": "Engineered Wood",
      "Color": "Graphite Grey",
      "Weight": "1.02 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 394,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 3999,
    "discount": 35,
    "price": 2599,
    "saved": 1400,
    "availability": "Only Few Left",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Car+Organizer+Trunk",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Organizer+Trunk",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Organizer+Trunk%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Organizer+Trunk%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Organizer+Trunk%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller"
    ]
  },
  {
    "id": "MDH-1053",
    "sku": "SKU105326",
    "name": "Restly Bar Stool Set",
    "brand": "Restly",
    "category": "Furniture",
    "description": "Upgrade your routine with the Restly Bar Stool Set \u2014 thoughtfully crafted by Restly to deliver consistent performance without compromising on design.",
    "features": [
      "Skin/eco-friendly materials",
      "Long-lasting durability",
      "Multi-functional usage",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Restly",
      "Model": "BAR-462",
      "Category": "Furniture",
      "Material": "High-Grade Polymer",
      "Color": "White",
      "Weight": "5.66 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 587,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 3999,
    "discount": 10,
    "price": 3599,
    "saved": 400,
    "availability": "Only Few Left",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Bar+Stool+Set",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bar+Stool+Set",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bar+Stool+Set%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bar+Stool+Set%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bar+Stool+Set%0A(View+4)"
    ],
    "badges": [
      "new"
    ]
  },
  {
    "id": "MDH-1130",
    "sku": "SKU113065",
    "name": "Deskly Cable Management Kit",
    "brand": "Deskly",
    "category": "Office Supplies",
    "description": "The Deskly Cable Management Kit from Deskly blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Ergonomic and comfortable",
      "Multi-functional usage",
      "Water & dust resistant",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Deskly",
      "Model": "CAB-222",
      "Category": "Office Supplies",
      "Material": "Premium ABS Plastic",
      "Color": "Charcoal",
      "Weight": "1.02 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 68,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 999,
    "discount": 45,
    "price": 549,
    "saved": 450,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Cable+Management+Kit",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Cable+Management+Kit",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Cable+Management+Kit%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Cable+Management+Kit%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Cable+Management+Kit%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1068",
    "sku": "SKU106863",
    "name": "Lumina Lip Care Combo Set",
    "brand": "Lumina",
    "category": "Beauty",
    "description": "Engineered for everyday reliability, the Lumina Lip Care Combo Set combines thoughtful design with dependable performance, making it a smart addition to your beauty collection.",
    "features": [
      "1-year manufacturer support",
      "Travel-friendly size",
      "Advanced safety features",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Lumina",
      "Model": "LIP-747",
      "Category": "Beauty",
      "Material": "Aluminum Alloy",
      "Color": "Navy",
      "Weight": "1.69 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 868,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 5999,
    "discount": 45,
    "price": 3299,
    "saved": 2700,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Lip+Care+Combo+Set",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Lip+Care+Combo+Set",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Lip+Care+Combo+Set%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Lip+Care+Combo+Set%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Lip+Care+Combo+Set%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new"
    ]
  },
  {
    "id": "MDH-1142",
    "sku": "SKU114282",
    "name": "Motorix Jump Starter Kit",
    "brand": "Motorix",
    "category": "Automotive",
    "description": "The Motorix Jump Starter Kit from Motorix blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Travel-friendly size",
      "Premium build quality",
      "Energy efficient design",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Motorix",
      "Model": "JUM-716",
      "Category": "Automotive",
      "Material": "Stainless Steel",
      "Color": "Black",
      "Weight": "3.49 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 191,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 1499,
    "discount": 45,
    "price": 824,
    "saved": 675,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Jump+Starter+Kit",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Jump+Starter+Kit",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Jump+Starter+Kit%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Jump+Starter+Kit%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Jump+Starter+Kit%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new",
      "trending"
    ]
  },
  {
    "id": "MDH-1079",
    "sku": "SKU107998",
    "name": "Athlex Water Bottle Sport 1L",
    "brand": "Athlex",
    "category": "Sports",
    "description": "The Athlex Water Bottle Sport 1L from Athlex blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Travel-friendly size",
      "Easy to clean and maintain",
      "Long-lasting durability",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "WAT-420",
      "Category": "Sports",
      "Material": "High-Grade Polymer",
      "Color": "Graphite Grey",
      "Weight": "4.81 kg",
      "Country of Origin": "India"
    },
    "rating": 4.2,
    "reviewsCount": 507,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 799,
    "discount": 20,
    "price": 639,
    "saved": 160,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Water+Bottle+Sport+1L",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Water+Bottle+Sport+1L",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Water+Bottle+Sport+1L%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Water+Bottle+Sport+1L%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Water+Bottle+Sport+1L%0A(View+4)"
    ],
    "badges": [
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1109",
    "sku": "SKU110947",
    "name": "Pageturn Press Self-Improvement Bestseller",
    "brand": "Pageturn Press",
    "category": "Books",
    "description": "The Pageturn Press Self-Improvement Bestseller from Pageturn Press blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "1-year manufacturer support",
      "Skin/eco-friendly materials",
      "Easy to clean and maintain",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Pageturn Press",
      "Model": "SEL-801",
      "Category": "Books",
      "Material": "Cotton Blend",
      "Color": "Blue",
      "Weight": "1.03 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 754,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 2999,
    "discount": 40,
    "price": 1799,
    "saved": 1200,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Self-Improvement+Bestseller",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Self-Improvement+Bestseller",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Self-Improvement+Bestseller%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Self-Improvement+Bestseller%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Self-Improvement+Bestseller%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1121",
    "sku": "SKU112178",
    "name": "Stationex Ergonomic Desk Organizer",
    "brand": "Stationex",
    "category": "Office Supplies",
    "description": "Engineered for everyday reliability, the Stationex Ergonomic Desk Organizer combines thoughtful design with dependable performance, making it a smart addition to your office supplies collection.",
    "features": [
      "Ergonomic and comfortable",
      "Advanced safety features",
      "1-year manufacturer support",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Stationex",
      "Model": "ERG-238",
      "Category": "Office Supplies",
      "Material": "Cotton Blend",
      "Color": "Black",
      "Weight": "6.45 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 311,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1249,
    "discount": 35,
    "price": 812,
    "saved": 437,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Ergonomic+Desk+Organizer",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Ergonomic+Desk+Organizer",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Ergonomic+Desk+Organizer%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Ergonomic+Desk+Organizer%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Ergonomic+Desk+Organizer%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1078",
    "sku": "SKU107882",
    "name": "Trailforce Gym Gloves",
    "brand": "Trailforce",
    "category": "Sports",
    "description": "The Trailforce Gym Gloves from Trailforce blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Noise-free smooth operation",
      "Advanced safety features",
      "Ergonomic and comfortable",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Trailforce",
      "Model": "GYM-885",
      "Category": "Sports",
      "Material": "Aluminum Alloy",
      "Color": "White",
      "Weight": "4.07 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 668,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 799,
    "discount": 10,
    "price": 719,
    "saved": 80,
    "availability": "Only Few Left",
    "warranty": "2 Years",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Gym+Gloves",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Gym+Gloves",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Gym+Gloves%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Gym+Gloves%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Gym+Gloves%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1010",
    "sku": "SKU101045",
    "name": "Nexowave Webcam 1080p",
    "brand": "Nexowave",
    "category": "Electronics",
    "description": "Engineered for everyday reliability, the Nexowave Webcam 1080p combines thoughtful design with dependable performance, making it a smart addition to your electronics collection.",
    "features": [
      "Travel-friendly size",
      "Noise-free smooth operation",
      "Skin/eco-friendly materials",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Nexowave",
      "Model": "WEB-767",
      "Category": "Electronics",
      "Material": "Aluminum Alloy",
      "Color": "Black",
      "Weight": "6.3 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 89,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 3499,
    "discount": 25,
    "price": 2624,
    "saved": 875,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Webcam+1080p",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Webcam+1080p",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Webcam+1080p%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Webcam+1080p%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Webcam+1080p%0A(View+4)"
    ],
    "badges": [
      "new",
      "trending"
    ]
  },
  {
    "id": "MDH-1132",
    "sku": "SKU113241",
    "name": "Deskly Business Card Holder",
    "brand": "Deskly",
    "category": "Office Supplies",
    "description": "Upgrade your routine with the Deskly Business Card Holder \u2014 thoughtfully crafted by Deskly to deliver consistent performance without compromising on design.",
    "features": [
      "Compact and lightweight",
      "Adjustable settings",
      "Premium build quality",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Deskly",
      "Model": "BUS-329",
      "Category": "Office Supplies",
      "Material": "Engineered Wood",
      "Color": "Blue",
      "Weight": "2.79 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 165,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 799,
    "discount": 45,
    "price": 439,
    "saved": 360,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Business+Card+Holder",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Business+Card+Holder",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Business+Card+Holder%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Business+Card+Holder%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Business+Card+Holder%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new"
    ]
  },
  {
    "id": "MDH-1114",
    "sku": "SKU111429",
    "name": "Chapterline Fantasy Fiction Novel",
    "brand": "Chapterline",
    "category": "Books",
    "description": "The Chapterline Fantasy Fiction Novel from Chapterline blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Sleek modern design",
      "Energy efficient design",
      "Adjustable settings",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Chapterline",
      "Model": "FAN-456",
      "Category": "Books",
      "Material": "Engineered Wood",
      "Color": "Graphite Grey",
      "Weight": "3.04 kg",
      "Country of Origin": "India"
    },
    "rating": 4.3,
    "reviewsCount": 314,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 2499,
    "discount": 10,
    "price": 2249,
    "saved": 250,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Fantasy+Fiction+Novel",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Fantasy+Fiction+Novel",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Fantasy+Fiction+Novel%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Fantasy+Fiction+Novel%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Fantasy+Fiction+Novel%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1134",
    "sku": "SKU113454",
    "name": "Autolume LED Headlight Bulb Set",
    "brand": "Autolume",
    "category": "Automotive",
    "description": "Designed with the modern user in mind, the Autolume LED Headlight Bulb Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Noise-free smooth operation",
      "Multi-functional usage",
      "Sleek modern design",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Autolume",
      "Model": "LED-206",
      "Category": "Automotive",
      "Material": "Stainless Steel",
      "Color": "Navy",
      "Weight": "6.39 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 13,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 5999,
    "discount": 10,
    "price": 5399,
    "saved": 600,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=LED+Headlight+Bulb+Set",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=LED+Headlight+Bulb+Set",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=LED+Headlight+Bulb+Set%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=LED+Headlight+Bulb+Set%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=LED+Headlight+Bulb+Set%0A(View+4)"
    ],
    "badges": [
      "new",
      "trending"
    ]
  },
  {
    "id": "MDH-1113",
    "sku": "SKU111323",
    "name": "Pageturn Press Business Strategy Guide",
    "brand": "Pageturn Press",
    "category": "Books",
    "description": "Upgrade your routine with the Pageturn Press Business Strategy Guide \u2014 thoughtfully crafted by Pageturn Press to deliver consistent performance without compromising on design.",
    "features": [
      "Compact and lightweight",
      "Multi-functional usage",
      "Advanced safety features",
      "Premium build quality"
    ],
    "specifications": {
      "Brand": "Pageturn Press",
      "Model": "BUS-870",
      "Category": "Books",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "0.82 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 375,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 9999,
    "discount": 25,
    "price": 7499,
    "saved": 2500,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Business+Strategy+Guide",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Business+Strategy+Guide",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Business+Strategy+Guide%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Business+Strategy+Guide%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Business+Strategy+Guide%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1016",
    "sku": "SKU101630",
    "name": "Kitchenora Electric Kettle",
    "brand": "Kitchenora",
    "category": "Home & Kitchen",
    "description": "The Kitchenora Electric Kettle from Kitchenora blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Compact and lightweight",
      "Water & dust resistant",
      "Long-lasting durability",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Kitchenora",
      "Model": "ELE-373",
      "Category": "Home & Kitchen",
      "Material": "Stainless Steel",
      "Color": "Charcoal",
      "Weight": "0.84 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 37,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 9999,
    "discount": 20,
    "price": 7999,
    "saved": 2000,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Electric+Kettle",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Electric+Kettle",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Electric+Kettle%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Electric+Kettle%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Electric+Kettle%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1060",
    "sku": "SKU106051",
    "name": "Blossette Makeup Brush Set",
    "brand": "Blossette",
    "category": "Beauty",
    "description": "Designed with the modern user in mind, the Blossette Makeup Brush Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Travel-friendly size",
      "1-year manufacturer support",
      "Multi-functional usage",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Blossette",
      "Model": "MAK-705",
      "Category": "Beauty",
      "Material": "Premium ABS Plastic",
      "Color": "Graphite Grey",
      "Weight": "3.37 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 81,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 5999,
    "discount": 35,
    "price": 3899,
    "saved": 2100,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Makeup+Brush+Set",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Makeup+Brush+Set",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Makeup+Brush+Set%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Makeup+Brush+Set%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Makeup+Brush+Set%0A(View+4)"
    ],
    "badges": [
      "deal",
      "featured"
    ]
  },
  {
    "id": "MDH-1103",
    "sku": "SKU110371",
    "name": "Wondertoy Board Game Family Pack",
    "brand": "Wondertoy",
    "category": "Toys",
    "description": "Designed with the modern user in mind, the Wondertoy Board Game Family Pack offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Skin/eco-friendly materials",
      "Sleek modern design",
      "Premium build quality",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Wondertoy",
      "Model": "BOA-648",
      "Category": "Toys",
      "Material": "Engineered Wood",
      "Color": "Black",
      "Weight": "3.34 kg",
      "Country of Origin": "India"
    },
    "rating": 3.6,
    "reviewsCount": 556,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 5999,
    "discount": 45,
    "price": 3299,
    "saved": 2700,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Board+Game+Family+Pack",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Board+Game+Family+Pack",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Board+Game+Family+Pack%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Board+Game+Family+Pack%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Board+Game+Family+Pack%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new"
    ]
  },
  {
    "id": "MDH-1125",
    "sku": "SKU112597",
    "name": "Stationex File Folder Organizer",
    "brand": "Stationex",
    "category": "Office Supplies",
    "description": "The Stationex File Folder Organizer from Stationex blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Adjustable settings",
      "Energy efficient design",
      "Sleek modern design",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Stationex",
      "Model": "FIL-589",
      "Category": "Office Supplies",
      "Material": "Premium ABS Plastic",
      "Color": "Blue",
      "Weight": "2.58 kg",
      "Country of Origin": "India"
    },
    "rating": 3.6,
    "reviewsCount": 363,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 3499,
    "discount": 10,
    "price": 3149,
    "saved": 350,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=File+Folder+Organizer",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=File+Folder+Organizer",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=File+Folder+Organizer%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=File+Folder+Organizer%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=File+Folder+Organizer%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1098",
    "sku": "SKU109848",
    "name": "Kidoria Remote Control Car",
    "brand": "Kidoria",
    "category": "Toys",
    "description": "The Kidoria Remote Control Car from Kidoria blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Easy to clean and maintain",
      "Adjustable settings",
      "1-year manufacturer support",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Kidoria",
      "Model": "REM-925",
      "Category": "Toys",
      "Material": "Cotton Blend",
      "Color": "Black",
      "Weight": "3.72 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 496,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 2999,
    "discount": 20,
    "price": 2399,
    "saved": 600,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Remote+Control+Car",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Remote+Control+Car",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Remote+Control+Car%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Remote+Control+Car%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Remote+Control+Car%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1048",
    "sku": "SKU104814",
    "name": "Restly Folding Chair",
    "brand": "Restly",
    "category": "Furniture",
    "description": "Designed with the modern user in mind, the Restly Folding Chair offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Easy to clean and maintain",
      "Adjustable settings",
      "Long-lasting durability",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Restly",
      "Model": "FOL-657",
      "Category": "Furniture",
      "Material": "High-Grade Polymer",
      "Color": "Graphite Grey",
      "Weight": "0.53 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 467,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 7999,
    "discount": 35,
    "price": 5199,
    "saved": 2800,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Folding+Chair",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Folding+Chair",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Folding+Chair%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Folding+Chair%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Folding+Chair%0A(View+4)"
    ],
    "badges": [
      "deal",
      "featured"
    ]
  },
  {
    "id": "MDH-1097",
    "sku": "SKU109750",
    "name": "Wondertoy Building Blocks Set",
    "brand": "Wondertoy",
    "category": "Toys",
    "description": "Designed with the modern user in mind, the Wondertoy Building Blocks Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Multi-functional usage",
      "Skin/eco-friendly materials",
      "Easy to clean and maintain",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Wondertoy",
      "Model": "BUI-381",
      "Category": "Toys",
      "Material": "Premium ABS Plastic",
      "Color": "Navy",
      "Weight": "6.17 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 158,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 4999,
    "discount": 35,
    "price": 3249,
    "saved": 1750,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Building+Blocks+Set",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Blocks+Set",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Blocks+Set%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Blocks+Set%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Blocks+Set%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1054",
    "sku": "SKU105481",
    "name": "Restly Wall Mounted Desk",
    "brand": "Restly",
    "category": "Furniture",
    "description": "Engineered for everyday reliability, the Restly Wall Mounted Desk combines thoughtful design with dependable performance, making it a smart addition to your furniture collection.",
    "features": [
      "Easy to clean and maintain",
      "Noise-free smooth operation",
      "Sleek modern design",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Restly",
      "Model": "WAL-723",
      "Category": "Furniture",
      "Material": "High-Grade Polymer",
      "Color": "Charcoal",
      "Weight": "1.85 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 599,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Wall+Mounted+Desk",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wall+Mounted+Desk",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wall+Mounted+Desk%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wall+Mounted+Desk%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Wall+Mounted+Desk%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1040",
    "sku": "SKU104094",
    "name": "Clothcraft Chino Trousers",
    "brand": "Clothcraft",
    "category": "Fashion",
    "description": "Engineered for everyday reliability, the Clothcraft Chino Trousers combines thoughtful design with dependable performance, making it a smart addition to your fashion collection.",
    "features": [
      "Compact and lightweight",
      "Skin/eco-friendly materials",
      "Advanced safety features",
      "Long-lasting durability"
    ],
    "specifications": {
      "Brand": "Clothcraft",
      "Model": "CHI-995",
      "Category": "Fashion",
      "Material": "Cotton Blend",
      "Color": "Black",
      "Weight": "3.49 kg",
      "Country of Origin": "India"
    },
    "rating": 4.3,
    "reviewsCount": 49,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 9999,
    "discount": 20,
    "price": 7999,
    "saved": 2000,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Chino+Trousers",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Chino+Trousers",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Chino+Trousers%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Chino+Trousers%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Chino+Trousers%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1090",
    "sku": "SKU109092",
    "name": "Poucha Wallet Card Holder",
    "brand": "Poucha",
    "category": "Accessories",
    "description": "The Poucha Wallet Card Holder from Poucha blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Noise-free smooth operation",
      "Ergonomic and comfortable",
      "Advanced safety features",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Poucha",
      "Model": "WAL-279",
      "Category": "Accessories",
      "Material": "Aluminum Alloy",
      "Color": "Charcoal",
      "Weight": "5.85 kg",
      "Country of Origin": "India"
    },
    "rating": 3.6,
    "reviewsCount": 357,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1999,
    "discount": 20,
    "price": 1599,
    "saved": 400,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Wallet+Card+Holder",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Wallet+Card+Holder",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Wallet+Card+Holder%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Wallet+Card+Holder%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Wallet+Card+Holder%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1110",
    "sku": "SKU111041",
    "name": "Inkwell Editions Mystery Thriller Novel",
    "brand": "Inkwell Editions",
    "category": "Books",
    "description": "Engineered for everyday reliability, the Inkwell Editions Mystery Thriller Novel combines thoughtful design with dependable performance, making it a smart addition to your books collection.",
    "features": [
      "Travel-friendly size",
      "Energy efficient design",
      "Compact and lightweight",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Inkwell Editions",
      "Model": "MYS-505",
      "Category": "Books",
      "Material": "Engineered Wood",
      "Color": "Navy",
      "Weight": "2.56 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 212,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 7999,
    "discount": 45,
    "price": 4399,
    "saved": 3600,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Mystery+Thriller+Novel",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Mystery+Thriller+Novel",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Mystery+Thriller+Novel%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Mystery+Thriller+Novel%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Mystery+Thriller+Novel%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1117",
    "sku": "SKU111789",
    "name": "Bindery House History Encyclopedia",
    "brand": "Bindery House",
    "category": "Books",
    "description": "Engineered for everyday reliability, the Bindery House History Encyclopedia combines thoughtful design with dependable performance, making it a smart addition to your books collection.",
    "features": [
      "Energy efficient design",
      "Multi-functional usage",
      "Compact and lightweight",
      "Long-lasting durability"
    ],
    "specifications": {
      "Brand": "Bindery House",
      "Model": "HIS-344",
      "Category": "Books",
      "Material": "Engineered Wood",
      "Color": "Black",
      "Weight": "1.31 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 616,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 1249,
    "discount": 30,
    "price": 874,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=History+Encyclopedia",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=History+Encyclopedia",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=History+Encyclopedia%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=History+Encyclopedia%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=History+Encyclopedia%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new"
    ]
  },
  {
    "id": "MDH-1012",
    "sku": "SKU101261",
    "name": "Nexowave Portable SSD 1TB",
    "brand": "Nexowave",
    "category": "Electronics",
    "description": "Designed with the modern user in mind, the Nexowave Portable SSD 1TB offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Advanced safety features",
      "Energy efficient design",
      "Sleek modern design",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Nexowave",
      "Model": "POR-367",
      "Category": "Electronics",
      "Material": "Stainless Steel",
      "Color": "Charcoal",
      "Weight": "4.7 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 52,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 999,
    "discount": 25,
    "price": 749,
    "saved": 250,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Portable+SSD+1TB",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Portable+SSD+1TB",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Portable+SSD+1TB%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Portable+SSD+1TB%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Portable+SSD+1TB%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1146",
    "sku": "SKU114693",
    "name": "Barkbox Cat Scratching Post",
    "brand": "Barkbox",
    "category": "Pet Supplies",
    "description": "Engineered for everyday reliability, the Barkbox Cat Scratching Post combines thoughtful design with dependable performance, making it a smart addition to your pet supplies collection.",
    "features": [
      "Noise-free smooth operation",
      "Adjustable settings",
      "Premium build quality",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Barkbox",
      "Model": "CAT-426",
      "Category": "Pet Supplies",
      "Material": "Engineered Wood",
      "Color": "Black",
      "Weight": "0.62 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 87,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 9999,
    "discount": 25,
    "price": 7499,
    "saved": 2500,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Cat+Scratching+Post",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Scratching+Post",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Scratching+Post%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Scratching+Post%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Cat+Scratching+Post%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1043",
    "sku": "SKU104369",
    "name": "Woodura Ergonomic Office Chair",
    "brand": "Woodura",
    "category": "Furniture",
    "description": "Upgrade your routine with the Woodura Ergonomic Office Chair \u2014 thoughtfully crafted by Woodura to deliver consistent performance without compromising on design.",
    "features": [
      "Long-lasting durability",
      "Advanced safety features",
      "Ergonomic and comfortable",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Woodura",
      "Model": "ERG-806",
      "Category": "Furniture",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "5.52 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 464,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1999,
    "discount": 50,
    "price": 1000,
    "saved": 999,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Ergonomic+Office+Chair",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Ergonomic+Office+Chair",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Ergonomic+Office+Chair%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Ergonomic+Office+Chair%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Ergonomic+Office+Chair%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending"
    ]
  },
  {
    "id": "MDH-1116",
    "sku": "SKU111664",
    "name": "Chapterline Poetry Anthology",
    "brand": "Chapterline",
    "category": "Books",
    "description": "Engineered for everyday reliability, the Chapterline Poetry Anthology combines thoughtful design with dependable performance, making it a smart addition to your books collection.",
    "features": [
      "Ergonomic and comfortable",
      "Noise-free smooth operation",
      "Water & dust resistant",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Chapterline",
      "Model": "POE-918",
      "Category": "Books",
      "Material": "Aluminum Alloy",
      "Color": "Blue",
      "Weight": "2.47 kg",
      "Country of Origin": "India"
    },
    "rating": 4.6,
    "reviewsCount": 222,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 2999,
    "discount": 10,
    "price": 2699,
    "saved": 300,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Poetry+Anthology",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Poetry+Anthology",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Poetry+Anthology%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Poetry+Anthology%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Poetry+Anthology%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1129",
    "sku": "SKU112963",
    "name": "Stationex Laptop Stand Adjustable",
    "brand": "Stationex",
    "category": "Office Supplies",
    "description": "Engineered for everyday reliability, the Stationex Laptop Stand Adjustable combines thoughtful design with dependable performance, making it a smart addition to your office supplies collection.",
    "features": [
      "Skin/eco-friendly materials",
      "Advanced safety features",
      "Compact and lightweight",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Stationex",
      "Model": "LAP-417",
      "Category": "Office Supplies",
      "Material": "Premium ABS Plastic",
      "Color": "Navy",
      "Weight": "6.0 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 561,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 2999,
    "discount": 40,
    "price": 1799,
    "saved": 1200,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Laptop+Stand+Adjustable",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Laptop+Stand+Adjustable",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Laptop+Stand+Adjustable%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Laptop+Stand+Adjustable%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Laptop+Stand+Adjustable%0A(View+4)"
    ],
    "badges": [
      "deal",
      "featured"
    ]
  },
  {
    "id": "MDH-1122",
    "sku": "SKU112258",
    "name": "Notewell Notebook Set A5",
    "brand": "Notewell",
    "category": "Office Supplies",
    "description": "Designed with the modern user in mind, the Notewell Notebook Set A5 offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Energy efficient design",
      "Sleek modern design",
      "Skin/eco-friendly materials",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Notewell",
      "Model": "NOT-811",
      "Category": "Office Supplies",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "6.18 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 799,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 3499,
    "discount": 15,
    "price": 2974,
    "saved": 525,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Notebook+Set+A5",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Notebook+Set+A5",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Notebook+Set+A5%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Notebook+Set+A5%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Notebook+Set+A5%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1119",
    "sku": "SKU111947",
    "name": "Storyfield Personal Finance Guide",
    "brand": "Storyfield",
    "category": "Books",
    "description": "Upgrade your routine with the Storyfield Personal Finance Guide \u2014 thoughtfully crafted by Storyfield to deliver consistent performance without compromising on design.",
    "features": [
      "Compact and lightweight",
      "Noise-free smooth operation",
      "Travel-friendly size",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Storyfield",
      "Model": "PER-662",
      "Category": "Books",
      "Material": "Aluminum Alloy",
      "Color": "Black",
      "Weight": "3.79 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 307,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 799,
    "discount": 30,
    "price": 559,
    "saved": 240,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Personal+Finance+Guide",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Personal+Finance+Guide",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Personal+Finance+Guide%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Personal+Finance+Guide%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Personal+Finance+Guide%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1034",
    "sku": "SKU103494",
    "name": "Draperie Formal Blazer",
    "brand": "Draperie",
    "category": "Fashion",
    "description": "The Draperie Formal Blazer from Draperie blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Easy to clean and maintain",
      "Multi-functional usage",
      "Compact and lightweight",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Draperie",
      "Model": "FOR-173",
      "Category": "Fashion",
      "Material": "Premium ABS Plastic",
      "Color": "Blue",
      "Weight": "5.18 kg",
      "Country of Origin": "India"
    },
    "rating": 4.2,
    "reviewsCount": 569,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 9999,
    "discount": 25,
    "price": 7499,
    "saved": 2500,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Formal+Blazer",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Formal+Blazer",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Formal+Blazer%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Formal+Blazer%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Formal+Blazer%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1127",
    "sku": "SKU112792",
    "name": "Officeon Whiteboard Magnetic",
    "brand": "Officeon",
    "category": "Office Supplies",
    "description": "Engineered for everyday reliability, the Officeon Whiteboard Magnetic combines thoughtful design with dependable performance, making it a smart addition to your office supplies collection.",
    "features": [
      "Water & dust resistant",
      "Advanced safety features",
      "Ergonomic and comfortable",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Officeon",
      "Model": "WHI-968",
      "Category": "Office Supplies",
      "Material": "High-Grade Polymer",
      "Color": "Graphite Grey",
      "Weight": "1.45 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 626,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 999,
    "discount": 25,
    "price": 749,
    "saved": 250,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Whiteboard+Magnetic",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Whiteboard+Magnetic",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Whiteboard+Magnetic%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Whiteboard+Magnetic%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Whiteboard+Magnetic%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1149",
    "sku": "SKU114966",
    "name": "Petloop Dog Chew Toy Set",
    "brand": "Petloop",
    "category": "Pet Supplies",
    "description": "Engineered for everyday reliability, the Petloop Dog Chew Toy Set combines thoughtful design with dependable performance, making it a smart addition to your pet supplies collection.",
    "features": [
      "Advanced safety features",
      "Premium build quality",
      "Compact and lightweight",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Petloop",
      "Model": "DOG-187",
      "Category": "Pet Supplies",
      "Material": "High-Grade Polymer",
      "Color": "Graphite Grey",
      "Weight": "5.28 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 287,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 3499,
    "discount": 30,
    "price": 2449,
    "saved": 1050,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Dog+Chew+Toy+Set",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Chew+Toy+Set",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Chew+Toy+Set%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Chew+Toy+Set%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Chew+Toy+Set%0A(View+4)"
    ],
    "badges": [
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1112",
    "sku": "SKU111296",
    "name": "Bindery House Cookbook Collection",
    "brand": "Bindery House",
    "category": "Books",
    "description": "Upgrade your routine with the Bindery House Cookbook Collection \u2014 thoughtfully crafted by Bindery House to deliver consistent performance without compromising on design.",
    "features": [
      "Ergonomic and comfortable",
      "Multi-functional usage",
      "Compact and lightweight",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Bindery House",
      "Model": "COO-908",
      "Category": "Books",
      "Material": "Cotton Blend",
      "Color": "Black",
      "Weight": "3.0 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 259,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 3499,
    "discount": 20,
    "price": 2799,
    "saved": 700,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/495057/FFFFFF?font=poppins&text=Cookbook+Collection",
    "images": [
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Cookbook+Collection",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Cookbook+Collection%0A(View+2)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Cookbook+Collection%0A(View+3)",
      "https://placehold.co/700x700/495057/FFFFFF?font=poppins&text=Cookbook+Collection%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1013",
    "sku": "SKU101382",
    "name": "Kryonix Bluetooth Neckband",
    "brand": "Kryonix",
    "category": "Electronics",
    "description": "The Kryonix Bluetooth Neckband from Kryonix blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Ergonomic and comfortable",
      "Compact and lightweight",
      "Long-lasting durability",
      "Energy efficient design"
    ],
    "specifications": {
      "Brand": "Kryonix",
      "Model": "BLU-478",
      "Category": "Electronics",
      "Material": "Engineered Wood",
      "Color": "Blue",
      "Weight": "2.93 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 530,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 999,
    "discount": 15,
    "price": 849,
    "saved": 150,
    "availability": "Only Few Left",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Neckband",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Neckband",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Neckband%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Neckband%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Bluetooth+Neckband%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1038",
    "sku": "SKU103847",
    "name": "Clothcraft Sports Cap",
    "brand": "Clothcraft",
    "category": "Fashion",
    "description": "The Clothcraft Sports Cap from Clothcraft blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Travel-friendly size",
      "Easy to clean and maintain",
      "1-year manufacturer support",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Clothcraft",
      "Model": "SPO-492",
      "Category": "Fashion",
      "Material": "Stainless Steel",
      "Color": "Navy",
      "Weight": "3.38 kg",
      "Country of Origin": "India"
    },
    "rating": 4.2,
    "reviewsCount": 506,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 3999,
    "discount": 30,
    "price": 2799,
    "saved": 1200,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Sports+Cap",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Sports+Cap",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Sports+Cap%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Sports+Cap%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Sports+Cap%0A(View+4)"
    ],
    "badges": [
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1024",
    "sku": "SKU102495",
    "name": "Domesta Storage Container Set",
    "brand": "Domesta",
    "category": "Home & Kitchen",
    "description": "Engineered for everyday reliability, the Domesta Storage Container Set combines thoughtful design with dependable performance, making it a smart addition to your home & kitchen collection.",
    "features": [
      "Travel-friendly size",
      "Compact and lightweight",
      "Advanced safety features",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Domesta",
      "Model": "STO-503",
      "Category": "Home & Kitchen",
      "Material": "Aluminum Alloy",
      "Color": "Navy",
      "Weight": "4.36 kg",
      "Country of Origin": "India"
    },
    "rating": 4.6,
    "reviewsCount": 872,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 5999,
    "discount": 40,
    "price": 3599,
    "saved": 2400,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Storage+Container+Set",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Storage+Container+Set",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Storage+Container+Set%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Storage+Container+Set%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Storage+Container+Set%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1072",
    "sku": "SKU107223",
    "name": "Trailforce Adjustable Dumbbell Set",
    "brand": "Trailforce",
    "category": "Sports",
    "description": "The Trailforce Adjustable Dumbbell Set from Trailforce blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Travel-friendly size",
      "Advanced safety features",
      "Water & dust resistant",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Trailforce",
      "Model": "ADJ-806",
      "Category": "Sports",
      "Material": "Cotton Blend",
      "Color": "Graphite Grey",
      "Weight": "2.99 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 325,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 999,
    "discount": 35,
    "price": 649,
    "saved": 350,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Adjustable+Dumbbell+Set",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Adjustable+Dumbbell+Set",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Adjustable+Dumbbell+Set%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Adjustable+Dumbbell+Set%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Adjustable+Dumbbell+Set%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1085",
    "sku": "SKU108598",
    "name": "Poucha Leather Belt",
    "brand": "Poucha",
    "category": "Accessories",
    "description": "Engineered for everyday reliability, the Poucha Leather Belt combines thoughtful design with dependable performance, making it a smart addition to your accessories collection.",
    "features": [
      "1-year manufacturer support",
      "Travel-friendly size",
      "Water & dust resistant",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Poucha",
      "Model": "LEA-822",
      "Category": "Accessories",
      "Material": "Stainless Steel",
      "Color": "Navy",
      "Weight": "1.47 kg",
      "Country of Origin": "India"
    },
    "rating": 4.3,
    "reviewsCount": 638,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1499,
    "discount": 40,
    "price": 899,
    "saved": 600,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Leather+Belt",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Leather+Belt",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Leather+Belt%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Leather+Belt%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Leather+Belt%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1022",
    "sku": "SKU102241",
    "name": "Domesta Chopping Board Set",
    "brand": "Domesta",
    "category": "Home & Kitchen",
    "description": "Upgrade your routine with the Domesta Chopping Board Set \u2014 thoughtfully crafted by Domesta to deliver consistent performance without compromising on design.",
    "features": [
      "Travel-friendly size",
      "Multi-functional usage",
      "Easy to clean and maintain",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Domesta",
      "Model": "CHO-179",
      "Category": "Home & Kitchen",
      "Material": "High-Grade Polymer",
      "Color": "Graphite Grey",
      "Weight": "1.64 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 545,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 5999,
    "discount": 30,
    "price": 4199,
    "saved": 1800,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Chopping+Board+Set",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Chopping+Board+Set",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Chopping+Board+Set%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Chopping+Board+Set%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Chopping+Board+Set%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "trending"
    ]
  },
  {
    "id": "MDH-1141",
    "sku": "SKU114139",
    "name": "Autolume Steering Wheel Cover",
    "brand": "Autolume",
    "category": "Automotive",
    "description": "Engineered for everyday reliability, the Autolume Steering Wheel Cover combines thoughtful design with dependable performance, making it a smart addition to your automotive collection.",
    "features": [
      "Ergonomic and comfortable",
      "Skin/eco-friendly materials",
      "Noise-free smooth operation",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Autolume",
      "Model": "STE-882",
      "Category": "Automotive",
      "Material": "Stainless Steel",
      "Color": "Navy",
      "Weight": "5.53 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 258,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 1249,
    "discount": 15,
    "price": 1062,
    "saved": 187,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Steering+Wheel+Cover",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Steering+Wheel+Cover",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Steering+Wheel+Cover%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Steering+Wheel+Cover%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Steering+Wheel+Cover%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1065",
    "sku": "SKU106567",
    "name": "Purelle Nail Care Kit",
    "brand": "Purelle",
    "category": "Beauty",
    "description": "Upgrade your routine with the Purelle Nail Care Kit \u2014 thoughtfully crafted by Purelle to deliver consistent performance without compromising on design.",
    "features": [
      "Noise-free smooth operation",
      "Travel-friendly size",
      "Easy to clean and maintain",
      "Long-lasting durability"
    ],
    "specifications": {
      "Brand": "Purelle",
      "Model": "NAI-572",
      "Category": "Beauty",
      "Material": "Engineered Wood",
      "Color": "White",
      "Weight": "3.34 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 840,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1499,
    "discount": 50,
    "price": 750,
    "saved": 749,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Nail+Care+Kit",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Nail+Care+Kit",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Nail+Care+Kit%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Nail+Care+Kit%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Nail+Care+Kit%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1046",
    "sku": "SKU104681",
    "name": "Formaline Bedside Table",
    "brand": "Formaline",
    "category": "Furniture",
    "description": "Designed with the modern user in mind, the Formaline Bedside Table offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Ergonomic and comfortable",
      "Skin/eco-friendly materials",
      "Energy efficient design",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Formaline",
      "Model": "BED-788",
      "Category": "Furniture",
      "Material": "High-Grade Polymer",
      "Color": "Charcoal",
      "Weight": "1.81 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 26,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "Only Few Left",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Bedside+Table",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bedside+Table",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bedside+Table%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bedside+Table%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Bedside+Table%0A(View+4)"
    ],
    "badges": [
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1086",
    "sku": "SKU108688",
    "name": "Beltcraft Sunglasses UV400",
    "brand": "Beltcraft",
    "category": "Accessories",
    "description": "Designed with the modern user in mind, the Beltcraft Sunglasses UV400 offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Skin/eco-friendly materials",
      "Ergonomic and comfortable",
      "Easy to clean and maintain",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Beltcraft",
      "Model": "SUN-821",
      "Category": "Accessories",
      "Material": "Stainless Steel",
      "Color": "Charcoal",
      "Weight": "4.63 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 297,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 3499,
    "discount": 25,
    "price": 2624,
    "saved": 875,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Sunglasses+UV400",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sunglasses+UV400",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sunglasses+UV400%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sunglasses+UV400%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sunglasses+UV400%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1061",
    "sku": "SKU106174",
    "name": "Blossette Facial Cleansing Brush",
    "brand": "Blossette",
    "category": "Beauty",
    "description": "The Blossette Facial Cleansing Brush from Blossette blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Water & dust resistant",
      "Premium build quality",
      "Travel-friendly size",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Blossette",
      "Model": "FAC-429",
      "Category": "Beauty",
      "Material": "Aluminum Alloy",
      "Color": "White",
      "Weight": "3.33 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 822,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 2999,
    "discount": 45,
    "price": 1649,
    "saved": 1350,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Facial+Cleansing+Brush",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Facial+Cleansing+Brush",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Facial+Cleansing+Brush%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Facial+Cleansing+Brush%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Facial+Cleansing+Brush%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new"
    ]
  },
  {
    "id": "MDH-1101",
    "sku": "SKU110128",
    "name": "Kidoria Educational Learning Tablet",
    "brand": "Kidoria",
    "category": "Toys",
    "description": "The Kidoria Educational Learning Tablet from Kidoria blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Advanced safety features",
      "Water & dust resistant",
      "Sleek modern design",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Kidoria",
      "Model": "EDU-300",
      "Category": "Toys",
      "Material": "Engineered Wood",
      "Color": "Blue",
      "Weight": "2.56 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 610,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 799,
    "discount": 30,
    "price": 559,
    "saved": 240,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Educational+Learning+Tablet",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Educational+Learning+Tablet",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Educational+Learning+Tablet%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Educational+Learning+Tablet%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Educational+Learning+Tablet%0A(View+4)"
    ],
    "badges": [
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1136",
    "sku": "SKU113627",
    "name": "Motorix Seat Cover Set",
    "brand": "Motorix",
    "category": "Automotive",
    "description": "Engineered for everyday reliability, the Motorix Seat Cover Set combines thoughtful design with dependable performance, making it a smart addition to your automotive collection.",
    "features": [
      "Travel-friendly size",
      "1-year manufacturer support",
      "Long-lasting durability",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Motorix",
      "Model": "SEA-648",
      "Category": "Automotive",
      "Material": "Engineered Wood",
      "Color": "Blue",
      "Weight": "3.02 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 180,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 9999,
    "discount": 15,
    "price": 8499,
    "saved": 1500,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Seat+Cover+Set",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Seat+Cover+Set",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Seat+Cover+Set%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Seat+Cover+Set%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Seat+Cover+Set%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1069",
    "sku": "SKU106918",
    "name": "Purelle Hair Oil Combo",
    "brand": "Purelle",
    "category": "Beauty",
    "description": "Engineered for everyday reliability, the Purelle Hair Oil Combo combines thoughtful design with dependable performance, making it a smart addition to your beauty collection.",
    "features": [
      "Skin/eco-friendly materials",
      "Premium build quality",
      "Sleek modern design",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Purelle",
      "Model": "HAI-750",
      "Category": "Beauty",
      "Material": "Cotton Blend",
      "Color": "Graphite Grey",
      "Weight": "1.76 kg",
      "Country of Origin": "India"
    },
    "rating": 4.3,
    "reviewsCount": 531,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 3999,
    "discount": 50,
    "price": 2000,
    "saved": 1999,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Hair+Oil+Combo",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Oil+Combo",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Oil+Combo%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Oil+Combo%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Oil+Combo%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new"
    ]
  },
  {
    "id": "MDH-1088",
    "sku": "SKU108822",
    "name": "Carrio Travel Duffel Bag",
    "brand": "Carrio",
    "category": "Accessories",
    "description": "The Carrio Travel Duffel Bag from Carrio blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Multi-functional usage",
      "Noise-free smooth operation",
      "Compact and lightweight",
      "Premium build quality"
    ],
    "specifications": {
      "Brand": "Carrio",
      "Model": "TRA-516",
      "Category": "Accessories",
      "Material": "High-Grade Polymer",
      "Color": "White",
      "Weight": "3.18 kg",
      "Country of Origin": "India"
    },
    "rating": 4.6,
    "reviewsCount": 114,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2999,
    "discount": 35,
    "price": 1949,
    "saved": 1050,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Travel+Duffel+Bag",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Travel+Duffel+Bag",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Travel+Duffel+Bag%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Travel+Duffel+Bag%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Travel+Duffel+Bag%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1029",
    "sku": "SKU102998",
    "name": "Threadloom Cotton Casual Shirt",
    "brand": "Threadloom",
    "category": "Fashion",
    "description": "The Threadloom Cotton Casual Shirt from Threadloom blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Energy efficient design",
      "Ergonomic and comfortable",
      "Easy to clean and maintain",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Threadloom",
      "Model": "COT-413",
      "Category": "Fashion",
      "Material": "High-Grade Polymer",
      "Color": "Navy",
      "Weight": "2.49 kg",
      "Country of Origin": "India"
    },
    "rating": 4.2,
    "reviewsCount": 29,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 3499,
    "discount": 45,
    "price": 1924,
    "saved": 1575,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Cotton+Casual+Shirt",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Cotton+Casual+Shirt",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Cotton+Casual+Shirt%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Cotton+Casual+Shirt%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Cotton+Casual+Shirt%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1092",
    "sku": "SKU109238",
    "name": "Straplyn Tote Bag Canvas",
    "brand": "Straplyn",
    "category": "Accessories",
    "description": "Upgrade your routine with the Straplyn Tote Bag Canvas \u2014 thoughtfully crafted by Straplyn to deliver consistent performance without compromising on design.",
    "features": [
      "Advanced safety features",
      "Long-lasting durability",
      "Sleek modern design",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Straplyn",
      "Model": "TOT-875",
      "Category": "Accessories",
      "Material": "Aluminum Alloy",
      "Color": "Charcoal",
      "Weight": "5.39 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 777,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 1249,
    "discount": 45,
    "price": 687,
    "saved": 562,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Tote+Bag+Canvas",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Tote+Bag+Canvas",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Tote+Bag+Canvas%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Tote+Bag+Canvas%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Tote+Bag+Canvas%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new"
    ]
  },
  {
    "id": "MDH-1093",
    "sku": "SKU109378",
    "name": "Gearloop Cap & Beanie Combo",
    "brand": "Gearloop",
    "category": "Accessories",
    "description": "Upgrade your routine with the Gearloop Cap & Beanie Combo \u2014 thoughtfully crafted by Gearloop to deliver consistent performance without compromising on design.",
    "features": [
      "Travel-friendly size",
      "Energy efficient design",
      "Multi-functional usage",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Gearloop",
      "Model": "CAP-193",
      "Category": "Accessories",
      "Material": "Aluminum Alloy",
      "Color": "White",
      "Weight": "5.29 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 544,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 1249,
    "discount": 20,
    "price": 999,
    "saved": 250,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Cap+&+Beanie+Combo",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Cap+&+Beanie+Combo",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Cap+&+Beanie+Combo%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Cap+&+Beanie+Combo%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Cap+&+Beanie+Combo%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1044",
    "sku": "SKU104445",
    "name": "Formaline Study Table",
    "brand": "Formaline",
    "category": "Furniture",
    "description": "Designed with the modern user in mind, the Formaline Study Table offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Travel-friendly size",
      "Adjustable settings",
      "Ergonomic and comfortable",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Formaline",
      "Model": "STU-324",
      "Category": "Furniture",
      "Material": "High-Grade Polymer",
      "Color": "Blue",
      "Weight": "4.09 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 775,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 799,
    "discount": 10,
    "price": 719,
    "saved": 80,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=Study+Table",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Study+Table",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Study+Table%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Study+Table%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=Study+Table%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1025",
    "sku": "SKU102545",
    "name": "Warmlyn Dinner Set 24-Piece",
    "brand": "Warmlyn",
    "category": "Home & Kitchen",
    "description": "Engineered for everyday reliability, the Warmlyn Dinner Set 24-Piece combines thoughtful design with dependable performance, making it a smart addition to your home & kitchen collection.",
    "features": [
      "Travel-friendly size",
      "Premium build quality",
      "Water & dust resistant",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Warmlyn",
      "Model": "DIN-458",
      "Category": "Home & Kitchen",
      "Material": "Stainless Steel",
      "Color": "Charcoal",
      "Weight": "0.59 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 95,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 9999,
    "discount": 40,
    "price": 5999,
    "saved": 4000,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Dinner+Set+24-Piece",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Dinner+Set+24-Piece",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Dinner+Set+24-Piece%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Dinner+Set+24-Piece%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Dinner+Set+24-Piece%0A(View+4)"
    ],
    "badges": [
      "deal",
      "featured"
    ]
  },
  {
    "id": "MDH-1105",
    "sku": "SKU110592",
    "name": "Blockzy Drone Mini Camera",
    "brand": "Blockzy",
    "category": "Toys",
    "description": "The Blockzy Drone Mini Camera from Blockzy blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Energy efficient design",
      "Skin/eco-friendly materials",
      "Premium build quality",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Blockzy",
      "Model": "DRO-988",
      "Category": "Toys",
      "Material": "High-Grade Polymer",
      "Color": "Navy",
      "Weight": "3.17 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 890,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 9999,
    "discount": 35,
    "price": 6499,
    "saved": 3500,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Drone+Mini+Camera",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Drone+Mini+Camera",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Drone+Mini+Camera%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Drone+Mini+Camera%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Drone+Mini+Camera%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new",
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1074",
    "sku": "SKU107413",
    "name": "Athlex Cycling Helmet",
    "brand": "Athlex",
    "category": "Sports",
    "description": "Designed with the modern user in mind, the Athlex Cycling Helmet offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "1-year manufacturer support",
      "Skin/eco-friendly materials",
      "Energy efficient design",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "CYC-820",
      "Category": "Sports",
      "Material": "Cotton Blend",
      "Color": "Blue",
      "Weight": "6.48 kg",
      "Country of Origin": "India"
    },
    "rating": 4.3,
    "reviewsCount": 408,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 7999,
    "discount": 20,
    "price": 6399,
    "saved": 1600,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Cycling+Helmet",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cycling+Helmet",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cycling+Helmet%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cycling+Helmet%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cycling+Helmet%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1091",
    "sku": "SKU109140",
    "name": "Poucha Phone Case Premium",
    "brand": "Poucha",
    "category": "Accessories",
    "description": "Designed with the modern user in mind, the Poucha Phone Case Premium offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Advanced safety features",
      "Water & dust resistant",
      "1-year manufacturer support",
      "Premium build quality"
    ],
    "specifications": {
      "Brand": "Poucha",
      "Model": "PHO-769",
      "Category": "Accessories",
      "Material": "Engineered Wood",
      "Color": "Charcoal",
      "Weight": "1.65 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 321,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 3499,
    "discount": 30,
    "price": 2449,
    "saved": 1050,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Phone+Case+Premium",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Phone+Case+Premium",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Phone+Case+Premium%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Phone+Case+Premium%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Phone+Case+Premium%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1075",
    "sku": "SKU107595",
    "name": "Trailforce Football Size 5",
    "brand": "Trailforce",
    "category": "Sports",
    "description": "The Trailforce Football Size 5 from Trailforce blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "1-year manufacturer support",
      "Ergonomic and comfortable",
      "Compact and lightweight",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Trailforce",
      "Model": "FOO-912",
      "Category": "Sports",
      "Material": "Engineered Wood",
      "Color": "Navy",
      "Weight": "1.57 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 309,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Football+Size+5",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Football+Size+5",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Football+Size+5%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Football+Size+5%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Football+Size+5%0A(View+4)"
    ],
    "badges": [
      "featured"
    ]
  },
  {
    "id": "MDH-1005",
    "sku": "SKU100543",
    "name": "Kryonix Power Bank 20000mAh",
    "brand": "Kryonix",
    "category": "Electronics",
    "description": "Upgrade your routine with the Kryonix Power Bank 20000mAh \u2014 thoughtfully crafted by Kryonix to deliver consistent performance without compromising on design.",
    "features": [
      "Long-lasting durability",
      "Easy to clean and maintain",
      "Compact and lightweight",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Kryonix",
      "Model": "POW-193",
      "Category": "Electronics",
      "Material": "Premium ABS Plastic",
      "Color": "Black",
      "Weight": "1.12 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 420,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 7999,
    "discount": 40,
    "price": 4799,
    "saved": 3200,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=Power+Bank+20000mAh",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Power+Bank+20000mAh",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Power+Bank+20000mAh%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Power+Bank+20000mAh%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=Power+Bank+20000mAh%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "trending"
    ]
  },
  {
    "id": "MDH-1095",
    "sku": "SKU109527",
    "name": "Gearloop Sling Crossbody Bag",
    "brand": "Gearloop",
    "category": "Accessories",
    "description": "The Gearloop Sling Crossbody Bag from Gearloop blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Sleek modern design",
      "Skin/eco-friendly materials",
      "Compact and lightweight",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Gearloop",
      "Model": "SLI-954",
      "Category": "Accessories",
      "Material": "Premium ABS Plastic",
      "Color": "Black",
      "Weight": "6.36 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 562,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 5999,
    "discount": 35,
    "price": 3899,
    "saved": 2100,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Sling+Crossbody+Bag",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sling+Crossbody+Bag",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sling+Crossbody+Bag%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sling+Crossbody+Bag%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Sling+Crossbody+Bag%0A(View+4)"
    ],
    "badges": [
      "deal",
      "trending"
    ]
  },
  {
    "id": "MDH-1100",
    "sku": "SKU110041",
    "name": "Blockzy Puzzle 500-Piece",
    "brand": "Blockzy",
    "category": "Toys",
    "description": "Upgrade your routine with the Blockzy Puzzle 500-Piece \u2014 thoughtfully crafted by Blockzy to deliver consistent performance without compromising on design.",
    "features": [
      "Skin/eco-friendly materials",
      "Long-lasting durability",
      "Noise-free smooth operation",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Blockzy",
      "Model": "PUZ-577",
      "Category": "Toys",
      "Material": "Aluminum Alloy",
      "Color": "Charcoal",
      "Weight": "2.43 kg",
      "Country of Origin": "India"
    },
    "rating": 4.2,
    "reviewsCount": 257,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 7999,
    "discount": 25,
    "price": 5999,
    "saved": 2000,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Puzzle+500-Piece",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Puzzle+500-Piece",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Puzzle+500-Piece%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Puzzle+500-Piece%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Puzzle+500-Piece%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1137",
    "sku": "SKU113755",
    "name": "Motorix Car Air Freshener Combo",
    "brand": "Motorix",
    "category": "Automotive",
    "description": "Upgrade your routine with the Motorix Car Air Freshener Combo \u2014 thoughtfully crafted by Motorix to deliver consistent performance without compromising on design.",
    "features": [
      "Ergonomic and comfortable",
      "Adjustable settings",
      "Compact and lightweight",
      "Premium build quality"
    ],
    "specifications": {
      "Brand": "Motorix",
      "Model": "CAR-975",
      "Category": "Automotive",
      "Material": "Cotton Blend",
      "Color": "Navy",
      "Weight": "4.9 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 318,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 2999,
    "discount": 50,
    "price": 1500,
    "saved": 1499,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Car+Air+Freshener+Combo",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Air+Freshener+Combo",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Air+Freshener+Combo%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Air+Freshener+Combo%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Air+Freshener+Combo%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1108",
    "sku": "SKU110850",
    "name": "Blockzy Building Robot Kit",
    "brand": "Blockzy",
    "category": "Toys",
    "description": "Engineered for everyday reliability, the Blockzy Building Robot Kit combines thoughtful design with dependable performance, making it a smart addition to your toys collection.",
    "features": [
      "Travel-friendly size",
      "Long-lasting durability",
      "Noise-free smooth operation",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Blockzy",
      "Model": "BUI-235",
      "Category": "Toys",
      "Material": "Premium ABS Plastic",
      "Color": "Blue",
      "Weight": "2.89 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 327,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 2499,
    "discount": 15,
    "price": 2124,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Building+Robot+Kit",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Robot+Kit",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Robot+Kit%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Robot+Kit%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Building+Robot+Kit%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1155",
    "sku": "SKU115585",
    "name": "Wagwell Pet Food Storage Container",
    "brand": "Wagwell",
    "category": "Pet Supplies",
    "description": "Engineered for everyday reliability, the Wagwell Pet Food Storage Container combines thoughtful design with dependable performance, making it a smart addition to your pet supplies collection.",
    "features": [
      "1-year manufacturer support",
      "Ergonomic and comfortable",
      "Water & dust resistant",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Wagwell",
      "Model": "PET-391",
      "Category": "Pet Supplies",
      "Material": "Premium ABS Plastic",
      "Color": "White",
      "Weight": "0.47 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 869,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 3999,
    "discount": 35,
    "price": 2599,
    "saved": 1400,
    "availability": "Only Few Left",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Pet+Food+Storage+Container",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Food+Storage+Container",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Food+Storage+Container%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Food+Storage+Container%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Food+Storage+Container%0A(View+4)"
    ],
    "badges": [
      "deal"
    ]
  },
  {
    "id": "MDH-1076",
    "sku": "SKU107618",
    "name": "Athlex Badminton Racket Set",
    "brand": "Athlex",
    "category": "Sports",
    "description": "Engineered for everyday reliability, the Athlex Badminton Racket Set combines thoughtful design with dependable performance, making it a smart addition to your sports collection.",
    "features": [
      "Travel-friendly size",
      "Skin/eco-friendly materials",
      "Sleek modern design",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "BAD-228",
      "Category": "Sports",
      "Material": "Engineered Wood",
      "Color": "Charcoal",
      "Weight": "0.62 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 748,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1999,
    "discount": 40,
    "price": 1199,
    "saved": 800,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Badminton+Racket+Set",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Badminton+Racket+Set",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Badminton+Racket+Set%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Badminton+Racket+Set%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Badminton+Racket+Set%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller"
    ]
  },
  {
    "id": "MDH-1128",
    "sku": "SKU112819",
    "name": "Stationex Stapler & Punch Set",
    "brand": "Stationex",
    "category": "Office Supplies",
    "description": "Designed with the modern user in mind, the Stationex Stapler & Punch Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Compact and lightweight",
      "Sleek modern design",
      "Advanced safety features",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Stationex",
      "Model": "STA-659",
      "Category": "Office Supplies",
      "Material": "High-Grade Polymer",
      "Color": "Blue",
      "Weight": "4.99 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 336,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 3999,
    "discount": 10,
    "price": 3599,
    "saved": 400,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Stapler+&+Punch+Set",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Stapler+&+Punch+Set",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Stapler+&+Punch+Set%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Stapler+&+Punch+Set%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Stapler+&+Punch+Set%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1007",
    "sku": "SKU100740",
    "name": "Zentek USB-C Hub",
    "brand": "Zentek",
    "category": "Electronics",
    "description": "The Zentek USB-C Hub from Zentek blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Energy efficient design",
      "Water & dust resistant",
      "Travel-friendly size",
      "1-year manufacturer support"
    ],
    "specifications": {
      "Brand": "Zentek",
      "Model": "USB-231",
      "Category": "Electronics",
      "Material": "High-Grade Polymer",
      "Color": "White",
      "Weight": "6.16 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 92,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 799,
    "discount": 25,
    "price": 599,
    "saved": 200,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/2F5CFF/FFFFFF?font=poppins&text=USB-C+Hub",
    "images": [
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=USB-C+Hub",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=USB-C+Hub%0A(View+2)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=USB-C+Hub%0A(View+3)",
      "https://placehold.co/700x700/2F5CFF/FFFFFF?font=poppins&text=USB-C+Hub%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1036",
    "sku": "SKU103695",
    "name": "Vestora Graphic T-Shirt",
    "brand": "Vestora",
    "category": "Fashion",
    "description": "Engineered for everyday reliability, the Vestora Graphic T-Shirt combines thoughtful design with dependable performance, making it a smart addition to your fashion collection.",
    "features": [
      "Travel-friendly size",
      "Ergonomic and comfortable",
      "Multi-functional usage",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Vestora",
      "Model": "GRA-565",
      "Category": "Fashion",
      "Material": "Premium ABS Plastic",
      "Color": "Graphite Grey",
      "Weight": "1.75 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 722,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 999,
    "discount": 20,
    "price": 799,
    "saved": 200,
    "availability": "Only Few Left",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Graphic+T-Shirt",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Graphic+T-Shirt",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Graphic+T-Shirt%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Graphic+T-Shirt%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Graphic+T-Shirt%0A(View+4)"
    ],
    "badges": [
      "new"
    ]
  },
  {
    "id": "MDH-1082",
    "sku": "SKU108297",
    "name": "Ironclad Cricket Bat Kashmir Willow",
    "brand": "Ironclad",
    "category": "Sports",
    "description": "Designed with the modern user in mind, the Ironclad Cricket Bat Kashmir Willow offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Sleek modern design",
      "Long-lasting durability",
      "Noise-free smooth operation",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Ironclad",
      "Model": "CRI-873",
      "Category": "Sports",
      "Material": "Stainless Steel",
      "Color": "Blue",
      "Weight": "3.98 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 111,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 4999,
    "discount": 15,
    "price": 4249,
    "saved": 750,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Cricket+Bat+Kashmir+Willow",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cricket+Bat+Kashmir+Willow",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cricket+Bat+Kashmir+Willow%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cricket+Bat+Kashmir+Willow%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Cricket+Bat+Kashmir+Willow%0A(View+4)"
    ],
    "badges": [
      "trending"
    ]
  },
  {
    "id": "MDH-1104",
    "sku": "SKU110460",
    "name": "Funtoro Toy Kitchen Set",
    "brand": "Funtoro",
    "category": "Toys",
    "description": "Designed with the modern user in mind, the Funtoro Toy Kitchen Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Advanced safety features",
      "Easy to clean and maintain",
      "Water & dust resistant",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Funtoro",
      "Model": "TOY-800",
      "Category": "Toys",
      "Material": "Premium ABS Plastic",
      "Color": "Charcoal",
      "Weight": "6.45 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 482,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 999,
    "discount": 35,
    "price": 649,
    "saved": 350,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/F76707/FFFFFF?font=poppins&text=Toy+Kitchen+Set",
    "images": [
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Toy+Kitchen+Set",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Toy+Kitchen+Set%0A(View+2)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Toy+Kitchen+Set%0A(View+3)",
      "https://placehold.co/700x700/F76707/FFFFFF?font=poppins&text=Toy+Kitchen+Set%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1015",
    "sku": "SKU101524",
    "name": "Hearthly Air Fryer 5L",
    "brand": "Hearthly",
    "category": "Home & Kitchen",
    "description": "Upgrade your routine with the Hearthly Air Fryer 5L \u2014 thoughtfully crafted by Hearthly to deliver consistent performance without compromising on design.",
    "features": [
      "Long-lasting durability",
      "Advanced safety features",
      "Skin/eco-friendly materials",
      "Compact and lightweight"
    ],
    "specifications": {
      "Brand": "Hearthly",
      "Model": "AIR-230",
      "Category": "Home & Kitchen",
      "Material": "Premium ABS Plastic",
      "Color": "Graphite Grey",
      "Weight": "2.47 kg",
      "Country of Origin": "India"
    },
    "rating": 4.4,
    "reviewsCount": 866,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 999,
    "discount": 20,
    "price": 799,
    "saved": 200,
    "availability": "Only Few Left",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Air+Fryer+5L",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Air+Fryer+5L",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Air+Fryer+5L%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Air+Fryer+5L%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Air+Fryer+5L%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1062",
    "sku": "SKU106276",
    "name": "Blossette Hair Straightener",
    "brand": "Blossette",
    "category": "Beauty",
    "description": "Engineered for everyday reliability, the Blossette Hair Straightener combines thoughtful design with dependable performance, making it a smart addition to your beauty collection.",
    "features": [
      "Sleek modern design",
      "1-year manufacturer support",
      "Noise-free smooth operation",
      "Long-lasting durability"
    ],
    "specifications": {
      "Brand": "Blossette",
      "Model": "HAI-908",
      "Category": "Beauty",
      "Material": "High-Grade Polymer",
      "Color": "Charcoal",
      "Weight": "2.28 kg",
      "Country of Origin": "India"
    },
    "rating": 4.1,
    "reviewsCount": 301,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 4999,
    "discount": 20,
    "price": 3999,
    "saved": 1000,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Hair+Straightener",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Straightener",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Straightener%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Straightener%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Hair+Straightener%0A(View+4)"
    ],
    "badges": [
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1133",
    "sku": "SKU113318",
    "name": "Gearhead Car Phone Mount",
    "brand": "Gearhead",
    "category": "Automotive",
    "description": "Engineered for everyday reliability, the Gearhead Car Phone Mount combines thoughtful design with dependable performance, making it a smart addition to your automotive collection.",
    "features": [
      "Long-lasting durability",
      "Energy efficient design",
      "Skin/eco-friendly materials",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Gearhead",
      "Model": "CAR-477",
      "Category": "Automotive",
      "Material": "Stainless Steel",
      "Color": "Graphite Grey",
      "Weight": "3.73 kg",
      "Country of Origin": "India"
    },
    "rating": 4.7,
    "reviewsCount": 330,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 3499,
    "discount": 30,
    "price": 2449,
    "saved": 1050,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Car+Phone+Mount",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Phone+Mount",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Phone+Mount%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Phone+Mount%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Car+Phone+Mount%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1039",
    "sku": "SKU103984",
    "name": "Draperie Ankle Boots",
    "brand": "Draperie",
    "category": "Fashion",
    "description": "Upgrade your routine with the Draperie Ankle Boots \u2014 thoughtfully crafted by Draperie to deliver consistent performance without compromising on design.",
    "features": [
      "Skin/eco-friendly materials",
      "Travel-friendly size",
      "Long-lasting durability",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Draperie",
      "Model": "ANK-566",
      "Category": "Fashion",
      "Material": "Engineered Wood",
      "Color": "Blue",
      "Weight": "6.38 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 469,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 5999,
    "discount": 45,
    "price": 3299,
    "saved": 2700,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/3B5BDB/FFFFFF?font=poppins&text=Ankle+Boots",
    "images": [
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Ankle+Boots",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Ankle+Boots%0A(View+2)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Ankle+Boots%0A(View+3)",
      "https://placehold.co/700x700/3B5BDB/FFFFFF?font=poppins&text=Ankle+Boots%0A(View+4)"
    ],
    "badges": [
      "deal",
      "bestseller"
    ]
  },
  {
    "id": "MDH-1049",
    "sku": "SKU104941",
    "name": "Restly TV Stand Unit",
    "brand": "Restly",
    "category": "Furniture",
    "description": "The Restly TV Stand Unit from Restly blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "Skin/eco-friendly materials",
      "Easy to clean and maintain",
      "Advanced safety features",
      "Adjustable settings"
    ],
    "specifications": {
      "Brand": "Restly",
      "Model": "TV-436",
      "Category": "Furniture",
      "Material": "Stainless Steel",
      "Color": "Navy",
      "Weight": "0.17 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 795,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 1249,
    "discount": 25,
    "price": 937,
    "saved": 312,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/5C7CFA/FFFFFF?font=poppins&text=TV+Stand+Unit",
    "images": [
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=TV+Stand+Unit",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=TV+Stand+Unit%0A(View+2)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=TV+Stand+Unit%0A(View+3)",
      "https://placehold.co/700x700/5C7CFA/FFFFFF?font=poppins&text=TV+Stand+Unit%0A(View+4)"
    ],
    "badges": [
      "new",
      "featured"
    ]
  },
  {
    "id": "MDH-1152",
    "sku": "SKU115287",
    "name": "Barkbox Pet Carrier Bag",
    "brand": "Barkbox",
    "category": "Pet Supplies",
    "description": "Upgrade your routine with the Barkbox Pet Carrier Bag \u2014 thoughtfully crafted by Barkbox to deliver consistent performance without compromising on design.",
    "features": [
      "Compact and lightweight",
      "Advanced safety features",
      "Adjustable settings",
      "Multi-functional usage"
    ],
    "specifications": {
      "Brand": "Barkbox",
      "Model": "PET-139",
      "Category": "Pet Supplies",
      "Material": "Cotton Blend",
      "Color": "Graphite Grey",
      "Weight": "4.53 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 424,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 3499,
    "discount": 10,
    "price": 3149,
    "saved": 350,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Pet+Carrier+Bag",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Carrier+Bag",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Carrier+Bag%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Carrier+Bag%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Carrier+Bag%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1067",
    "sku": "SKU106793",
    "name": "Glowvana Sunscreen SPF50",
    "brand": "Glowvana",
    "category": "Beauty",
    "description": "The Glowvana Sunscreen SPF50 from Glowvana blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "features": [
      "1-year manufacturer support",
      "Adjustable settings",
      "Travel-friendly size",
      "Water & dust resistant"
    ],
    "specifications": {
      "Brand": "Glowvana",
      "Model": "SUN-877",
      "Category": "Beauty",
      "Material": "High-Grade Polymer",
      "Color": "White",
      "Weight": "3.0 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 305,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 2499,
    "discount": 20,
    "price": 1999,
    "saved": 500,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "15-Day Return & Refund",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/845EF7/FFFFFF?font=poppins&text=Sunscreen+SPF50",
    "images": [
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Sunscreen+SPF50",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Sunscreen+SPF50%0A(View+2)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Sunscreen+SPF50%0A(View+3)",
      "https://placehold.co/700x700/845EF7/FFFFFF?font=poppins&text=Sunscreen+SPF50%0A(View+4)"
    ],
    "badges": [
      "trending",
      "featured"
    ]
  },
  {
    "id": "MDH-1147",
    "sku": "SKU114765",
    "name": "Barkbox Pet Bed Cushion",
    "brand": "Barkbox",
    "category": "Pet Supplies",
    "description": "Designed with the modern user in mind, the Barkbox Pet Bed Cushion offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Easy to clean and maintain",
      "Sleek modern design",
      "Water & dust resistant",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Barkbox",
      "Model": "PET-776",
      "Category": "Pet Supplies",
      "Material": "Engineered Wood",
      "Color": "Graphite Grey",
      "Weight": "1.66 kg",
      "Country of Origin": "India"
    },
    "rating": 3.7,
    "reviewsCount": 222,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1249,
    "discount": 10,
    "price": 1124,
    "saved": 125,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Pet+Bed+Cushion",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Bed+Cushion",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Bed+Cushion%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Bed+Cushion%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Pet+Bed+Cushion%0A(View+4)"
    ],
    "badges": [
      "new"
    ]
  },
  {
    "id": "MDH-1084",
    "sku": "SKU108486",
    "name": "Athlex Swimming Goggles",
    "brand": "Athlex",
    "category": "Sports",
    "description": "Engineered for everyday reliability, the Athlex Swimming Goggles combines thoughtful design with dependable performance, making it a smart addition to your sports collection.",
    "features": [
      "Noise-free smooth operation",
      "Advanced safety features",
      "Adjustable settings",
      "Easy to clean and maintain"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "SWI-697",
      "Category": "Sports",
      "Material": "Cotton Blend",
      "Color": "Blue",
      "Weight": "3.48 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 813,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      }
    ],
    "mrp": 3499,
    "discount": 30,
    "price": 2449,
    "saved": 1050,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Swimming+Goggles",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Swimming+Goggles",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Swimming+Goggles%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Swimming+Goggles%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Swimming+Goggles%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new"
    ]
  },
  {
    "id": "MDH-1071",
    "sku": "SKU107193",
    "name": "Athlex Yoga Mat Premium",
    "brand": "Athlex",
    "category": "Sports",
    "description": "Upgrade your routine with the Athlex Yoga Mat Premium \u2014 thoughtfully crafted by Athlex to deliver consistent performance without compromising on design.",
    "features": [
      "Sleek modern design",
      "1-year manufacturer support",
      "Water & dust resistant",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "YOG-447",
      "Category": "Sports",
      "Material": "Stainless Steel",
      "Color": "White",
      "Weight": "4.54 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 388,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 2499,
    "discount": 30,
    "price": 1749,
    "saved": 750,
    "availability": "In Stock",
    "warranty": "No Warranty (Consumable Item)",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "7-10 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Yoga+Mat+Premium",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Yoga+Mat+Premium",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Yoga+Mat+Premium%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Yoga+Mat+Premium%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Yoga+Mat+Premium%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1087",
    "sku": "SKU108754",
    "name": "Poucha Laptop Backpack",
    "brand": "Poucha",
    "category": "Accessories",
    "description": "Designed with the modern user in mind, the Poucha Laptop Backpack offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Water & dust resistant",
      "Energy efficient design",
      "Long-lasting durability",
      "Travel-friendly size"
    ],
    "specifications": {
      "Brand": "Poucha",
      "Model": "LAP-865",
      "Category": "Accessories",
      "Material": "Cotton Blend",
      "Color": "Blue",
      "Weight": "1.43 kg",
      "Country of Origin": "India"
    },
    "rating": 4.0,
    "reviewsCount": 306,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 9999,
    "discount": 20,
    "price": 7999,
    "saved": 2000,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Laptop+Backpack",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Laptop+Backpack",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Laptop+Backpack%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Laptop+Backpack%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Laptop+Backpack%0A(View+4)"
    ],
    "badges": []
  },
  {
    "id": "MDH-1017",
    "sku": "SKU101761",
    "name": "Kitchenora Non-Stick Cookware Set",
    "brand": "Kitchenora",
    "category": "Home & Kitchen",
    "description": "Upgrade your routine with the Kitchenora Non-Stick Cookware Set \u2014 thoughtfully crafted by Kitchenora to deliver consistent performance without compromising on design.",
    "features": [
      "Ergonomic and comfortable",
      "Long-lasting durability",
      "Multi-functional usage",
      "Skin/eco-friendly materials"
    ],
    "specifications": {
      "Brand": "Kitchenora",
      "Model": "NON-795",
      "Category": "Home & Kitchen",
      "Material": "Aluminum Alloy",
      "Color": "Graphite Grey",
      "Weight": "6.11 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 803,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 2499,
    "discount": 30,
    "price": 1749,
    "saved": 750,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Non-Stick+Cookware+Set",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Non-Stick+Cookware+Set",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Non-Stick+Cookware+Set%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Non-Stick+Cookware+Set%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Non-Stick+Cookware+Set%0A(View+4)"
    ],
    "badges": [
      "bestseller"
    ]
  },
  {
    "id": "MDH-1124",
    "sku": "SKU112493",
    "name": "Papertone Sticky Notes Combo",
    "brand": "Papertone",
    "category": "Office Supplies",
    "description": "Engineered for everyday reliability, the Papertone Sticky Notes Combo combines thoughtful design with dependable performance, making it a smart addition to your office supplies collection.",
    "features": [
      "Energy efficient design",
      "Multi-functional usage",
      "Long-lasting durability",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Papertone",
      "Model": "STI-480",
      "Category": "Office Supplies",
      "Material": "High-Grade Polymer",
      "Color": "Charcoal",
      "Weight": "1.2 kg",
      "Country of Origin": "India"
    },
    "rating": 4.8,
    "reviewsCount": 292,
    "reviews": [
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      }
    ],
    "mrp": 1999,
    "discount": 20,
    "price": 1599,
    "saved": 400,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/343A40/FFFFFF?font=poppins&text=Sticky+Notes+Combo",
    "images": [
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Sticky+Notes+Combo",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Sticky+Notes+Combo%0A(View+2)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Sticky+Notes+Combo%0A(View+3)",
      "https://placehold.co/700x700/343A40/FFFFFF?font=poppins&text=Sticky+Notes+Combo%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new",
      "trending"
    ]
  },
  {
    "id": "MDH-1028",
    "sku": "SKU102821",
    "name": "Kitchenora Food Steamer",
    "brand": "Kitchenora",
    "category": "Home & Kitchen",
    "description": "Designed with the modern user in mind, the Kitchenora Food Steamer offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Advanced safety features",
      "1-year manufacturer support",
      "Multi-functional usage",
      "Sleek modern design"
    ],
    "specifications": {
      "Brand": "Kitchenora",
      "Model": "FOO-129",
      "Category": "Home & Kitchen",
      "Material": "Cotton Blend",
      "Color": "Graphite Grey",
      "Weight": "1.3 kg",
      "Country of Origin": "India"
    },
    "rating": 3.9,
    "reviewsCount": 487,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1999,
    "discount": 45,
    "price": 1099,
    "saved": 900,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/4C6EF5/FFFFFF?font=poppins&text=Food+Steamer",
    "images": [
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Food+Steamer",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Food+Steamer%0A(View+2)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Food+Steamer%0A(View+3)",
      "https://placehold.co/700x700/4C6EF5/FFFFFF?font=poppins&text=Food+Steamer%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new"
    ]
  },
  {
    "id": "MDH-1077",
    "sku": "SKU107729",
    "name": "Ironclad Skipping Rope",
    "brand": "Ironclad",
    "category": "Sports",
    "description": "Engineered for everyday reliability, the Ironclad Skipping Rope combines thoughtful design with dependable performance, making it a smart addition to your sports collection.",
    "features": [
      "Easy to clean and maintain",
      "Long-lasting durability",
      "Skin/eco-friendly materials",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Ironclad",
      "Model": "SKI-356",
      "Category": "Sports",
      "Material": "Stainless Steel",
      "Color": "Charcoal",
      "Weight": "6.22 kg",
      "Country of Origin": "India"
    },
    "rating": 3.8,
    "reviewsCount": 738,
    "reviews": [
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 1999,
    "discount": 20,
    "price": 1599,
    "saved": 400,
    "availability": "Only Few Left",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Skipping+Rope",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Skipping+Rope",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Skipping+Rope%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Skipping+Rope%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Skipping+Rope%0A(View+4)"
    ],
    "badges": [
      "new"
    ]
  },
  {
    "id": "MDH-1073",
    "sku": "SKU107328",
    "name": "Athlex Resistance Band Set",
    "brand": "Athlex",
    "category": "Sports",
    "description": "Designed with the modern user in mind, the Athlex Resistance Band Set offers a perfect balance of style, durability, and everyday convenience.",
    "features": [
      "Easy to clean and maintain",
      "Noise-free smooth operation",
      "Multi-functional usage",
      "Long-lasting durability"
    ],
    "specifications": {
      "Brand": "Athlex",
      "Model": "RES-492",
      "Category": "Sports",
      "Material": "Aluminum Alloy",
      "Color": "Black",
      "Weight": "3.99 kg",
      "Country of Origin": "India"
    },
    "rating": 3.6,
    "reviewsCount": 80,
    "reviews": [
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Rahul K.",
        "rating": 5,
        "text": "Exceeded my expectations, works exactly as shown. Packaging was solid too."
      }
    ],
    "mrp": 4999,
    "discount": 45,
    "price": 2749,
    "saved": 2250,
    "availability": "In Stock",
    "warranty": "6 Months",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "2-4 Business Days",
    "image": "https://placehold.co/500x500/1971C2/FFFFFF?font=poppins&text=Resistance+Band+Set",
    "images": [
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Resistance+Band+Set",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Resistance+Band+Set%0A(View+2)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Resistance+Band+Set%0A(View+3)",
      "https://placehold.co/700x700/1971C2/FFFFFF?font=poppins&text=Resistance+Band+Set%0A(View+4)"
    ],
    "badges": [
      "deal",
      "featured"
    ]
  },
  {
    "id": "MDH-1153",
    "sku": "SKU115339",
    "name": "Pawsome Dog Training Clicker",
    "brand": "Pawsome",
    "category": "Pet Supplies",
    "description": "Upgrade your routine with the Pawsome Dog Training Clicker \u2014 thoughtfully crafted by Pawsome to deliver consistent performance without compromising on design.",
    "features": [
      "Noise-free smooth operation",
      "Adjustable settings",
      "Long-lasting durability",
      "Ergonomic and comfortable"
    ],
    "specifications": {
      "Brand": "Pawsome",
      "Model": "DOG-719",
      "Category": "Pet Supplies",
      "Material": "High-Grade Polymer",
      "Color": "Black",
      "Weight": "1.34 kg",
      "Country of Origin": "India"
    },
    "rating": 5.0,
    "reviewsCount": 465,
    "reviews": [
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Sneha R.",
        "rating": 4,
        "text": "Nice value for money. Minor delay in delivery but product quality is great."
      },
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      }
    ],
    "mrp": 1249,
    "discount": 30,
    "price": 874,
    "saved": 375,
    "availability": "In Stock",
    "warranty": "2 Years",
    "returnPolicy": "7-Day Easy Return",
    "deliveryTime": "5-7 Business Days",
    "image": "https://placehold.co/500x500/E8590C/FFFFFF?font=poppins&text=Dog+Training+Clicker",
    "images": [
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Training+Clicker",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Training+Clicker%0A(View+2)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Training+Clicker%0A(View+3)",
      "https://placehold.co/700x700/E8590C/FFFFFF?font=poppins&text=Dog+Training+Clicker%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "new"
    ]
  },
  {
    "id": "MDH-1144",
    "sku": "SKU114426",
    "name": "Torquefit Microfiber Cleaning Kit",
    "brand": "Torquefit",
    "category": "Automotive",
    "description": "Engineered for everyday reliability, the Torquefit Microfiber Cleaning Kit combines thoughtful design with dependable performance, making it a smart addition to your automotive collection.",
    "features": [
      "Sleek modern design",
      "Adjustable settings",
      "Noise-free smooth operation",
      "Advanced safety features"
    ],
    "specifications": {
      "Brand": "Torquefit",
      "Model": "MIC-286",
      "Category": "Automotive",
      "Material": "Aluminum Alloy",
      "Color": "Graphite Grey",
      "Weight": "6.0 kg",
      "Country of Origin": "India"
    },
    "rating": 4.9,
    "reviewsCount": 598,
    "reviews": [
      {
        "name": "Vikram T.",
        "rating": 5,
        "text": "This is my second order from this store, always reliable quality."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      }
    ],
    "mrp": 1249,
    "discount": 10,
    "price": 1124,
    "saved": 125,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "No Return (Hygiene Product)",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/212529/FFFFFF?font=poppins&text=Microfiber+Cleaning+Kit",
    "images": [
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Microfiber+Cleaning+Kit",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Microfiber+Cleaning+Kit%0A(View+2)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Microfiber+Cleaning+Kit%0A(View+3)",
      "https://placehold.co/700x700/212529/FFFFFF?font=poppins&text=Microfiber+Cleaning+Kit%0A(View+4)"
    ],
    "badges": [
      "bestseller",
      "featured"
    ]
  },
  {
    "id": "MDH-1096",
    "sku": "SKU109614",
    "name": "Carrio Umbrella Auto-Open",
    "brand": "Carrio",
    "category": "Accessories",
    "description": "Engineered for everyday reliability, the Carrio Umbrella Auto-Open combines thoughtful design with dependable performance, making it a smart addition to your accessories collection.",
    "features": [
      "Easy to clean and maintain",
      "1-year manufacturer support",
      "Energy efficient design",
      "Noise-free smooth operation"
    ],
    "specifications": {
      "Brand": "Carrio",
      "Model": "UMB-557",
      "Category": "Accessories",
      "Material": "Aluminum Alloy",
      "Color": "Charcoal",
      "Weight": "4.62 kg",
      "Country of Origin": "India"
    },
    "rating": 4.5,
    "reviewsCount": 28,
    "reviews": [
      {
        "name": "Arjun M.",
        "rating": 5,
        "text": "Really happy with this purchase, quality feels premium and delivery was quick."
      },
      {
        "name": "Priya S.",
        "rating": 4,
        "text": "Good product overall, matches the description. Would recommend."
      },
      {
        "name": "Ananya D.",
        "rating": 3,
        "text": "Decent product, does the job but could be improved slightly."
      }
    ],
    "mrp": 9999,
    "discount": 40,
    "price": 5999,
    "saved": 4000,
    "availability": "In Stock",
    "warranty": "1 Year",
    "returnPolicy": "10-Day Replacement Only",
    "deliveryTime": "3-5 Business Days",
    "image": "https://placehold.co/500x500/0CA678/FFFFFF?font=poppins&text=Umbrella+Auto-Open",
    "images": [
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Umbrella+Auto-Open",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Umbrella+Auto-Open%0A(View+2)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Umbrella+Auto-Open%0A(View+3)",
      "https://placehold.co/700x700/0CA678/FFFFFF?font=poppins&text=Umbrella+Auto-Open%0A(View+4)"
    ],
    "badges": [
      "deal",
      "new",
      "featured"
    ]
  }
];
