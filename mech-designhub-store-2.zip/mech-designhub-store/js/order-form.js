/* ==========================================================================
   MECH DESIGNHUB — order-form.js
   Buy Now modal: order form -> validation -> order object -> success page
   ========================================================================== */

const ORDER_STATE = { product: null, qty: 1 };

function openBuyNow(productId) {
  const p = findProduct(productId);
  if (!p) { showToast("Product not found", "error"); return; }
  ORDER_STATE.product = p;
  ORDER_STATE.qty = 1;

  const overlay = openModal(buyNowFormHTML(p), "buynow-modal");
  bindBuyNowForm();
}
window.openBuyNow = openBuyNow;

function buyNowFormHTML(p) {
  return `
  <div class="modal-head">
    <strong><i class="fa-solid fa-bolt" style="color:var(--blue-600);"></i> Complete Your Order</strong>
    <button class="modal-close" onclick="closeModal('buynow-modal')"><i class="fa-solid fa-xmark"></i></button>
  </div>
  <div class="modal-body">
    <div class="order-summary-box">
      <img src="${p.image}" alt="${p.name}">
      <div>
        <div class="os-name">${p.name}</div>
        <div class="os-id mono">ID: ${p.id} &nbsp;·&nbsp; SKU: ${p.sku}</div>
        <div class="qty-stepper" style="margin-top:8px;">
          <button type="button" id="qty-minus">−</button>
          <span id="qty-value">1</span>
          <button type="button" id="qty-plus">+</button>
        </div>
      </div>
      <div class="os-price">
        <b id="os-total" class="mono">${STORE.currency(p.price)}</b>
        <div style="font-size:11px;color:var(--gray-500);">Unit: ${STORE.currency(p.price)}</div>
      </div>
    </div>

    <form id="order-form" novalidate>
      <fieldset class="form-fieldset">
        <legend><i class="fa-solid fa-user"></i> Customer Information</legend>
        <div class="form-row">
          <div class="form-group">
            <label>Full Name <span class="req">*</span></label>
            <input type="text" name="fullName" required>
            <span class="field-error">Please enter your full name</span>
          </div>
          <div class="form-group">
            <label>Mobile Number <span class="req">*</span></label>
            <input type="tel" name="mobile" placeholder="10-digit mobile number" required maxlength="10">
            <span class="field-error">Enter a valid 10-digit mobile number</span>
          </div>
        </div>
        <div class="form-group">
          <label>Email (Optional)</label>
          <input type="email" name="email" placeholder="you@example.com">
          <span class="field-error">Enter a valid email address</span>
        </div>
      </fieldset>

      <fieldset class="form-fieldset">
        <legend><i class="fa-solid fa-location-dot"></i> Delivery Address</legend>
        <div class="form-row">
          <div class="form-group">
            <label>House / Flat Number <span class="req">*</span></label>
            <input type="text" name="houseNo" required>
            <span class="field-error">Required</span>
          </div>
          <div class="form-group">
            <label>Apartment / Building</label>
            <input type="text" name="apartment">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Street <span class="req">*</span></label>
            <input type="text" name="street" required>
            <span class="field-error">Required</span>
          </div>
          <div class="form-group">
            <label>Area / Locality <span class="req">*</span></label>
            <input type="text" name="area" required>
            <span class="field-error">Required</span>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Landmark</label>
            <input type="text" name="landmark">
          </div>
          <div class="form-group">
            <label>City <span class="req">*</span></label>
            <input type="text" name="city" required>
            <span class="field-error">Required</span>
          </div>
        </div>
        <div class="form-row cols-3">
          <div class="form-group">
            <label>District <span class="req">*</span></label>
            <input type="text" name="district" required>
            <span class="field-error">Required</span>
          </div>
          <div class="form-group">
            <label>State <span class="req">*</span></label>
            <input type="text" name="state" required>
            <span class="field-error">Required</span>
          </div>
          <div class="form-group">
            <label>PIN Code <span class="req">*</span></label>
            <input type="text" name="pincode" required maxlength="6" placeholder="6-digit PIN">
            <span class="field-error">Enter a valid 6-digit PIN code</span>
          </div>
        </div>
        <div class="form-group">
          <label>Country <span class="req">*</span></label>
          <input type="text" name="country" value="India" required>
          <span class="field-error">Required</span>
        </div>
      </fieldset>

      <div class="form-actions">
        <button type="button" class="btn btn-outline btn-block" onclick="closeModal('buynow-modal')">Cancel</button>
        <button type="submit" class="btn btn-primary btn-block"><i class="fa-solid fa-file-invoice"></i> Generate Order</button>
      </div>
    </form>
  </div>`;
}

function bindBuyNowForm() {
  const minus = document.getElementById("qty-minus");
  const plus = document.getElementById("qty-plus");
  const qtyVal = document.getElementById("qty-value");
  const totalEl = document.getElementById("os-total");

  function refreshQty() {
    qtyVal.textContent = ORDER_STATE.qty;
    totalEl.textContent = STORE.currency(ORDER_STATE.product.price * ORDER_STATE.qty);
  }
  minus?.addEventListener("click", () => { if (ORDER_STATE.qty > 1) { ORDER_STATE.qty--; refreshQty(); } });
  plus?.addEventListener("click", () => { if (ORDER_STATE.qty < 10) { ORDER_STATE.qty++; refreshQty(); } });

  const form = document.getElementById("order-form");
  form?.addEventListener("submit", (e) => {
    e.preventDefault();
    if (validateOrderForm(form)) submitOrder(form);
  });
}

function setFieldError(input, show) {
  input.classList.toggle("error", show);
  const err = input.parentElement.querySelector(".field-error");
  err?.classList.toggle("show", show);
}

function validateOrderForm(form) {
  let valid = true;
  const required = form.querySelectorAll("[required]");
  required.forEach(input => {
    const ok = input.value.trim().length > 0;
    if (!ok) valid = false;
    if (input.name !== "mobile" && input.name !== "pincode") setFieldError(input, !ok);
  });

  const mobile = form.mobile;
  const mobileOk = /^[6-9]\d{9}$/.test(mobile.value.trim());
  setFieldError(mobile, !mobileOk);
  if (!mobileOk) valid = false;

  const pincode = form.pincode;
  const pinOk = /^\d{6}$/.test(pincode.value.trim());
  setFieldError(pincode, !pinOk);
  if (!pinOk) valid = false;

  const email = form.email;
  if (email.value.trim()) {
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());
    setFieldError(email, !emailOk);
    if (!emailOk) valid = false;
  } else {
    setFieldError(email, false);
  }

  if (!valid) showToast("Please fix the highlighted fields", "error");
  return valid;
}

function generateOrderId() {
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `MDH${Date.now().toString().slice(-7)}${rand}`;
}
function generateInvoiceNumber() {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  return `INV-${ymd}-${Math.floor(1000 + Math.random() * 9000)}`;
}
function formatDateLong(d) {
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function estimateDeliveryDate(deliveryTimeStr) {
  const match = deliveryTimeStr.match(/(\d+)-(\d+)/);
  const days = match ? parseInt(match[2], 10) : 7;
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d;
}

function submitOrder(form) {
  const fd = new FormData(form);
  const p = ORDER_STATE.product;
  const qty = ORDER_STATE.qty;
  const orderDate = new Date();

  const order = {
    orderId: generateOrderId(),
    invoiceNumber: generateInvoiceNumber(),
    orderDate: formatDateLong(orderDate),
    estDelivery: formatDateLong(estimateDeliveryDate(p.deliveryTime)),
    customer: {
      fullName: fd.get("fullName").trim(),
      mobile: fd.get("mobile").trim(),
      email: fd.get("email").trim(),
    },
    address: {
      houseNo: fd.get("houseNo").trim(),
      apartment: fd.get("apartment").trim(),
      street: fd.get("street").trim(),
      area: fd.get("area").trim(),
      landmark: fd.get("landmark").trim(),
      city: fd.get("city").trim(),
      district: fd.get("district").trim(),
      state: fd.get("state").trim(),
      pincode: fd.get("pincode").trim(),
      country: fd.get("country").trim(),
    },
    product: { id: p.id, sku: p.sku, name: p.name, brand: p.brand, image: p.image },
    qty,
    unitPrice: p.price,
    totalPrice: p.price * qty,
  };

  localStorage.setItem("mdh_last_order", JSON.stringify(order));
  showToast("Order form generated!", "success");
  closeModal("buynow-modal");
  setTimeout(() => { window.location.href = "order-success.html"; }, 400);
}
