# -*- coding: utf-8 -*-
from build_common import IG_URL

FAQS = [
    ("How do I place an order?", "Browse products, open the one you want, and click \"Buy Now.\" Fill in your delivery details, generate the PDF order sheet, then send that PDF to our Instagram account via Direct Message. Our team verifies and confirms it manually."),
    ("Do I need to create an account?", "No. This store has no login or signup — you can browse and generate an order sheet as a guest every time."),
    ("How do I pay for my order?", "We don't collect payment on this website. Once your order is verified over Instagram DM, our team will share available payment options directly with you."),
    ("Is Cash on Delivery (COD) available?", "COD availability depends on your location and the product. Ask our team on Instagram after sending your order sheet and they'll confirm for your PIN code."),
    ("How long does delivery take?", "Delivery time varies by product and is shown on each product page, typically between 3–10 business days after order confirmation."),
    ("Can I track my order?", "Yes — once confirmed, our team will share tracking details with you over Instagram DM or email."),
    ("What if I want to cancel or change my order?", "Message us on Instagram with your Order ID as soon as possible. Orders can usually be changed or cancelled before they are marked as shipped."),
    ("What is your return policy?", "Return policy varies by product and is listed on each product's detail page — ranging from 7–15 day returns to no-return for hygiene items."),
    ("Is my information safe?", "Your order details are only stored in your browser (locally) until you send them to us. We don't run a backend database — your data isn't transmitted anywhere except the PDF you choose to send us."),
    ("Why do I have to send the PDF via Instagram instead of checking out online?", "We intentionally keep this a manually verified, backend-free store. It lets a real person double-check stock, pricing and your address before anything ships — reducing errors on both sides."),
]

def faq_body():
    items = "\n".join(f"""
    <div class="accordion-item">
      <div class="accordion-head">{q}<i class="fa-solid fa-chevron-down"></i></div>
      <div class="accordion-body"><div class="accordion-body-inner">{a}</div></div>
    </div>""" for q, a in FAQS)
    return f"""
<div class="page-hero">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / FAQ</div>
    <h1 class="section-title mt-0">Frequently Asked Questions</h1>
    <p class="section-sub" style="margin:0 auto;">Everything you need to know about ordering, delivery and returns.</p>
  </div>
</div>
<section class="section">
  <div class="container" style="max-width:760px;">
    {items}
  </div>
</section>
<section class="section-tight" style="background:#fff;padding-top:0;">
  <div class="container">
    <div class="ig-band" data-aos="fade-up">
      <div><h3><i class="fa-brands fa-instagram"></i> Still have questions?</h3><p>Our team is happy to help — just send us a DM.</p></div>
      <a href="{IG_URL}" target="_blank" rel="noopener" class="btn" style="background:#fff;color:#dd2a7b;"><i class="fa-brands fa-instagram"></i> Ask on Instagram</a>
    </div>
  </div>
</section>
"""


def privacy_body():
    return """
<div class="page-hero">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / Privacy Policy</div>
    <h1 class="section-title mt-0">Privacy Policy</h1>
    <p class="section-sub" style="margin:0 auto;">Last updated: July 2026</p>
  </div>
</div>
<section class="section">
  <div class="container policy-content" style="max-width:800px;">
    <h2>1. Overview</h2>
    <p>Mech DesignHub is a frontend-only demo storefront. This site has no backend server or database — nearly everything you see is generated and stored inside your own browser. This policy explains what limited data is involved and how it's handled.</p>

    <h2>2. Information We Collect</h2>
    <ul>
      <li>Browsing preferences such as wishlist items and recently viewed products, stored locally in your browser using <code>localStorage</code>.</li>
      <li>Order details you voluntarily type into the "Buy Now" form (name, mobile number, email, delivery address) — used only to generate your downloadable PDF order sheet.</li>
      <li>Basic, non-identifying analytics may apply if this site is hosted with a third-party analytics tool.</li>
    </ul>

    <h2>3. How We Use Your Information</h2>
    <p>Information entered into the order form is used solely to populate your PDF order sheet. This data stays in your browser and is only shared with us if and when you choose to send the generated PDF to our Instagram account.</p>

    <h2>4. Data Sharing via Instagram</h2>
    <p>When you voluntarily send your order PDF to our Instagram Direct Messages, that transfer is governed by Instagram/Meta's own privacy policy in addition to this one. We only use the information in that PDF to verify, confirm and fulfill your order.</p>

    <h2>5. Cookies &amp; Local Storage</h2>
    <p>We use your browser's local storage (not tracking cookies) to remember your wishlist and recently viewed items between visits. Clearing your browser data will remove this information.</p>

    <h2>6. Data Security</h2>
    <p>Because this site has no backend database, there is no central server storing your personal details — data lives in your browser until you choose to export it as a PDF. Please keep your device secure, as you would for any sensitive information.</p>

    <h2>7. Children's Privacy</h2>
    <p>This store is not directed at children under 13, and we do not knowingly collect information from children.</p>

    <h2>8. Changes to This Policy</h2>
    <p>We may update this policy occasionally. Continued use of the site after changes means you accept the revised policy.</p>

    <h2>9. Contact Us</h2>
    <p>Questions about this policy? Reach us at orders.mechdesignhub@gmail.com or via Instagram DM at @mech_designhub.</p>
  </div>
</section>
"""


def terms_body():
    return """
<div class="page-hero">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / Terms &amp; Conditions</div>
    <h1 class="section-title mt-0">Terms &amp; Conditions</h1>
    <p class="section-sub" style="margin:0 auto;">Last updated: July 2026</p>
  </div>
</div>
<section class="section">
  <div class="container policy-content" style="max-width:800px;">
    <h2>1. Acceptance of Terms</h2>
    <p>By browsing Mech DesignHub and generating an order sheet, you agree to these Terms &amp; Conditions.</p>

    <h2>2. Nature of Our Service</h2>
    <p>Mech DesignHub is a manually-verified dropshipping storefront. This website does not process payments, does not require an account, and does not automatically confirm any order. Every order is reviewed and confirmed by a real team member through Instagram Direct Message.</p>

    <h2>3. How Orders Work</h2>
    <ul>
      <li>Selecting "Buy Now" and completing the delivery form generates a downloadable PDF order sheet — it does not place a binding order by itself.</li>
      <li>An order is only considered submitted once you send the generated PDF to our official Instagram account, <a href="https://www.instagram.com/mech_designhub/" target="_blank" rel="noopener">@mech_designhub</a>.</li>
      <li>Orders are confirmed only after our team manually verifies product availability, pricing and your delivery details.</li>
    </ul>

    <h2>4. Pricing &amp; Payment</h2>
    <p>All prices are shown in Indian Rupees (₹) and include the MRP, discount and final selling price. No online payment is collected through this website; accepted payment methods will be shared with you directly once your order is verified.</p>

    <h2>5. Shipping &amp; Delivery</h2>
    <p>Estimated delivery windows are shown on each product page and are approximate. Actual delivery times may vary based on your location, courier availability and order verification time.</p>

    <h2>6. Returns &amp; Refunds</h2>
    <p>Each product lists its own return policy on its detail page. To initiate a return, contact us via Instagram DM or email with your Order ID within the applicable window.</p>

    <h2>7. User Responsibilities</h2>
    <p>You agree to provide accurate delivery and contact information. Mech DesignHub is not responsible for delays or delivery failures caused by incorrect information submitted in the order form.</p>

    <h2>8. Limitation of Liability</h2>
    <p>This is a demo, frontend-only storefront template. Product data, pricing and availability shown are for demonstration purposes and are subject to change or manual correction during order verification.</p>

    <h2>9. Governing Law</h2>
    <p>These terms are governed by the laws of India, without regard to conflict-of-law principles.</p>

    <h2>10. Contact Us</h2>
    <p>For any questions about these terms, reach us at orders.mechdesignhub@gmail.com or via Instagram DM at @mech_designhub.</p>
  </div>
</section>
"""


def notfound_body():
    return """
<div class="error-page container">
  <div>
    <div class="error-code">404</div>
    <h2 class="section-title">Page not found</h2>
    <p class="section-sub" style="margin:0 auto 26px;">The page you're looking for may have been moved, renamed, or doesn't exist. Let's get you back on track.</p>
    <div style="max-width:420px;margin:0 auto 26px;position:relative;display:block;" class="nav-search">
      <input type="text" placeholder="Search products..." aria-label="Search products">
      <button type="button" aria-label="Search"><i class="fa-solid fa-magnifying-glass"></i></button>
      <div class="search-suggest"></div>
    </div>
    <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
      <a href="index.html" class="btn btn-primary"><i class="fa-solid fa-house"></i> Back to Home</a>
      <a href="products.html" class="btn btn-outline"><i class="fa-solid fa-bag-shopping"></i> Browse Products</a>
    </div>
  </div>
</div>
"""
