# -*- coding: utf-8 -*-
from build_common import IG_URL

def products_body():
    return """
<div class="page-hero">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / Products</div>
    <h1 class="section-title mt-0">All Products</h1>
    <p class="section-sub" style="margin:0 auto;">Filter, sort and search across our full 150+ item catalog.</p>
  </div>
</div>

<div class="container section-tight">
  <div class="listing-layout">
    <aside class="filters-panel" id="filters-panel">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <strong style="font-size:14.5px;"><i class="fa-solid fa-sliders"></i> Filters</strong>
        <button id="mobile-filter-close" class="modal-close" style="display:none;"><i class="fa-solid fa-xmark"></i></button>
      </div>

      <div class="form-group" style="margin-bottom:16px;">
        <label>Search</label>
        <input type="text" id="listing-search-input" placeholder="Search this catalog...">
      </div>

      <div class="filter-group">
        <div class="filter-title">Category</div>
        <div id="filter-categories"></div>
      </div>

      <div class="filter-group">
        <div class="filter-title">Brand</div>
        <div id="filter-brands" style="max-height:200px;overflow-y:auto;"></div>
      </div>

      <div class="filter-group">
        <div class="filter-title">Customer Rating</div>
        <label class="filter-option"><input type="radio" name="rating" class="f-rating" value="4.5">4.5★ &amp; above</label>
        <label class="filter-option"><input type="radio" name="rating" class="f-rating" value="4">4★ &amp; above</label>
        <label class="filter-option"><input type="radio" name="rating" class="f-rating" value="3">3★ &amp; above</label>
      </div>

      <div class="filter-group">
        <div class="filter-title">Discount</div>
        <label class="filter-option"><input type="radio" name="discount" class="f-discount" value="40">40% or more</label>
        <label class="filter-option"><input type="radio" name="discount" class="f-discount" value="25">25% or more</label>
        <label class="filter-option"><input type="radio" name="discount" class="f-discount" value="10">10% or more</label>
      </div>

      <div class="filter-group">
        <div class="filter-title">Price Range (₹)</div>
        <div class="price-range-inputs">
          <input type="number" id="price-min" placeholder="Min">
          <span>–</span>
          <input type="number" id="price-max" placeholder="Max">
        </div>
      </div>

      <button id="clear-filters" class="btn btn-outline btn-block btn-sm"><i class="fa-solid fa-rotate-left"></i> Clear All Filters</button>
    </aside>
    <div id="filter-overlay" class="drawer-overlay"></div>

    <div>
      <div class="listing-toolbar">
        <button class="btn btn-outline btn-sm mobile-filter-btn" id="mobile-filter-open"><i class="fa-solid fa-sliders"></i> Filters</button>
        <span class="result-count" id="result-count">Loading products…</span>
        <select class="sort-select" id="sort-select">
          <option value="popular">Most Popular</option>
          <option value="price-low">Price: Low to High</option>
          <option value="price-high">Price: High to Low</option>
          <option value="rating">Best Rating</option>
          <option value="discount">Biggest Discount</option>
        </select>
      </div>
      <div class="chip-row" id="chip-row"></div>
      <div class="product-grid" id="products-grid"></div>
    </div>
  </div>
</div>

<section class="section-tight" style="padding-top:0;">
  <div class="container">
    <div class="ig-band" data-aos="fade-up">
      <div>
        <h3><i class="fa-brands fa-instagram"></i> Can't decide? Ask us on Instagram</h3>
        <p>Send us a message with what you're looking for and our team will help you pick the right product.</p>
      </div>
      <a href="__IG_URL__" target="_blank" rel="noopener" class="btn" style="background:#fff;color:#dd2a7b;"><i class="fa-brands fa-instagram"></i> Message Us</a>
    </div>
  </div>
</section>
""".replace("__IG_URL__", IG_URL)


def product_details_body():
    return """
<div id="pd-root">
<div class="page-hero" style="padding:26px 0;">
  <div class="container">
    <div class="breadcrumb"><a href="index.html">Home</a> / <a href="products.html" id="pd-breadcrumb-cat">Category</a> / <span id="pd-breadcrumb-name">Product</span></div>
  </div>
</div>

<div class="container section-tight">
  <div style="display:grid;grid-template-columns:1fr 1.15fr;gap:44px;align-items:flex-start;" class="pd-top-grid">
    <div>
      <div class="gallery-main"><img id="pd-main-image" src="" alt="Product image"></div>
      <div class="gallery-thumbs" id="pd-thumbs"></div>
    </div>
    <div>
      <div class="pcard-brand" id="pd-brand" style="font-size:12.5px;"></div>
      <h1 id="pd-name" style="font-size:26px;margin:6px 0 10px;"></h1>
      <div class="pcard-rating" style="margin-bottom:14px;font-size:14px;">
        <span class="stars" id="pd-stars" style="font-size:15px;"></span>
        <span class="count" id="pd-rating-text"></span>
      </div>
      <div class="mono" style="font-size:12.5px;color:var(--gray-500);margin-bottom:16px;">
        Product ID: <b id="pd-id" style="color:var(--ink);"></b> &nbsp;·&nbsp; SKU: <b id="pd-sku" style="color:var(--ink);"></b>
      </div>
      <div class="pcard-price" style="margin-bottom:6px;">
        <span class="price-now" id="pd-price" style="font-size:28px;"></span>
        <span class="price-mrp" id="pd-mrp" style="font-size:16px;"></span>
        <span class="price-off" id="pd-off" style="font-size:14px;"></span>
      </div>
      <div style="font-size:13px;color:var(--green);font-weight:600;margin-bottom:20px;">You save <span id="pd-saved"></span></div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:22px;">
        <div class="glass-card" style="padding:12px 14px;box-shadow:none;"><div style="font-size:11px;color:var(--gray-500);">AVAILABILITY</div><b id="pd-availability" style="font-size:13px;"></b></div>
        <div class="glass-card" style="padding:12px 14px;box-shadow:none;"><div style="font-size:11px;color:var(--gray-500);">DELIVERY TIME</div><b id="pd-delivery" style="font-size:13px;"></b></div>
        <div class="glass-card" style="padding:12px 14px;box-shadow:none;"><div style="font-size:11px;color:var(--gray-500);">WARRANTY</div><b id="pd-warranty" style="font-size:13px;"></b></div>
        <div class="glass-card" style="padding:12px 14px;box-shadow:none;"><div style="font-size:11px;color:var(--gray-500);">RETURN POLICY</div><b id="pd-return" style="font-size:13px;"></b></div>
      </div>

      <div style="display:flex;gap:12px;">
        <button class="btn btn-primary" id="pd-buy-btn" style="flex:1;padding:15px;font-size:15px;"><i class="fa-solid fa-bolt"></i> Buy Now</button>
        <button class="pcard-wish" id="pd-wish-btn" style="position:static;width:52px;height:52px;border:1.5px solid var(--gray-200);"><i class="fa-regular fa-heart"></i></button>
      </div>
      <a href="__IG_URL__" target="_blank" rel="noopener" class="btn btn-ig btn-block" style="margin-top:12px;"><i class="fa-brands fa-instagram"></i> Order This on Instagram</a>
    </div>
  </div>

  <div class="pd-tabs">
    <div class="pd-tab active" data-target="tab-desc">Description</div>
    <div class="pd-tab" data-target="tab-specs">Specifications</div>
    <div class="pd-tab" data-target="tab-features">Features</div>
    <div class="pd-tab" data-target="tab-reviews">Reviews</div>
  </div>
  <div id="tab-desc" class="pd-tabpanel active"><p id="pd-desc" style="max-width:760px;"></p></div>
  <div id="tab-specs" class="pd-tabpanel"><table class="spec-table" style="max-width:640px;"><tbody id="pd-specs"></tbody></table></div>
  <div id="tab-features" class="pd-tabpanel"><ul id="pd-features" style="display:flex;flex-direction:column;gap:12px;max-width:600px;"></ul></div>
  <div id="tab-reviews" class="pd-tabpanel"><div id="pd-reviews" style="max-width:680px;"></div></div>
</div>

<section class="section-tight" style="background:#fff;">
  <div class="container">
    <div class="section-head"><div><div class="eyebrow">You May Also Like</div><h2 class="section-title">Related Products</h2></div></div>
    <div class="product-grid" id="pd-related"></div>
  </div>
</section>

<section class="section-tight" id="pd-recent-section">
  <div class="container">
    <div class="section-head"><div><div class="eyebrow">Your History</div><h2 class="section-title">Recently Viewed</h2></div></div>
    <div class="product-grid" id="pd-recent"></div>
  </div>
</section>
</div>
""".replace("__IG_URL__", IG_URL)
