/* ==========================================================================
   MECH DESIGNHUB — pdf-generator.js
   Builds a professional order-sheet PDF from the stored order object
   ========================================================================== */

const BRAND = {
  name: "Mech DesignHub",
  tagline: "Engineered Everyday Essentials",
  instagram: "https://www.instagram.com/mech_designhub/",
  instagramHandle: "@mech_designhub",
  supportEmail: "orders.mechdesignhub@gmail.com",
};

function buildOrderPDF(order) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const margin = 42;
  let y = 0;

  const blue = [47, 92, 255];
  const navy = [16, 27, 61];
  const gray = [92, 101, 122];
  const lightGray = [238, 240, 247];
  const green = [22, 163, 74];

  // ---- Header band ----
  doc.setFillColor(...navy);
  doc.rect(0, 0, pageW, 96, "F");

  // logo mark
  doc.setFillColor(...blue);
  doc.roundedRect(margin, 24, 46, 46, 10, 10, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("MD", margin + 23, 24 + 30, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(19);
  doc.text(BRAND.name, margin + 60, 46);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);
  doc.setTextColor(200, 210, 240);
  doc.text(BRAND.tagline.toUpperCase(), margin + 60, 61);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(255, 255, 255);
  doc.text("ORDER SHEET", pageW - margin, 42, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(200, 210, 240);
  doc.text("Manual Verification Order · Not a Tax Invoice", pageW - margin, 56, { align: "right" });

  y = 128;

  // ---- Order meta strip ----
  const metaItems = [
    ["Order ID", order.orderId],
    ["Invoice No.", order.invoiceNumber],
    ["Order Date", order.orderDate],
    ["Est. Delivery", order.estDelivery],
  ];
  const colW = (pageW - margin * 2) / 4;
  doc.setDrawColor(...lightGray);
  metaItems.forEach((m, i) => {
    const x = margin + i * colW;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(...gray);
    doc.text(m[0].toUpperCase(), x, y);
    doc.setFont("courier", "bold");
    doc.setFontSize(10.5);
    doc.setTextColor(...navy);
    doc.text(String(m[1]), x, y + 16);
  });
  y += 34;
  doc.setDrawColor(...lightGray);
  doc.line(margin, y, pageW - margin, y);
  y += 26;

  // ---- Customer & Address (two columns) ----
  const colGap = 24;
  const halfW = (pageW - margin * 2 - colGap) / 2;

  sectionLabel(doc, "CUSTOMER INFORMATION", margin, y, blue);
  sectionLabel(doc, "DELIVERY ADDRESS", margin + halfW + colGap, y, blue);
  y += 16;

  const custLines = [
    ["Full Name", order.customer.fullName],
    ["Mobile Number", order.customer.mobile],
    ["Email", order.customer.email || "-"],
  ];
  const addrFull = [
    order.address.houseNo, order.address.apartment, order.address.street, order.address.area
  ].filter(Boolean).join(", ");
  const addrLine2 = [order.address.landmark].filter(Boolean).join(", ");
  const addrLine3 = `${order.address.city}, ${order.address.district}, ${order.address.state} - ${order.address.pincode}`;
  const addrLines = [
    ["Address", addrFull],
    ...(addrLine2 ? [["Landmark", addrLine2]] : []),
    ["City/State", addrLine3],
    ["Country", order.address.country],
  ];

  let yc = y, ya = y;
  custLines.forEach(l => { yc = kvLine(doc, l[0], l[1], margin, yc, halfW, gray, navy); });
  addrLines.forEach(l => { ya = kvLine(doc, l[0], l[1], margin + halfW + colGap, ya, halfW, gray, navy); });

  y = Math.max(yc, ya) + 14;
  doc.setDrawColor(...lightGray);
  doc.line(margin, y, pageW - margin, y);
  y += 26;

  // ---- Product table ----
  sectionLabel(doc, "ORDER ITEM", margin, y, blue);
  y += 14;

  const tableX = margin;
  const tableW = pageW - margin * 2;
  const headers = ["Product", "Product ID", "Qty", "Unit Price", "Total"];
  const widths = [tableW * 0.40, tableW * 0.22, tableW * 0.10, tableW * 0.14, tableW * 0.14];

  doc.setFillColor(...navy);
  doc.rect(tableX, y, tableW, 26, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  let cx = tableX + 10;
  headers.forEach((h, i) => { doc.text(h, cx, y + 17); cx += widths[i]; });
  y += 26;

  const rowH = 46;
  doc.setFillColor(...lightGray);
  doc.rect(tableX, y, tableW, rowH, "F");
  doc.setTextColor(...navy);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  cx = tableX + 10;
  const nameLines = doc.splitTextToSize(order.product.name, widths[0] - 16);
  doc.text(nameLines, cx, y + 16);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(...gray);
  doc.text(order.product.brand, cx, y + 32);
  cx += widths[0];

  doc.setFont("courier", "normal");
  doc.setFontSize(9.5);
  doc.setTextColor(...navy);
  doc.text(order.product.id, cx, y + 22);
  doc.setFontSize(8);
  doc.setTextColor(...gray);
  doc.text(order.product.sku, cx, y + 34);
  cx += widths[1];

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(...navy);
  doc.text(String(order.qty), cx, y + 26);
  cx += widths[2];

  doc.setFont("courier", "normal");
  doc.text(rupee(order.unitPrice), cx, y + 26);
  cx += widths[3];

  doc.setFont("courier", "bold");
  doc.setTextColor(...blue);
  doc.text(rupee(order.totalPrice), cx, y + 26);

  y += rowH + 6;
  doc.setDrawColor(...lightGray);
  doc.line(margin, y, pageW - margin, y);
  y += 4;

  // total row
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(...navy);
  doc.text("Order Total", pageW - margin - 150, y + 20);
  doc.setFont("courier", "bold");
  doc.setFontSize(15);
  doc.setTextColor(...blue);
  doc.text(rupee(order.totalPrice), pageW - margin, y + 20, { align: "right" });
  y += 44;

  // ---- Notes / signature ----
  doc.setDrawColor(...lightGray);
  doc.line(margin, y, pageW - margin, y);
  y += 24;

  const noteW = (pageW - margin * 2 - colGap) / 2;
  sectionLabel(doc, "NOTES", margin, y, blue);
  sectionLabel(doc, "CUSTOMER SIGNATURE", margin + noteW + colGap, y, blue);
  y += 14;
  doc.setDrawColor(...lightGray);
  doc.roundedRect(margin, y, noteW, 64, 6, 6);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(8.5);
  doc.setTextColor(...gray);
  doc.text("This order is pending manual verification via Instagram DM.\nOur team will contact you to confirm before dispatch.", margin + 10, y + 20);

  doc.roundedRect(margin + noteW + colGap, y, noteW, 64, 6, 6);
  doc.setDrawColor(...gray);
  doc.line(margin + noteW + colGap + 16, y + 46, margin + noteW + colGap + noteW - 16, y + 46);
  doc.setFontSize(8);
  doc.text("Sign above", margin + noteW + colGap + 16, y + 58);

  y += 90;

  // ---- Thank you + footer ----
  doc.setFillColor(...lightGray);
  doc.roundedRect(margin, y, pageW - margin * 2, 46, 8, 8, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...navy);
  doc.text("Thank you for shopping with Mech DesignHub!", pageW / 2, y + 19, { align: "center" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(...gray);
  doc.text(`Send this PDF to our Instagram ${BRAND.instagramHandle} to confirm your order.`, pageW / 2, y + 33, { align: "center" });

  const footerY = doc.internal.pageSize.getHeight() - 26;
  doc.setFontSize(7.5);
  doc.setTextColor(...gray);
  doc.text(`${BRAND.name} · ${BRAND.instagramHandle} · This is a manually confirmed dropshipping order (no online payment collected).`, pageW / 2, footerY, { align: "center" });

  return doc;
}

function sectionLabel(doc, text, x, y, color) {
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(...color);
  doc.text(text, x, y);
}
function kvLine(doc, label, value, x, y, w, grayColor, navyColor) {
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...grayColor);
  doc.text(label, x, y);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9.5);
  doc.setTextColor(...navyColor);
  const lines = doc.splitTextToSize(String(value || "-"), w);
  doc.text(lines, x, y + 13);
  return y + 13 + (lines.length - 1) * 11 + 16;
}
function rupee(n) { return "Rs. " + Math.round(n).toLocaleString("en-IN"); }

function generateOrderPDF(order, mode) {
  const doc = buildOrderPDF(order);
  const filename = `MechDesignHub_Order_${order.orderId}.pdf`;
  if (mode === "download") {
    doc.save(filename);
    showToast("PDF downloaded", "success");
  } else if (mode === "preview") {
    const url = doc.output("bloburl");
    window.open(url, "_blank");
  } else if (mode === "print") {
    doc.autoPrint();
    const url = doc.output("bloburl");
    window.open(url, "_blank");
  }
}
window.generateOrderPDF = generateOrderPDF;
