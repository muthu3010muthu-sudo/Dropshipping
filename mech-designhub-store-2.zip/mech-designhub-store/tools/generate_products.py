import json, random

random.seed(42)

# Category -> (color hex for placeholder, [ (type_name, [brand pool], [name templates], price_min, price_max) ])
CATEGORIES = {
    "Electronics": {
        "color": "2F5CFF",
        "brands": ["Voltrix", "Nexowave", "Zentek", "Byteon", "Kryonix"],
        "items": [
            "Wireless Earbuds", "Bluetooth Speaker", "Smart Watch", "Noise Cancelling Headphones",
            "Power Bank 20000mAh", "Fast Charger 65W", "USB-C Hub", "Mechanical Keyboard",
            "Wireless Mouse", "Webcam 1080p", "LED Desk Lamp", "Portable SSD 1TB",
            "Bluetooth Neckband", "Smart Plug Wi-Fi",
        ],
    },
    "Home & Kitchen": {
        "color": "4C6EF5",
        "brands": ["Hearthly", "Kitchenora", "Domesta", "Warmlyn", "Cookrite"],
        "items": [
            "Air Fryer 5L", "Electric Kettle", "Non-Stick Cookware Set", "Blender 700W",
            "Coffee Maker", "Rice Cooker", "Vacuum Flask Set", "Chopping Board Set",
            "Knife Set 6-Piece", "Storage Container Set", "Dinner Set 24-Piece", "Table Lamp",
            "Induction Cooktop", "Food Steamer",
        ],
    },
    "Fashion": {
        "color": "3B5BDB",
        "brands": ["Urbanwear", "Threadloom", "Vestora", "Clothcraft", "Draperie"],
        "items": [
            "Cotton Casual Shirt", "Slim Fit Jeans", "Running Shoes", "Leather Wallet",
            "Winter Hoodie", "Formal Blazer", "Canvas Sneakers", "Graphic T-Shirt",
            "Denim Jacket", "Sports Cap", "Ankle Boots", "Chino Trousers",
            "Polo T-Shirt", "Track Pants",
        ],
    },
    "Furniture": {
        "color": "5C7CFA",
        "brands": ["Woodura", "Framewell", "Restly", "Formaline", "Oakstead"],
        "items": [
            "Ergonomic Office Chair", "Study Table", "Bookshelf 5-Tier", "Bedside Table",
            "Wooden Coffee Table", "Folding Chair", "TV Stand Unit", "Shoe Rack Organizer",
            "Wardrobe 3-Door", "Recliner Sofa Chair", "Bar Stool Set", "Wall Mounted Desk",
            "Shoe Cabinet", "Console Table",
        ],
    },
    "Beauty": {
        "color": "845EF7",
        "brands": ["Glowvana", "Lumina", "Purelle", "Skinova", "Blossette"],
        "items": [
            "Vitamin C Face Serum", "Hair Dryer 1800W", "Electric Trimmer", "Makeup Brush Set",
            "Facial Cleansing Brush", "Hair Straightener", "Moisturizing Cream", "Perfume 100ml",
            "Nail Care Kit", "LED Makeup Mirror", "Sunscreen SPF50", "Lip Care Combo Set",
            "Hair Oil Combo", "Face Wash Combo",
        ],
    },
    "Sports": {
        "color": "1971C2",
        "brands": ["Athlex", "Fitgear", "Trailforce", "Sprintix", "Ironclad"],
        "items": [
            "Yoga Mat Premium", "Adjustable Dumbbell Set", "Resistance Band Set", "Cycling Helmet",
            "Football Size 5", "Badminton Racket Set", "Skipping Rope", "Gym Gloves",
            "Water Bottle Sport 1L", "Fitness Tracker Band", "Camping Tent 2-Person", "Cricket Bat Kashmir Willow",
            "Table Tennis Kit", "Swimming Goggles",
        ],
    },
    "Accessories": {
        "color": "0CA678",
        "brands": ["Carrio", "Straplyn", "Beltcraft", "Poucha", "Gearloop"],
        "items": [
            "Leather Belt", "Sunglasses UV400", "Laptop Backpack", "Travel Duffel Bag",
            "Analog Wrist Watch", "Wallet Card Holder", "Phone Case Premium", "Tote Bag Canvas",
            "Cap & Beanie Combo", "Keychain Multi-tool", "Sling Crossbody Bag", "Umbrella Auto-Open",
        ],
    },
    "Toys": {
        "color": "F76707",
        "brands": ["Playnest", "Kidoria", "Funtoro", "Blockzy", "Wondertoy"],
        "items": [
            "Building Blocks Set", "Remote Control Car", "Plush Teddy Bear", "Puzzle 500-Piece",
            "Educational Learning Tablet", "Action Figure Set", "Board Game Family Pack", "Toy Kitchen Set",
            "Drone Mini Camera", "Art & Craft Kit", "Musical Toy Piano", "Building Robot Kit",
        ],
    },
    "Books": {
        "color": "495057",
        "brands": ["Pageturn Press", "Storyfield", "Inkwell Editions", "Bindery House", "Chapterline"],
        "items": [
            "Self-Improvement Bestseller", "Mystery Thriller Novel", "Children's Picture Book Set",
            "Cookbook Collection", "Business Strategy Guide", "Fantasy Fiction Novel",
            "Productivity Planner Book", "Poetry Anthology", "History Encyclopedia", "Science Fiction Novel",
            "Personal Finance Guide", "Motivational Quotes Journal",
        ],
    },
    "Office Supplies": {
        "color": "343A40",
        "brands": ["Deskly", "Papertone", "Officeon", "Notewell", "Stationex"],
        "items": [
            "Ergonomic Desk Organizer", "Notebook Set A5", "Gel Pen Set", "Sticky Notes Combo",
            "File Folder Organizer", "Desk Calendar Stand", "Whiteboard Magnetic", "Stapler & Punch Set",
            "Laptop Stand Adjustable", "Cable Management Kit", "Highlighter Set", "Business Card Holder",
        ],
    },
    "Automotive": {
        "color": "212529",
        "brands": ["Driveon", "Motorix", "Torquefit", "Gearhead", "Autolume"],
        "items": [
            "Car Phone Mount", "LED Headlight Bulb Set", "Car Vacuum Cleaner", "Seat Cover Set",
            "Car Air Freshener Combo", "Tire Pressure Gauge", "Dashboard Camera", "Car Cover Waterproof",
            "Steering Wheel Cover", "Jump Starter Kit", "Car Organizer Trunk", "Microfiber Cleaning Kit",
        ],
    },
    "Pet Supplies": {
        "color": "E8590C",
        "brands": ["Pawsome", "Furrylane", "Petloop", "Wagwell", "Barkbox"],
        "items": [
            "Dog Leash & Collar Set", "Cat Scratching Post", "Pet Bed Cushion", "Automatic Pet Feeder",
            "Dog Chew Toy Set", "Pet Grooming Kit", "Cat Litter Box", "Pet Carrier Bag",
            "Dog Training Clicker", "Aquarium Filter Pump", "Pet Food Storage Container", "Bird Cage Medium",
        ],
    },
}

FEATURES_POOL = [
    "Premium build quality", "Energy efficient design", "Compact and lightweight",
    "Easy to clean and maintain", "Ergonomic and comfortable", "Long-lasting durability",
    "Sleek modern design", "Travel-friendly size", "Skin/eco-friendly materials",
    "Advanced safety features", "Multi-functional usage", "Water & dust resistant",
    "Noise-free smooth operation", "Adjustable settings", "1-year manufacturer support",
]

DESC_TEMPLATES = [
    "Engineered for everyday reliability, the {name} combines thoughtful design with dependable performance, making it a smart addition to your {cat_lower} collection.",
    "The {name} from {brand} blends premium materials with practical functionality, delivering a experience that's built to last and easy to love.",
    "Designed with the modern user in mind, the {name} offers a perfect balance of style, durability, and everyday convenience.",
    "Upgrade your routine with the {name} — thoughtfully crafted by {brand} to deliver consistent performance without compromising on design.",
]

REVIEW_TEMPLATES = [
    ("Arjun M.", 5, "Really happy with this purchase, quality feels premium and delivery was quick."),
    ("Priya S.", 4, "Good product overall, matches the description. Would recommend."),
    ("Rahul K.", 5, "Exceeded my expectations, works exactly as shown. Packaging was solid too."),
    ("Sneha R.", 4, "Nice value for money. Minor delay in delivery but product quality is great."),
    ("Vikram T.", 5, "This is my second order from this store, always reliable quality."),
    ("Ananya D.", 3, "Decent product, does the job but could be improved slightly."),
]

WARRANTIES = ["6 Months", "1 Year", "2 Years", "No Warranty (Consumable Item)"]
DELIVERY_TIMES = ["3-5 Business Days", "5-7 Business Days", "2-4 Business Days", "7-10 Business Days"]
RETURN_POLICIES = ["7-Day Easy Return", "10-Day Replacement Only", "No Return (Hygiene Product)", "15-Day Return & Refund"]

products = []
pid = 1000

for cat, meta in CATEGORIES.items():
    color = meta["color"]
    for item in meta["items"]:
        brand = random.choice(meta["brands"])
        pid += 1
        product_id = f"MDH-{pid}"
        sku = f"SKU{pid}{random.randint(10,99)}"
        name = f"{brand} {item}"
        mrp = random.choice([799, 999, 1249, 1499, 1999, 2499, 2999, 3499, 3999, 4999, 5999, 7999, 9999])
        discount = random.choice([10, 15, 20, 25, 30, 35, 40, 45, 50])
        selling = round(mrp * (100 - discount) / 100)
        saved = mrp - selling
        rating = round(random.uniform(3.6, 5.0), 1)
        reviews_count = random.randint(12, 890)
        n_features = random.sample(FEATURES_POOL, 4)
        desc = random.choice(DESC_TEMPLATES).format(name=name, brand=brand, cat_lower=cat.lower())
        specs = {
            "Brand": brand,
            "Model": f"{item.split()[0][:3].upper()}-{random.randint(100,999)}",
            "Category": cat,
            "Material": random.choice(["Premium ABS Plastic", "Stainless Steel", "Engineered Wood", "Cotton Blend", "Aluminum Alloy", "High-Grade Polymer"]),
            "Color": random.choice(["Black", "Blue", "Graphite Grey", "White", "Navy", "Charcoal"]),
            "Weight": f"{round(random.uniform(0.15, 6.5), 2)} kg",
            "Country of Origin": "India",
        }
        n_reviews = random.sample(REVIEW_TEMPLATES, 3)
        images = [f"https://placehold.co/700x700/{color}/FFFFFF?font=poppins&text={item.replace(' ','+')}" for _ in range(1)]
        images += [f"https://placehold.co/700x700/{color}/FFFFFF?font=poppins&text={item.replace(' ','+')}%0A(View+{i+2})" for i in range(3)]
        thumb = f"https://placehold.co/500x500/{color}/FFFFFF?font=poppins&text={item.replace(' ','+')}"

        product = {
            "id": product_id,
            "sku": sku,
            "name": name,
            "brand": brand,
            "category": cat,
            "description": desc,
            "features": n_features,
            "specifications": specs,
            "rating": rating,
            "reviewsCount": reviews_count,
            "reviews": [{"name": r[0], "rating": r[1], "text": r[2]} for r in n_reviews],
            "mrp": mrp,
            "discount": discount,
            "price": selling,
            "saved": saved,
            "availability": random.choices(["In Stock", "Only Few Left", "In Stock"], weights=[6,1,3])[0],
            "warranty": random.choice(WARRANTIES),
            "returnPolicy": random.choice(RETURN_POLICIES),
            "deliveryTime": random.choice(DELIVERY_TIMES),
            "image": thumb,
            "images": images,
            "badges": [],
        }
        # assign tag badges
        tags = []
        if discount >= 35:
            tags.append("deal")
        if rating >= 4.6 and reviews_count >= 200:
            tags.append("bestseller")
        if random.random() < 0.22:
            tags.append("new")
        if random.random() < 0.3:
            tags.append("trending")
        if random.random() < 0.35:
            tags.append("featured")
        product["badges"] = tags
        products.append(product)

random.shuffle(products)

print(f"Generated {len(products)} products")

import os
OUT_PATH = os.path.join(os.path.dirname(__file__), "..", "js", "products-data.js")
with open(OUT_PATH, "w") as f:
    f.write("// Auto-generated demo product catalog for Mech DesignHub\n")
    f.write("const PRODUCTS = ")
    f.write(json.dumps(products, indent=2))
    f.write(";\n")
