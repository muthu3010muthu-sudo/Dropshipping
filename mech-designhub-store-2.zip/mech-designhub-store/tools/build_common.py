\
# -*- coding: utf-8 -*-
"""Builds all HTML pages for the Mech DesignHub site using shared chrome."""

IG_URL = "https://www.instagram.com/mech_designhub/"

def nav_link(label, href, key, current):
    cls = ' class="active"' if key == current else ""
    return f'<a href="{href}"{cls}>{label}</a>'

NAV_ITEMS = [
    ("Home", "index.html", "home"),
    ("Products", "products.html", "products"),
    ("Categories", "categories.html", "categories"),
    ("About Us", "about.html", "about"),
    ("Contact", "contact.html", "contact"),
    ("FAQ", "faq.html", "faq"),
]

def head(title, desc, current):
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} | Mech DesignHub</title>
<meta name="description" content="{desc}">
<meta name="robots" content="index, follow">
<link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 rx=%2224%22 fill=%22%232F5CFF%22/><text x=%2250%22 y=%2266%22 font-size=%2244%22 font-family=%22sans-serif%22 fill=%22white%22 text-anchor=%22middle%22 font-weight=%22bold%22>M</text></svg>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
"""

def page_loader():
    return """<div id="page-loader"><div class="loader-mark"><div class="loader-ring"></div><span>Mech DesignHub</span></div></div>
<div id="scroll-progress"></div>
"""

def navbar(current):
    links = "\n      ".join(nav_link(l, h, k, current) for l, h, k in NAV_ITEMS)
    return f"""<nav id="navbar">
  <div class="container nav-inner">
    <a href="index.html" class="brand">
      <span class="brand-mark"><i class="fa-solid fa-cube"></i></span>
      <span>Mech DesignHub<small>Engineered Essentials</small></span>
    </a>
    <div class="nav-links">
      {links}
    </div>
    <div class="nav-search">
      <input type="text" placeholder="Search products, brands, categories..." aria-label="Search products">
      <button type="button" aria-label="Search"><i class="fa-solid fa-magnifying-glass"></i></button>
      <div class="search-suggest"></div>
    </div>
    <div class="nav-actions">
      <button class="icon-btn" onclick="openWishlistPanel()" aria-label="Wishlist" style="position:relative;">
        <i class="fa-regular fa-heart"></i>
        <span id="wishlist-count" class="badge-count" style="display:none;">0</span>
      </button>
      <a class="icon-btn" href="{IG_URL}" target="_blank" rel="noopener" aria-label="Order on Instagram" style="color:#dd2a7b;border-color:#f6c6dd;">
        <i class="fa-brands fa-instagram"></i>
      </a>
      <button class="nav-burger" id="nav-burger" aria-label="Open menu"><i class="fa-solid fa-bars"></i></button>
    </div>
  </div>
</nav>
<div class="drawer-overlay" id="drawer-overlay"></div>
<div class="mobile-drawer" id="mobile-drawer">
  <div class="brand" style="margin-bottom:22px;">
    <span class="brand-mark"><i class="fa-solid fa-cube"></i></span>
    <span>Mech DesignHub<small>Engineered Essentials</small></span>
  </div>
  <a href="index.html">Home</a>
  <a href="products.html">Products</a>
  <a href="categories.html">Categories</a>
  <a href="about.html">About Us</a>
  <a href="contact.html">Contact Us</a>
  <a href="faq.html">FAQ</a>
  <a href="privacy.html">Privacy Policy</a>
  <a href="terms.html">Terms &amp; Conditions</a>
  <a href="{IG_URL}" target="_blank" rel="noopener" style="color:#dd2a7b;font-weight:700;">
    <i class="fa-brands fa-instagram"></i>&nbsp; Order on Instagram
  </a>
</div>
"""

def footer():
    return f"""<footer>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="index.html" class="brand">
          <span class="brand-mark"><i class="fa-solid fa-cube"></i></span>
          <span>Mech DesignHub<small style="color:rgba(255,255,255,.5);">Engineered Essentials</small></span>
        </a>
        <p>A frontend-only dropshipping storefront. Browse, build your order sheet, and confirm manually with our team over Instagram DM — simple, transparent, no online payment required.</p>
        <div class="social-row">
          <a href="{IG_URL}" target="_blank" rel="noopener" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="#" aria-label="Twitter"><i class="fa-brands fa-x-twitter"></i></a>
          <a href="#" aria-label="Pinterest"><i class="fa-brands fa-pinterest-p"></i></a>
        </div>
      </div>
      <div class="footer-col">
        <h5>Quick Links</h5>
        <a href="index.html">Home</a>
        <a href="products.html">Shop All Products</a>
        <a href="categories.html">Categories</a>
        <a href="about.html">About Us</a>
        <a href="contact.html">Contact Us</a>
      </div>
      <div class="footer-col">
        <h5>Help &amp; Info</h5>
        <a href="faq.html">FAQ</a>
        <a href="privacy.html">Privacy Policy</a>
        <a href="terms.html">Terms &amp; Conditions</a>
        <a href="contact.html">Shipping &amp; Returns</a>
        <a href="index.html#how-to-order">How to Order</a>
      </div>
      <div class="footer-col footer-contact">
        <h5>Get In Touch</h5>
        <ul>
          <li><i class="fa-brands fa-instagram"></i><a href="{IG_URL}" target="_blank" rel="noopener" style="padding:0;">@mech_designhub</a></li>
          <li><i class="fa-solid fa-envelope"></i><span>orders.mechdesignhub@gmail.com</span></li>
          <li><i class="fa-solid fa-clock"></i><span>Mon–Sat, 10 AM – 7 PM IST</span></li>
        </ul>
        <a href="{IG_URL}" target="_blank" rel="noopener" class="btn btn-ig btn-sm" style="margin-top:10px;"><i class="fa-brands fa-instagram"></i> Order on Instagram</a>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span class="cur-year"></span> Mech DesignHub. All rights reserved.</span>
      <span>Demo storefront · Frontend-only · Manual order confirmation via Instagram DM</span>
    </div>
  </div>
</footer>
"""

def floating_widgets():
    return f"""<div id="toast-container"></div>
<button id="back-to-top" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button>
<a id="float-ig" href="{IG_URL}" target="_blank" rel="noopener" aria-label="Order on Instagram" class="show"><i class="fa-brands fa-instagram"></i></a>
"""

def scripts_tail():
    return """<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="js/products-data.js"></script>
<script src="js/main.js"></script>
<script src="js/render.js"></script>
<script src="js/order-form.js"></script>
<script src="js/pdf-generator.js"></script>
"""

def page_wrap(current, title, desc, body, extra_scripts=""):
    return (
        head(title, desc, current)
        + "<body>\n"
        + page_loader()
        + navbar(current)
        + body
        + footer()
        + floating_widgets()
        + scripts_tail()
        + extra_scripts
        + "\n</body>\n</html>\n"
    )
